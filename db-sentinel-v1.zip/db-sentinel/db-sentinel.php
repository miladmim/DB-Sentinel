<?php
/**
 * Plugin Name:       DB Sentinel – نگهبان دیتابیس
 * Description:       بکاپ خودکار دیتابیس، بازگردانی کامل و گزینشی، آپلود بکاپ، ذخیره‌ساز بیرونی رمزنگاری‌شده، ردیابی «چه کسی / کدام افزونه» با امکان برگرداندن هر تغییر، اسکنر امنیتی و اعلان‌ها.
 * Version:           1.0.0
 * Requires at least: 5.6
 * Requires PHP:      7.2
 * Author:            miladmim
 * Text Domain:       db-sentinel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DBS_VERSION', '2.0.0' );
define( 'DBS_FILE', __FILE__ );
define( 'DBS_DIR', plugin_dir_path( __FILE__ ) );
define( 'DBS_URL', plugin_dir_url( __FILE__ ) );

require_once DBS_DIR . 'includes/paths.php';
require_once DBS_DIR . 'includes/class-dbs-settings.php';
require_once DBS_DIR . 'includes/class-dbs-sql.php';
require_once DBS_DIR . 'includes/class-dbs-activity.php';
require_once DBS_DIR . 'includes/class-dbs-backup.php';
require_once DBS_DIR . 'includes/class-dbs-remote.php';
require_once DBS_DIR . 'includes/class-dbs-notify.php';
require_once DBS_DIR . 'includes/class-dbs-tools.php';
require_once DBS_DIR . 'includes/class-dbs-admin.php';

class DBS_Plugin {

	const HOOK  = 'dbs_run_backup';
	const WATCH = 'dbs_watchdog';

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
		add_action( self::HOOK, array( __CLASS__, 'cron_backup' ) );
		add_action( self::WATCH, array( 'DBS_Notify', 'watchdog' ) );
		add_action( 'init', array( __CLASS__, 'ensure_schedule' ) );
		add_action( 'init', array( __CLASS__, 'cron_endpoint' ), 1 );
		add_filter( 'upgrader_pre_install', array( __CLASS__, 'pre_update' ), 10, 2 );
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 100 );

		DBS_Activity::init();
		if ( is_admin() ) {
			DBS_Admin::init();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			require_once DBS_DIR . 'includes/class-dbs-cli.php';
			WP_CLI::add_command( 'sentinel', 'DBS_CLI' );
		}
	}

	public static function schedules( $s ) {
		$hours             = (int) DBS_Settings::get( 'interval_hours' );
		$s['dbs_interval'] = array(
			'interval' => max( 3600, $hours * 3600 ),
			'display'  => 'DB Sentinel',
		);
		return $s;
	}

	public static function cron_backup() {
		DBS_Backup::run( 'auto' );
	}

	public static function ensure_schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 60, 'dbs_interval', self::HOOK );
		}
		if ( ! wp_next_scheduled( self::WATCH ) ) {
			wp_schedule_event( time() + 300, 'hourly', self::WATCH );
		}
	}

	public static function reschedule() {
		wp_clear_scheduled_hook( self::HOOK );
		$interval = (int) DBS_Settings::get( 'interval_hours' ) * 3600;
		$list     = DBS_Storage::all();
		$next     = time() + 60;
		if ( $list ) {
			$next = max( $next, (int) $list[0]['created'] + $interval );
		}
		wp_schedule_event( $next, 'dbs_interval', self::HOOK );
	}

	/**
	 * Secret URL for a real server cron:  https://site/?dbs_cron=KEY
	 * Runs a backup only when one is due, plus the hourly maintenance.
	 */
	public static function cron_endpoint() {
		if ( ! isset( $_GET['dbs_cron'] ) ) {
			return;
		}
		nocache_headers();
		$key = is_string( $_GET['dbs_cron'] ) ? $_GET['dbs_cron'] : '';
		if ( ! hash_equals( DBS_Settings::cron_key(), $key ) ) {
			status_header( 403 );
			exit( 'forbidden' );
		}
		@ignore_user_abort( true );
		@set_time_limit( 0 );
		$list = DBS_Storage::all();
		$due  = ! $list || ( time() - (int) $list[0]['created'] ) >= (int) DBS_Settings::get( 'interval_hours' ) * 3600 - 120;
		$ran  = false;
		$err  = '';
		if ( $due ) {
			$r   = DBS_Backup::run( 'auto' );
			$ran = ! is_wp_error( $r );
			$err = is_wp_error( $r ) ? $r->get_error_message() : '';
		}
		if ( time() - (int) get_option( 'dbs_watch_at', 0 ) > 3000 ) {
			update_option( 'dbs_watch_at', time(), false );
			DBS_Notify::watchdog();
		}
		header( 'Content-Type: application/json; charset=utf-8' );
		echo wp_json_encode( array( 'ok' => '' === $err, 'ran' => $ran, 'error' => $err ) );
		exit;
	}

	/** Automatic restore point right before a plugin / theme / core update. */
	public static function pre_update( $response, $hook_extra ) {
		static $done = false;
		if ( $done || ! DBS_Settings::get( 'pre_update_snapshot' ) ) {
			return $response;
		}
		$done = true;
		$list = DBS_Storage::all();
		if ( $list && time() - (int) $list[0]['created'] < 600 ) {
			return $response;
		}
		DBS_Backup::run( 'pre_update' );
		return $response;
	}

	public static function admin_bar( $bar ) {
		if ( ! current_user_can( 'manage_options' ) || ! is_admin_bar_showing() ) {
			return;
		}
		$info = get_transient( 'dbs_bar' );
		if ( ! is_array( $info ) ) {
			$list = DBS_Storage::all();
			$info = array( 'last' => $list ? (int) $list[0]['created'] : 0 );
			set_transient( 'dbs_bar', $info, 300 );
		}
		$limit = (int) DBS_Settings::get( 'interval_hours' ) * 3600 * 1.5 + 1800;
		$ok    = $info['last'] && ( time() - $info['last'] ) < $limit;
		$txt   = $info['last'] ? human_time_diff( $info['last'] ) . ' پیش' : 'بدون بکاپ';
		$bar->add_node(
			array(
				'id'    => 'dbs-status',
				'title' => '<span style="display:inline-block;width:9px;height:9px;border-radius:50%;margin-inline-end:6px;background:' . ( $ok ? '#3ddc97' : '#ff5c5c' ) . '"></span>بکاپ دیتابیس: ' . esc_html( $txt ),
				'href'  => admin_url( 'admin.php?page=' . DBS_Admin::SLUG ),
			)
		);
	}

	public static function activate() {
		DBS_Storage::dir( true );
		DBS_Activity::install();
		update_option( 'dbs_db_version', DBS_VERSION, false );
		DBS_Settings::cron_key();
		wp_clear_scheduled_hook( self::HOOK );
		wp_clear_scheduled_hook( self::WATCH );
		wp_schedule_event( time() + 45, 'dbs_interval', self::HOOK );
		wp_schedule_event( time() + 300, 'hourly', self::WATCH );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::HOOK );
		wp_clear_scheduled_hook( self::WATCH );
	}
}

register_activation_hook( __FILE__, array( 'DBS_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'DBS_Plugin', 'deactivate' ) );

DBS_Plugin::init();
