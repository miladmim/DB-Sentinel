<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBS_Tools {

	/* ------------------------------------------------------------------ *
	 * Undo a logged change
	 * ------------------------------------------------------------------ */

	public static function undo( $id, $force = false ) {
		global $wpdb;
		$t   = DBS_Activity::table();
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, summary, undo, undone FROM `{$t}` WHERE id = %d", (int) $id ), ARRAY_A );
		if ( ! $row || '' === (string) $row['undo'] ) {
			return new WP_Error( 'dbs_undo', 'برای این رویداد امکان برگرداندن ثبت نشده است.' );
		}
		if ( ! empty( $row['undone'] ) ) {
			return new WP_Error( 'dbs_undo', 'این تغییر قبلاً برگردانده شده است.' );
		}
		$d = json_decode( $row['undo'], true );
		if ( ! is_array( $d ) || empty( $d['t'] ) ) {
			return new WP_Error( 'dbs_undo', 'اطلاعات برگرداندن خراب است.' );
		}

		$changed = new WP_Error( 'dbs_changed', 'از زمان این تغییر، همان مورد دوباره عوض شده است. برگرداندن، تغییرات بعدی را هم از بین می‌برد.' );
		DBS_Activity::$suppress = true;
		try {
			$res = self::apply_undo( $d, $force, $changed );
		} finally {
			DBS_Activity::$suppress = false;
		}
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$wpdb->update( $t, array( 'undone' => 1 ), array( 'id' => (int) $id ), array( '%d' ), array( '%d' ) );
		DBS_Activity::record(
			array(
				'category'    => 'undo',
				'action'      => 'undo',
				'severity'    => 'notice',
				'summary'     => 'برگرداندن تغییر: ' . DBS_Inspect::cut( $row['summary'], 300 ),
				'object_type' => 'event',
				'object_id'   => (string) $id,
				'actor_type'  => 'plugin',
				'actor_slug'  => 'db-sentinel',
			)
		);
		return true;
	}

	private static function apply_undo( $d, $force, $changed ) {
		switch ( $d['t'] ) {
			case 'option':
				$name = (string) $d['name'];
				$cur  = get_option( $name, '__dbs_none__' );
				if ( 'set' === $d['op'] || 'delete' === $d['op'] ) {
					if ( ! $force && ! empty( $d['h'] ) && '__dbs_none__' !== $cur && md5( maybe_serialize( $cur ) ) !== $d['h'] ) {
						return $changed;
					}
					if ( 'set' === $d['op'] ) {
						update_option( $name, maybe_unserialize( $d['value'] ) );
					} else {
						delete_option( $name );
					}
				} else {
					if ( ! $force && '__dbs_none__' !== $cur ) {
						return $changed;
					}
					if ( '__dbs_none__' !== $cur ) {
						delete_option( $name );
					}
					add_option( $name, maybe_unserialize( $d['value'] ) );
				}
				return true;

			case 'post':
				$post = get_post( (int) $d['id'], ARRAY_A );
				if ( ! $post ) {
					return new WP_Error( 'dbs_undo', 'این نوشته دیگر وجود ندارد.' );
				}
				if ( ! $force && ! empty( $d['h'] ) ) {
					$now = array();
					foreach ( (array) $d['k'] as $k ) {
						$now[ $k ] = (string) $post[ $k ];
					}
					if ( md5( wp_json_encode( $now ) ) !== $d['h'] ) {
						return $changed;
					}
				}
				$r = wp_update_post( wp_slash( array_merge( array( 'ID' => (int) $d['id'] ), $d['fields'] ) ), true );
				return is_wp_error( $r ) ? $r : true;

			case 'post_trash':
				wp_trash_post( (int) $d['id'] );
				return true;

			case 'post_untrash':
				wp_untrash_post( (int) $d['id'] );
				return true;

			case 'meta':
				if ( 'set' === $d['op'] ) {
					update_post_meta( (int) $d['id'], $d['key'], wp_slash( maybe_unserialize( $d['value'] ) ) );
				} else {
					delete_post_meta( (int) $d['id'], $d['key'] );
				}
				return true;

			case 'roles':
				$u = new WP_User( (int) $d['user_id'] );
				if ( ! $u->exists() ) {
					return new WP_Error( 'dbs_undo', 'این کاربر دیگر وجود ندارد.' );
				}
				foreach ( (array) $u->roles as $r ) {
					$u->remove_role( $r );
				}
				foreach ( (array) $d['roles'] as $r ) {
					$u->add_role( $r );
				}
				return true;

			case 'plugin':
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
				if ( ! empty( $d['activate'] ) ) {
					$r = activate_plugin( $d['file'] );
					return is_wp_error( $r ) ? $r : true;
				}
				deactivate_plugins( $d['file'] );
				return true;
		}
		return new WP_Error( 'dbs_undo', 'نوع برگرداندن پشتیبانی نمی‌شود.' );
	}

	/* ------------------------------------------------------------------ *
	 * Compare
	 * ------------------------------------------------------------------ */

	private static function live_info() {
		global $wpdb;
		$out = array();
		foreach ( DBS_Backup::tables() as $t ) {
			$out[ $t ] = array( 'rows' => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . str_replace( '`', '``', $t ) . '`' ), 'crc' => '' );
		}
		return $out;
	}

	public static function compare( $a, $b ) {
		$ma = DBS_Storage::get( $a );
		if ( ! $ma ) {
			return new WP_Error( 'dbs_cmp', 'بکاپ اول پیدا نشد.' );
		}
		$ia = DBS_Storage::table_info( $ma );
		if ( 'live' === $b ) {
			$ib = self::live_info();
		} else {
			$mb = DBS_Storage::get( $b );
			if ( ! $mb ) {
				return new WP_Error( 'dbs_cmp', 'بکاپ دوم پیدا نشد.' );
			}
			$ib = DBS_Storage::table_info( $mb );
		}
		$out   = array();
		$names = array_unique( array_merge( array_keys( $ia ), array_keys( $ib ) ) );
		foreach ( $names as $n ) {
			$x = isset( $ia[ $n ] ) ? $ia[ $n ] : null;
			$y = isset( $ib[ $n ] ) ? $ib[ $n ] : null;
			if ( ! $x ) {
				$st = 'added';
			} elseif ( ! $y ) {
				$st = 'removed';
			} elseif ( ! empty( $x['crc'] ) && ! empty( $y['crc'] ) ) {
				$st = ( $x['crc'] === $y['crc'] ) ? 'same' : 'changed';
			} else {
				$st = ( (int) $x['rows'] === (int) $y['rows'] ) ? 'maybe' : 'changed';
			}
			$out[] = array(
				'name'   => $n,
				'status' => $st,
				'a'      => $x ? (int) $x['rows'] : null,
				'b'      => $y ? (int) $y['rows'] : null,
				'crc_a'  => $x ? $x['crc'] : '',
			);
		}
		$rank = array( 'changed' => 0, 'added' => 1, 'removed' => 2, 'maybe' => 3, 'same' => 4 );
		usort(
			$out,
			function ( $p, $q ) use ( $rank ) {
				return ( $rank[ $p['status'] ] - $rank[ $q['status'] ] ) ?: strcmp( $p['name'], $q['name'] );
			}
		);
		return $out;
	}

	public static function deep_check( $table ) {
		if ( ! in_array( $table, DBS_Backup::tables(), true ) ) {
			return new WP_Error( 'dbs_cmp', 'جدول نامعتبر است.' );
		}
		@set_time_limit( 0 );
		return DBS_Backup::digest_table( $table );
	}

	/* ------------------------------------------------------------------ *
	 * Search & replace (serialized-data safe)
	 * ------------------------------------------------------------------ */

	private static function swap( $str, $s, $r, &$c ) {
		$n   = 0;
		$out = str_replace( $s, $r, $str, $n );
		$c  += $n;
		if ( false !== strpos( $s, '/' ) ) { // JSON-escaped slashes.
			$n2  = 0;
			$out = str_replace( str_replace( '/', '\\/', $s ), str_replace( '/', '\\/', $r ), $out, $n2 );
			$c  += $n2;
		}
		return $out;
	}

	private static function walk( $d, $s, $r, &$c ) {
		if ( is_string( $d ) ) {
			if ( is_serialized( $d ) ) {
				$un = @unserialize( $d );
				if ( false !== $un || 'b:0;' === trim( $d ) ) {
					$c0  = $c;
					$new = self::walk( $un, $s, $r, $c );
					return ( $c > $c0 ) ? serialize( $new ) : $d;
				}
			}
			return self::swap( $d, $s, $r, $c );
		}
		if ( is_array( $d ) ) {
			foreach ( $d as $k => $v ) {
				$d[ $k ] = self::walk( $v, $s, $r, $c );
			}
			return $d;
		}
		if ( is_object( $d ) ) {
			foreach ( get_object_vars( $d ) as $k => $v ) {
				$d->$k = self::walk( $v, $s, $r, $c );
			}
		}
		return $d;
	}

	public static function replace_value( $data, $s, $r, &$count ) {
		$c   = 0;
		$out = self::walk( $data, $s, $r, $c );
		$count += $c;
		return $out;
	}

	public static function sr_tables() {
		return DBS_Backup::tables();
	}

	private static function sr_meta( $table ) {
		global $wpdb;
		$q    = str_replace( '`', '``', $table );
		$cols = array();
		$pk   = '';
		foreach ( (array) $wpdb->get_results( "SHOW COLUMNS FROM `{$q}`", ARRAY_A ) as $c ) {
			if ( preg_match( '/char|text|json/i', $c['Type'] ) && 'guid' !== $c['Field'] ) {
				$cols[] = $c['Field'];
			}
		}
		$keys = (array) $wpdb->get_results( "SHOW KEYS FROM `{$q}` WHERE Key_name = 'PRIMARY'", ARRAY_A );
		if ( 1 === count( $keys ) ) {
			foreach ( (array) $wpdb->get_results( "SHOW COLUMNS FROM `{$q}`", ARRAY_A ) as $c ) {
				if ( $c['Field'] === $keys[0]['Column_name'] && preg_match( '/int/i', $c['Type'] ) ) {
					$pk = $c['Field'];
				}
			}
		}
		return array( 'cols' => $cols, 'pk' => $pk );
	}

	public static function sr_step( $search, $replace, $state, $dry ) {
		global $wpdb;
		if ( '' === $search ) {
			return new WP_Error( 'dbs_sr', 'عبارت جستجو خالی است.' );
		}
		$tables  = (array) $state['tables'];
		$i       = (int) $state['i'];
		$last    = isset( $state['last'] ) ? $state['last'] : null;
		$cells   = (int) $state['cells'];
		$rowsch  = (int) $state['rows'];
		$scanned = (int) $state['scanned'];
		$skipped = isset( $state['skipped'] ) ? (array) $state['skipped'] : array();
		$t0      = microtime( true );
		$esc     = ( false !== strpos( $search, '/' ) ) ? str_replace( '/', '\\/', $search ) : '';

		DBS_Activity::$suppress = true;
		try {
			while ( $i < count( $tables ) && microtime( true ) - $t0 < 6 ) {
				$table = $tables[ $i ];
				$q     = str_replace( '`', '``', $table );
				$meta  = self::sr_meta( $table );
				if ( '' === $meta['pk'] || ! $meta['cols'] ) {
					$skipped[] = $table;
					$i++;
					$last = null;
					continue;
				}
				$pk    = $meta['pk'];
				$sel   = '`' . implode( '`,`', array_map( function ( $x ) {
					return str_replace( '`', '``', $x );
				}, array_merge( array( $pk ), $meta['cols'] ) ) ) . '`';
				$where = '';
				if ( null !== $last && '' !== $last ) {
					if ( ! preg_match( '/^-?\d+$/', (string) $last ) ) {
						$last = null;
					} else {
						$where = ' WHERE `' . str_replace( '`', '``', $pk ) . '` > ' . $last;
					}
				}
				$rows = $wpdb->get_results( "SELECT {$sel} FROM `{$q}`{$where} ORDER BY `" . str_replace( '`', '``', $pk ) . '` ASC LIMIT 200', ARRAY_A );
				if ( empty( $rows ) ) {
					$i++;
					$last = null;
					continue;
				}
				foreach ( $rows as $row ) {
					$scanned++;
					$upd = array();
					foreach ( $meta['cols'] as $c ) {
						$v = $row[ $c ];
						if ( null === $v || '' === $v || ( false === strpos( $v, $search ) && ( '' === $esc || false === strpos( $v, $esc ) ) ) ) {
							continue;
						}
						$cnt = 0;
						$nv  = self::replace_value( $v, $search, $replace, $cnt );
						if ( $cnt > 0 && $nv !== $v ) {
							$cells++;
							$upd[ $c ] = $nv;
						}
					}
					if ( $upd ) {
						$rowsch++;
						if ( ! $dry ) {
							$wpdb->update( $table, $upd, array( $pk => $row[ $pk ] ) );
						}
					}
				}
				$lastrow = end( $rows );
				$last    = (string) $lastrow[ $pk ];
				$wpdb->flush();
			}
		} finally {
			DBS_Activity::$suppress = false;
		}

		$done = ( $i >= count( $tables ) );
		if ( $done && ! $dry && $cells ) {
			DBS_Activity::record(
				array(
					'category'    => 'tools',
					'action'      => 'search_replace',
					'severity'    => 'warning',
					'summary'     => 'جستجو و جایگزینی در دیتابیس: «' . DBS_Inspect::cut( $search, 60 ) . '» ← «' . DBS_Inspect::cut( $replace, 60 ) . '» (' . $cells . ' سلول در ' . $rowsch . ' ردیف)',
					'object_type' => 'database',
					'actor_type'  => 'plugin',
					'actor_slug'  => 'db-sentinel',
				)
			);
		}
		return array(
			'state'   => array( 'tables' => $tables, 'i' => $i, 'last' => $last, 'cells' => $cells, 'rows' => $rowsch, 'scanned' => $scanned, 'skipped' => $skipped ),
			'done'    => $done,
			'percent' => $tables ? round( min( 100, $i / count( $tables ) * 100 ), 1 ) : 100,
			'table'   => ( $i < count( $tables ) ) ? $tables[ $i ] : '',
		);
	}

	/* ------------------------------------------------------------------ *
	 * Security scanner
	 * ------------------------------------------------------------------ */

	private static $phases = array( 'posts', 'options', 'meta', 'users' );

	private static function snippet( $text, $pos, $len = 170 ) {
		$start = max( 0, $pos - 40 );
		$s     = substr( $text, $start, $len );
		return DBS_Inspect::cut( preg_replace( '/\s+/', ' ', $s ), $len );
	}

	private static function analyze( $text ) {
		$out = array();
		if ( ! is_string( $text ) || '' === $text ) {
			return $out;
		}
		if ( strlen( $text ) > 1500000 ) {
			$text = substr( $text, 0, 1500000 );
		}
		foreach ( DBS_Inspect::extract( $text ) as $it ) {
			if ( ! empty( $it['obf'] ) ) {
				$out[] = array( 'sev' => 'danger', 'rule' => 'اسکریپت مبهم‌سازی‌شده', 'snippet' => $it['label'] );
			} elseif ( ! empty( $it['ad'] ) ) {
				$out[] = array( 'sev' => 'notice', 'rule' => 'کد تبلیغاتی', 'snippet' => $it['label'] );
			} elseif ( 'inline' === $it['kind'] && preg_match( '/location\s*(?:\.href|\.replace|\.assign)?\s*=|location\.replace\(/i', $it['label'] ) ) {
				$out[] = array( 'sev' => 'warning', 'rule' => 'اسکریپت ریدایرکت', 'snippet' => $it['label'] );
			}
		}
		if ( preg_match( '/<iframe[^>]*(?:width=["\']?0|height=["\']?0|display\s*:\s*none|visibility\s*:\s*hidden|left\s*:\s*-\d{3,})/i', $text, $m, PREG_OFFSET_CAPTURE ) ) {
			$out[] = array( 'sev' => 'danger', 'rule' => 'iframe مخفی', 'snippet' => self::snippet( $text, $m[0][1] ) );
		}
		if ( preg_match( '/eval\s*\(\s*(?:base64_decode|gzinflate|str_rot13|gzuncompress)/i', $text, $m, PREG_OFFSET_CAPTURE ) ) {
			$out[] = array( 'sev' => 'danger', 'rule' => 'اجرای کد رمزشده (eval)', 'snippet' => self::snippet( $text, $m[0][1] ) );
		}
		if ( preg_match( '/document\.write\s*\(\s*(?:unescape|atob)/i', $text, $m, PREG_OFFSET_CAPTURE ) ) {
			$out[] = array( 'sev' => 'danger', 'rule' => 'document.write با کد رمزشده', 'snippet' => self::snippet( $text, $m[0][1] ) );
		}
		if ( preg_match( '/fromCharCode\s*\((?:\s*\d+\s*,){20,}/i', $text, $m, PREG_OFFSET_CAPTURE ) ) {
			$out[] = array( 'sev' => 'danger', 'rule' => 'رشته‌ی کدشده‌ی طولانی (fromCharCode)', 'snippet' => self::snippet( $text, $m[0][1] ) );
		}
		if ( preg_match_all( '/display\s*:\s*none[^>]*>(.{0,4000}?)<\/(?:div|span|p|ul)>/is', $text, $mm, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $mm[1] as $blk ) {
				if ( preg_match_all( '/<a\s[^>]*href/i', $blk[0] ) >= 5 ) {
					$out[] = array( 'sev' => 'warning', 'rule' => 'بلوک لینک‌های مخفی (احتمال اسپم سئو)', 'snippet' => self::snippet( $text, $blk[1] ) );
					break;
				}
			}
		}
		return $out;
	}

	/**
	 * One step of the scan. State: phase, last (id window start), scanned.
	 */
	public static function scan_step( $st ) {
		global $wpdb;
		$phase = isset( $st['phase'] ) && in_array( $st['phase'], self::$phases, true ) ? $st['phase'] : 'posts';
		$last  = isset( $st['last'] ) ? (int) $st['last'] : 0;
		$scan  = isset( $st['scanned'] ) ? (int) $st['scanned'] : 0;
		$win   = 4000;
		$found = array();
		$like  = "(%1\$s LIKE '%%<script%%' OR %1\$s LIKE '%%<iframe%%' OR %1\$s LIKE '%%eval(%%' OR %1\$s LIKE '%%display:none%%' OR %1\$s LIKE '%%display: none%%' OR %1\$s LIKE '%%document.write%%' OR %1\$s LIKE '%%fromCharCode%%')";
		$idx   = array_search( $phase, self::$phases, true );

		if ( 'users' === $phase ) {
			foreach ( get_users( array( 'role' => 'administrator', 'number' => 100 ) ) as $u ) {
				$days    = (int) floor( ( time() - strtotime( $u->user_registered . ' UTC' ) ) / 86400 );
				$found[] = array(
					'sev'     => ( $days <= 14 ) ? 'warning' : 'info',
					'rule'    => 'حساب مدیر کل',
					'where'   => array( 'type' => 'user', 'id' => $u->ID, 'label' => $u->user_login, 'url' => get_edit_user_link( $u->ID ) ),
					'snippet' => 'ثبت‌نام: ' . $days . ' روز پیش' . ( $days <= 14 ? ' — تازه ساخته شده' : '' ),
				);
			}
			return array( 'state' => array( 'phase' => 'users', 'last' => 0, 'scanned' => $scan ), 'findings' => $found, 'done' => true, 'percent' => 100 );
		}

		if ( 'posts' === $phase ) {
			$max  = (int) $wpdb->get_var( "SELECT MAX(ID) FROM {$wpdb->posts}" );
			$cond = sprintf( $like, 'post_content' );
			$sql  = "SELECT ID, post_title, post_type, post_status, post_content FROM {$wpdb->posts} WHERE ID > " . (int) $last . ' AND ID <= ' . (int) ( $last + $win ) . " AND post_type NOT IN ('revision','auto-draft') AND {$cond}";
			foreach ( (array) $wpdb->get_results( $sql, ARRAY_A ) as $r ) {
				foreach ( self::analyze( $r['post_content'] ) as $f ) {
					$f['where'] = array( 'type' => 'post', 'id' => (int) $r['ID'], 'label' => ( $r['post_title'] ? DBS_Inspect::cut( $r['post_title'], 60 ) : '(بدون عنوان)' ) . ' [' . $r['post_type'] . ']', 'url' => get_edit_post_link( (int) $r['ID'], 'raw' ) );
					$found[]    = $f;
				}
			}
		} elseif ( 'options' === $phase ) {
			$max  = (int) $wpdb->get_var( "SELECT MAX(option_id) FROM {$wpdb->options}" );
			$cond = sprintf( $like, 'option_value' );
			$sql  = "SELECT option_id, option_name, LEFT(option_value, 1500000) AS v FROM {$wpdb->options} WHERE option_id > " . (int) $last . ' AND option_id <= ' . (int) ( $last + $win ) . " AND option_name NOT LIKE '\\_transient%' AND option_name NOT LIKE '\\_site\\_transient%' AND {$cond}";
			foreach ( (array) $wpdb->get_results( $sql, ARRAY_A ) as $r ) {
				foreach ( self::analyze( $r['v'] ) as $f ) {
					$f['where'] = array( 'type' => 'option', 'id' => (int) $r['option_id'], 'label' => $r['option_name'], 'url' => '' );
					$found[]    = $f;
				}
			}
		} else {
			$max  = (int) $wpdb->get_var( "SELECT MAX(meta_id) FROM {$wpdb->postmeta}" );
			$cond = sprintf( $like, 'meta_value' );
			$sql  = "SELECT meta_id, post_id, meta_key, LEFT(meta_value, 1500000) AS v FROM {$wpdb->postmeta} WHERE meta_id > " . (int) $last . ' AND meta_id <= ' . (int) ( $last + $win ) . " AND {$cond}";
			foreach ( (array) $wpdb->get_results( $sql, ARRAY_A ) as $r ) {
				foreach ( self::analyze( $r['v'] ) as $f ) {
					$f['where'] = array( 'type' => 'meta', 'id' => (int) $r['post_id'], 'label' => $r['meta_key'] . ' (#' . $r['post_id'] . ')', 'url' => get_edit_post_link( (int) $r['post_id'], 'raw' ) );
					$found[]    = $f;
				}
			}
		}

		$scan += $win;
		$next  = $last + $win;
		$fin   = ( $next >= $max );
		if ( $fin ) {
			$phase = self::$phases[ $idx + 1 ];
			$next  = 0;
		}
		$pct = round( ( ( $idx + ( $fin ? 1 : min( 1, $next / max( 1, $max ) ) ) ) / 4 ) * 100, 1 );
		return array( 'state' => array( 'phase' => $phase, 'last' => $next, 'scanned' => $scan ), 'findings' => $found, 'done' => false, 'percent' => $pct );
	}
}
