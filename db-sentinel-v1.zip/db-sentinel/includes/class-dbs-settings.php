<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin settings.
 *
 * Non-secret values live in one option AND in <backup dir>/settings.json. Secrets (S3 keys,
 * FTP password, Telegram token, encryption passphrase) are stored ONLY in the settings file
 * inside the protected backup directory, so they never end up inside database backups and
 * they survive a database restore.
 */
class DBS_Settings {

	const OPT = 'dbs_settings';

	public static $secrets = array( 's3_secret', 'ftp_pass', 'tg_token', 'remote_pass' );

	private static $cache = null;

	public static function defaults() {
		return array(
			'interval_hours'      => 12,
			'retention_hours'     => 48,
			'compress'            => 1,
			'exclude_tables'      => '',
			'disk_guard'          => 1,
			'pre_update_snapshot' => 1,
			'auto_verify'         => 0,
			'reauth'              => 1,
			'cron_key'            => '',

			'log_events'          => 1,
			'log_sql'             => 1,
			'log_sql_frontend'    => 0,
			'log_retention_days'  => 30,
			'log_max_rows'        => 100000,
			'ignore_patterns'     => '',
			'delete_on_uninstall' => 0,

			'notify_email_on'     => 1,
			'notify_email_to'     => '',
			'notify_telegram_on'  => 0,
			'tg_token'            => '',
			'tg_chat'             => '',
			'tg_api'              => 'https://api.telegram.org',
			'notify_webhook_on'   => 0,
			'webhook_url'         => '',
			'notify_danger'       => 1,
			'notify_fail'         => 1,
			'notify_missed'       => 1,
			'notify_weekly'       => 0,

			'remote_driver'       => '',
			'remote_auto'         => 1,
			'remote_encrypt'      => 0,
			'remote_pass'         => '',
			'remote_daily'        => 7,
			'remote_weekly'       => 4,
			's3_endpoint'         => '',
			's3_region'           => 'us-east-1',
			's3_bucket'           => '',
			's3_key'              => '',
			's3_secret'           => '',
			's3_prefix'           => 'db-sentinel',
			's3_pathstyle'        => 1,
			'ftp_host'            => '',
			'ftp_port'            => 21,
			'ftp_user'            => '',
			'ftp_pass'            => '',
			'ftp_dir'             => '/db-sentinel',
			'ftp_ssl'             => 0,
			'ftp_passive'         => 1,
		);
	}

	private static function file() {
		$dir = dbs_backup_dir( false );
		return $dir ? $dir . '/settings.json' : '';
	}

	public static function all() {
		if ( null === self::$cache ) {
			$saved = get_option( self::OPT, array() );
			$data  = is_array( $saved ) ? $saved : array();
			$f     = self::file();
			if ( $f && is_file( $f ) ) {
				$j = json_decode( (string) @file_get_contents( $f ), true );
				if ( is_array( $j ) ) {
					$data = array_merge( $data, $j );
				}
			}
			self::$cache = wp_parse_args( $data, self::defaults() );
		}
		return self::$cache;
	}

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/** Settings for the browser: secrets are replaced by "<key>_set" flags. */
	public static function for_ui() {
		$all = self::all();
		foreach ( self::$secrets as $k ) {
			$all[ $k . '_set' ] = ( '' !== (string) $all[ $k ] );
			$all[ $k ]          = '';
		}
		unset( $all['cron_key'] );
		return $all;
	}

	public static function cron_key() {
		$k = (string) self::get( 'cron_key' );
		if ( strlen( $k ) < 20 ) {
			$k = bin2hex( random_bytes( 16 ) );
			self::persist( array_merge( self::all(), array( 'cron_key' => $k ) ) );
		}
		return $k;
	}

	private static function persist( $out ) {
		$public = array_diff_key( $out, array_flip( self::$secrets ) );
		update_option( self::OPT, $public, false );
		$f = self::file();
		if ( ! $f && DBS_Storage::dir( true ) ) {
			$f = self::file();
		}
		if ( $f ) {
			@file_put_contents( $f, wp_json_encode( $out ), LOCK_EX );
			@chmod( $f, 0600 );
		}
		self::$cache = $out;
	}

	public static function save( $data ) {
		$d   = self::defaults();
		$old = self::all();
		$in  = is_array( $data ) ? $data : array();
		$out = $old;

		$ints = array(
			'interval_hours'     => array( 1, 168 ),
			'retention_hours'    => array( 1, 720 ),
			'log_retention_days' => array( 1, 365 ),
			'log_max_rows'       => array( 1000, 2000000 ),
			'remote_daily'       => array( 0, 365 ),
			'remote_weekly'      => array( 0, 104 ),
			'ftp_port'           => array( 1, 65535 ),
		);
		foreach ( $ints as $k => $r ) {
			$v       = isset( $in[ $k ] ) ? (int) $in[ $k ] : (int) $d[ $k ];
			$out[ $k ] = min( $r[1], max( $r[0], $v ) );
		}
		$out['retention_hours'] = max( $out['retention_hours'], $out['interval_hours'] );

		$flags = array( 'compress', 'disk_guard', 'pre_update_snapshot', 'auto_verify', 'reauth', 'log_events', 'log_sql', 'log_sql_frontend', 'delete_on_uninstall', 'notify_email_on', 'notify_telegram_on', 'notify_webhook_on', 'notify_danger', 'notify_fail', 'notify_missed', 'notify_weekly', 'remote_auto', 'remote_encrypt', 's3_pathstyle', 'ftp_ssl', 'ftp_passive' );
		foreach ( $flags as $k ) {
			$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
		}

		$text = array( 'tg_chat', 's3_region', 's3_bucket', 's3_key', 's3_prefix', 'ftp_host', 'ftp_user', 'ftp_dir' );
		foreach ( $text as $k ) {
			$out[ $k ] = isset( $in[ $k ] ) ? trim( sanitize_text_field( $in[ $k ] ) ) : $old[ $k ];
		}
		foreach ( array( 'tg_api', 'webhook_url', 's3_endpoint' ) as $k ) {
			$out[ $k ] = isset( $in[ $k ] ) ? trim( esc_url_raw( $in[ $k ] ) ) : $old[ $k ];
		}
		$out['tg_api']          = $out['tg_api'] ? rtrim( $out['tg_api'], '/' ) : $d['tg_api'];
		$out['s3_endpoint']     = rtrim( $out['s3_endpoint'], '/' );
		$out['notify_email_to'] = ( isset( $in['notify_email_to'] ) && is_email( $in['notify_email_to'] ) ) ? sanitize_email( $in['notify_email_to'] ) : '';
		$out['remote_driver']   = ( isset( $in['remote_driver'] ) && in_array( $in['remote_driver'], array( 's3', 'ftp' ), true ) ) ? $in['remote_driver'] : '';

		foreach ( array( 'ignore_patterns', 'exclude_tables' ) as $k ) {
			$lines = isset( $in[ $k ] ) ? preg_split( '/\R/u', (string) $in[ $k ] ) : array();
			$clean = array();
			foreach ( (array) $lines as $line ) {
				$line = trim( wp_strip_all_tags( $line ) );
				if ( '' !== $line && strlen( $line ) <= 80 ) {
					$clean[] = $line;
				}
			}
			$out[ $k ] = implode( "\n", array_slice( array_unique( $clean ), 0, 100 ) );
		}

		// Secrets: missing or "__keep__" keeps the stored value; an empty string clears it.
		foreach ( self::$secrets as $k ) {
			if ( isset( $in[ $k ] ) && '__keep__' !== $in[ $k ] ) {
				$out[ $k ] = trim( (string) $in[ $k ] );
			}
		}

		self::persist( $out );
		return $out;
	}
}

/**
 * Backup files on disk. Metadata lives in a JSON file next to every dump (not in the
 * database), so the list survives a database restore.
 */
class DBS_Storage {

	const ID_RE = '/^\d{8}-\d{6}-[a-f0-9]{8}$/';

	public static function dir( $create = true ) {
		return dbs_backup_dir( $create );
	}

	public static function valid_id( $id ) {
		return is_string( $id ) && 1 === preg_match( self::ID_RE, $id );
	}

	public static function new_id() {
		return gmdate( 'Ymd-His' ) . '-' . bin2hex( random_bytes( 4 ) );
	}

	public static function all() {
		$dir = self::dir( false );
		if ( ! $dir ) {
			return array();
		}
		$items = @scandir( $dir );
		if ( ! $items ) {
			return array();
		}
		$out = array();
		foreach ( $items as $name ) {
			if ( ! preg_match( '/^dbs-(\d{8}-\d{6}-[a-f0-9]{8})\.json$/', $name ) ) {
				continue;
			}
			$raw  = @file_get_contents( $dir . '/' . $name );
			$meta = $raw ? json_decode( $raw, true ) : null;
			if ( ! is_array( $meta ) || empty( $meta['id'] ) || empty( $meta['file'] ) ) {
				continue;
			}
			if ( ! is_file( $dir . '/' . $meta['file'] ) ) {
				continue;
			}
			$out[] = $meta;
		}
		usort(
			$out,
			function ( $a, $b ) {
				return (int) $b['created'] - (int) $a['created'];
			}
		);
		return $out;
	}

	public static function get( $id ) {
		if ( ! self::valid_id( $id ) ) {
			return null;
		}
		foreach ( self::all() as $meta ) {
			if ( $meta['id'] === $id ) {
				return $meta;
			}
		}
		return null;
	}

	public static function path( $meta ) {
		return self::dir( false ) . '/' . basename( $meta['file'] );
	}

	public static function update_meta( $id, $patch ) {
		$dir = self::dir( false );
		if ( ! $dir || ! self::valid_id( $id ) ) {
			return null;
		}
		$p = $dir . '/dbs-' . $id . '.json';
		$m = json_decode( (string) @file_get_contents( $p ), true );
		if ( ! is_array( $m ) ) {
			return null;
		}
		$m = array_merge( $m, $patch );
		file_put_contents( $p, wp_json_encode( $m ), LOCK_EX );
		return $m;
	}

	public static function delete( $id ) {
		$meta = self::get( $id );
		if ( ! $meta ) {
			return false;
		}
		$dir = self::dir( false );
		@unlink( $dir . '/' . basename( $meta['file'] ) );
		@unlink( $dir . '/dbs-' . $id . '.json' );
		return true;
	}

	/**
	 * Remove backups older than the retention window. The newest backup and locked
	 * backups are always kept.
	 */
	public static function prune() {
		$retention = (int) DBS_Settings::get( 'retention_hours' ) * 3600;
		$cut       = time() - $retention;
		$deleted   = array();
		foreach ( self::all() as $i => $meta ) {
			if ( 0 === $i || ! empty( $meta['locked'] ) ) {
				continue;
			}
			if ( (int) $meta['created'] < $cut ) {
				self::delete( $meta['id'] );
				$deleted[] = $meta['id'];
			}
		}
		self::cleanup_temp();
		return $deleted;
	}

	public static function cleanup_temp() {
		$dir = self::dir( false );
		if ( ! $dir ) {
			return;
		}
		$items = @scandir( $dir );
		if ( ! $items ) {
			return;
		}
		foreach ( $items as $name ) {
			$path = $dir . '/' . $name;
			if ( ! is_file( $path ) ) {
				continue;
			}
			$age = time() - (int) @filemtime( $path );
			if ( preg_match( '/\.(tmp|part|idx)$/', $name ) && $age > 7200 ) {
				@unlink( $path );
			} elseif ( preg_match( '/^restore-[a-z0-9]+\.(sql|json)$/i', $name ) && $age > 86400 ) {
				@unlink( $path );
			}
		}
	}

	/**
	 * Per-table info (rows / checksum). Old backups without it are indexed once by
	 * scanning the file, and the result is cached in the metadata.
	 */
	public static function table_info( $meta ) {
		if ( ! empty( $meta['tables_info'] ) && is_array( $meta['tables_info'] ) ) {
			return $meta['tables_info'];
		}
		$gz   = ! empty( $meta['compressed'] );
		$path = self::path( $meta );
		$h    = $gz ? @gzopen( $path, 'rb' ) : @fopen( $path, 'rb' );
		if ( ! $h ) {
			return array();
		}
		$info = array();
		$cur  = null;
		while ( false !== ( $line = DBS_Sql::read_line( $h, $gz ) ) ) {
			if ( 0 === strncmp( $line, 'DROP TABLE IF EXISTS `', 22 ) ) {
				if ( preg_match( '/^DROP TABLE IF EXISTS `((?:[^`]|``)+)`;/', $line, $m ) ) {
					$cur          = str_replace( '``', '`', $m[1] );
					$info[ $cur ] = array( 'rows' => 0, 'crc' => '' );
				}
			} elseif ( null !== $cur && 0 === strncmp( $line, 'INSERT INTO `', 13 ) ) {
				$info[ $cur ]['rows'] += substr_count( $line, '),(' ) + 1;
			}
		}
		$gz ? gzclose( $h ) : fclose( $h );
		self::update_meta( $meta['id'], array( 'tables_info' => $info, 'rows_exact' => false ) );
		return $info;
	}
}
