<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Alerts to email, Telegram and a generic webhook.
 */
class DBS_Notify {

	private static function site() {
		return (string) wp_parse_url( home_url(), PHP_URL_HOST );
	}

	/**
	 * @param string $kind   danger | fail | missed | weekly | anomaly | test
	 * @param string $title
	 * @param array  $lines
	 * @param bool   $wait   Wait for the HTTP calls (used by the "test" button).
	 * @return array Per-channel results (only meaningful when $wait is true).
	 */
	public static function send( $kind, $title, $lines = array(), $wait = false ) {
		$s = DBS_Settings::all();
		$flag = array(
			'danger'  => 'notify_danger',
			'anomaly' => 'notify_danger',
			'fail'    => 'notify_fail',
			'missed'  => 'notify_missed',
			'weekly'  => 'notify_weekly',
		);
		if ( 'test' !== $kind && ( ! isset( $flag[ $kind ] ) || empty( $s[ $flag[ $kind ] ] ) ) ) {
			return array();
		}

		$text = '[' . self::site() . '] ' . $title;
		if ( $lines ) {
			$text .= "\n" . implode( "\n", array_map( 'wp_strip_all_tags', $lines ) );
		}
		$text = DBS_Inspect::cut( $text, 3500 );
		$res  = array();

		if ( ! empty( $s['notify_email_on'] ) ) {
			$to = $s['notify_email_to'] ? $s['notify_email_to'] : get_option( 'admin_email' );
			if ( $to ) {
				$ok           = wp_mail( $to, '[' . self::site() . '] ' . $title, $text );
				$res['email'] = $ok ? true : 'ارسال ایمیل ناموفق بود (تنظیمات ایمیل سرور را بررسی کنید).';
			}
		}
		if ( ! empty( $s['notify_telegram_on'] ) && $s['tg_token'] && $s['tg_chat'] ) {
			$r = wp_remote_post(
				$s['tg_api'] . '/bot' . $s['tg_token'] . '/sendMessage',
				array(
					'timeout'  => $wait ? 15 : 3,
					'blocking' => $wait,
					'body'     => array( 'chat_id' => $s['tg_chat'], 'text' => $text ),
				)
			);
			if ( $wait ) {
				if ( is_wp_error( $r ) ) {
					$res['telegram'] = $r->get_error_message();
				} else {
					$code            = (int) wp_remote_retrieve_response_code( $r );
					$res['telegram'] = ( 200 === $code ) ? true : 'HTTP ' . $code . ' ' . wp_strip_all_tags( DBS_Inspect::cut( wp_remote_retrieve_body( $r ), 160 ) );
				}
			}
		}
		if ( ! empty( $s['notify_webhook_on'] ) && $s['webhook_url'] ) {
			$r = wp_remote_post(
				$s['webhook_url'],
				array(
					'timeout'  => $wait ? 15 : 3,
					'blocking' => $wait,
					'headers'  => array( 'Content-Type' => 'application/json' ),
					'body'     => wp_json_encode( array( 'site' => self::site(), 'kind' => $kind, 'title' => $title, 'lines' => $lines, 'time' => gmdate( 'c' ) ) ),
				)
			);
			if ( $wait ) {
				$res['webhook'] = is_wp_error( $r ) ? $r->get_error_message() : ( ( (int) wp_remote_retrieve_response_code( $r ) < 300 ) ? true : 'HTTP ' . (int) wp_remote_retrieve_response_code( $r ) );
			}
		}
		return $res;
	}

	/** Called with the dangerous events that were just written to the log. */
	public static function danger( $rows ) {
		if ( ! $rows || get_transient( 'dbs_thr_danger' ) ) {
			return;
		}
		set_transient( 'dbs_thr_danger', 1, 300 );
		$lines = array();
		foreach ( array_slice( $rows, 0, 6 ) as $r ) {
			$who     = ! empty( $r['user_login'] ) ? $r['user_login'] : 'سیستم/ناشناس';
			$lines[] = '• ' . DBS_Inspect::cut( $r['summary'], 220 ) . ' — ' . $who . ' / ' . DBS_Names::actor( $r['actor_type'], $r['actor_slug'] );
		}
		if ( count( $rows ) > 6 ) {
			$lines[] = 'و ' . ( count( $rows ) - 6 ) . ' مورد دیگر…';
		}
		self::send( 'danger', count( $rows ) . ' تغییر با سطح «خطر» در دیتابیس', $lines );
	}

	public static function weekly() {
		$since = time() - 7 * 86400;
		$c     = DBS_Activity::count_since( $since );
		$lines = array(
			'تعداد بکاپ‌های موجود: ' . count( DBS_Storage::all() ),
			'تغییرات ثبت‌شده در هفته‌ی اخیر: ' . $c['total'] . ' (مهم: ' . $c['important'] . ')',
		);
		foreach ( DBS_Activity::top_users( $since, 3 ) as $u ) {
			$lines[] = 'کاربر: ' . ( $u['login'] ? $u['login'] : 'سیستم/ناشناس' ) . ' — ' . $u['c'] . ' تغییر';
		}
		foreach ( DBS_Activity::top_actors( $since, 3 ) as $a ) {
			$lines[] = 'افزونه/بخش: ' . $a['name'] . ' — ' . $a['c'];
		}
		self::send( 'weekly', 'گزارش هفتگی نگهبان دیتابیس', $lines );
	}

	/** Hourly maintenance: missed backups, weekly digest, retries, verification. */
	public static function watchdog() {
		$s    = DBS_Settings::all();
		$list = DBS_Storage::all();
		$last = $list ? (int) $list[0]['created'] : 0;

		$limit = (int) $s['interval_hours'] * 3600 * 1.5 + 1800;
		if ( $last && time() - $last > $limit && time() - (int) get_option( 'dbs_missed_at', 0 ) > 6 * 3600 ) {
			update_option( 'dbs_missed_at', time(), false );
			self::send( 'missed', 'بکاپ به‌موقع گرفته نشد', array( 'آخرین بکاپ: ' . human_time_diff( $last ) . ' پیش', 'زمان‌بند وردپرس (WP-Cron) را بررسی کنید.' ) );
		}

		if ( ! empty( $s['notify_weekly'] ) && time() - (int) get_option( 'dbs_weekly_at', 0 ) > 7 * 86400 - 3600 ) {
			update_option( 'dbs_weekly_at', time(), false );
			self::weekly();
		}

		if ( DBS_Remote::auto_ready() ) {
			foreach ( array_slice( $list, 0, 3 ) as $m ) {
				if ( empty( $m['remote']['ok'] ) && ( empty( $m['remote']['ts'] ) || time() - (int) $m['remote']['ts'] > 3600 ) ) {
					DBS_Remote::upload( $m );
					break;
				}
			}
		}

		if ( ! empty( $s['auto_verify'] ) && time() - (int) get_option( 'dbs_verify_at', 0 ) > 86400 ) {
			foreach ( $list as $m ) {
				if ( empty( $m['verified'] ) ) {
					update_option( 'dbs_verify_at', time(), false );
					DBS_Restore::verify_sync( $m['id'] );
					break;
				}
			}
		}

		DBS_Activity::prune();
		DBS_Storage::cleanup_temp();
	}
}

/**
 * Rate based anomaly rules on top of the audit log.
 */
class DBS_Anomaly {

	public static function check( $rows ) {
		global $wpdb;
		$del = 0;
		$usr = 0;
		foreach ( $rows as $r ) {
			if ( 'post' === $r['category'] && in_array( $r['action'], array( 'deleted', 'trashed' ), true ) ) {
				$del++;
			}
			if ( 'user' === $r['category'] && 'created' === $r['action'] ) {
				$usr++;
			}
		}
		$t   = DBS_Activity::table();
		$cut = gmdate( 'Y-m-d H:i:s', time() - 600 );
		if ( $del ) {
			$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$t}` WHERE category='post' AND action IN ('deleted','trashed') AND created_at >= %s", $cut ) );
			if ( $n >= 10 ) {
				self::fire( 'mass_delete', 'حذف گروهی نوشته‌ها', $n . ' نوشته یا برگه در ۱۰ دقیقه‌ی اخیر حذف یا به زباله‌دان منتقل شد.' );
			}
		}
		if ( $usr ) {
			$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$t}` WHERE category='user' AND action='created' AND created_at >= %s", $cut ) );
			if ( $n >= 3 ) {
				self::fire( 'mass_users', 'ساخت چند کاربر پشت‌سرهم', $n . ' کاربر جدید در ۱۰ دقیقه‌ی اخیر ساخته شد.' );
			}
		}
	}

	private static function fire( $key, $title, $text ) {
		$k = 'dbs_anomaly_' . $key;
		if ( time() - (int) get_option( $k, 0 ) < 1800 ) {
			return;
		}
		update_option( $k, time(), false );
		DBS_Activity::record(
			array(
				'category'    => 'anomaly',
				'action'      => $key,
				'severity'    => 'danger',
				'summary'     => 'ناهنجاری: ' . $title . ' — ' . $text,
				'object_type' => 'anomaly',
				'actor_type'  => 'plugin',
				'actor_slug'  => 'db-sentinel',
			)
		);
		DBS_Notify::send( 'anomaly', 'ناهنجاری: ' . $title, array( $text ) );
	}
}
