<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manage DB Sentinel from the command line.
 *
 * ## EXAMPLES
 *
 *     wp sentinel backup
 *     wp sentinel list
 *     wp sentinel restore 20260921-101500-ab12cd34 --yes
 *     wp sentinel restore <id> --tables=wp_options,wp_posts --yes
 *     wp sentinel verify <id>
 *     wp sentinel remote-upload <id>
 *     wp sentinel scan
 */
class DBS_CLI {

	/**
	 * Create a database backup now.
	 */
	public function backup( $args, $assoc ) {
		$r = DBS_Backup::run( 'manual' );
		if ( is_wp_error( $r ) ) {
			WP_CLI::error( $r->get_error_message() );
		}
		WP_CLI::success( 'Backup created: ' . $r['id'] . ' (' . size_format( $r['size'] ) . ', ' . $r['tables'] . ' tables)' );
	}

	/**
	 * List backups.
	 */
	public function list_( $args, $assoc ) {
		$rows = array();
		foreach ( DBS_Storage::all() as $m ) {
			$rows[] = array(
				'id'      => $m['id'],
				'created' => gmdate( 'Y-m-d H:i:s', $m['created'] ) . ' UTC',
				'type'    => $m['type'],
				'size'    => size_format( $m['size'] ),
				'locked'  => ! empty( $m['locked'] ) ? 'yes' : '',
				'remote'  => ! empty( $m['remote']['ok'] ) ? 'yes' : '',
				'verified' => ! empty( $m['verified']['ok'] ) ? 'yes' : ( ! empty( $m['verified'] ) ? 'FAILED' : '' ),
			);
		}
		WP_CLI\Utils\format_items( 'table', $rows, array( 'id', 'created', 'type', 'size', 'locked', 'remote', 'verified' ) );
	}

	/**
	 * Restore a backup (optionally only some tables).
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : Backup id.
	 *
	 * [--tables=<list>]
	 * : Comma separated table names for a partial restore.
	 *
	 * [--yes]
	 * : Do not ask for confirmation.
	 */
	public function restore( $args, $assoc ) {
		$id = $args[0];
		if ( ! DBS_Storage::get( $id ) ) {
			WP_CLI::error( 'Backup not found.' );
		}
		WP_CLI::confirm( 'This replaces the current database content. Continue?', $assoc );
		WP_CLI::log( 'Creating a safety backup first...' );
		$safe = DBS_Backup::run( 'pre_restore', array( 'for' => $id ) );
		if ( is_wp_error( $safe ) ) {
			WP_CLI::error( 'Safety backup failed: ' . $safe->get_error_message() );
		}
		$tables = ! empty( $assoc['tables'] ) ? array_map( 'trim', explode( ',', $assoc['tables'] ) ) : array();
		$job    = DBS_Restore::init_job( $id, array( 'tables' => $tables ) );
		if ( is_wp_error( $job ) ) {
			WP_CLI::error( $job->get_error_message() );
		}
		$r = DBS_Restore::run_sync( $job['job'] );
		DBS_Restore::abort( $job['job'] );
		if ( empty( $r['ok'] ) ) {
			WP_CLI::error( 'Restore failed: ' . ( isset( $r['error'] ) ? $r['error'] : 'unknown' ) . ' — safety backup: ' . $safe['id'] );
		}
		WP_CLI::success( 'Restore finished (' . $r['stmts'] . ' statements). Safety backup: ' . $safe['id'] );
	}

	/**
	 * Test-restore a backup into temporary tables and drop them again.
	 */
	public function verify( $args, $assoc ) {
		$id = isset( $args[0] ) ? $args[0] : '';
		if ( ! $id ) {
			$list = DBS_Storage::all();
			$id   = $list ? $list[0]['id'] : '';
		}
		$r = DBS_Restore::verify_sync( $id );
		if ( is_wp_error( $r ) ) {
			WP_CLI::error( $r->get_error_message() );
		}
		$v = isset( $r['verify'] ) ? $r['verify'] : array();
		if ( ! empty( $v['ok'] ) ) {
			WP_CLI::success( 'Backup is restorable (' . $v['checked'] . ' tables checked).' );
		}
		WP_CLI::error( 'Verification failed: ' . implode( '; ', isset( $v['mismatch'] ) ? $v['mismatch'] : array( 'unknown' ) ) );
	}

	/**
	 * Delete backups older than the retention window.
	 */
	public function prune( $args, $assoc ) {
		$d = DBS_Storage::prune();
		WP_CLI::success( count( $d ) . ' backup(s) deleted.' );
	}

	/**
	 * Upload a backup (default: the newest) to the configured remote storage.
	 *
	 * @subcommand remote-upload
	 */
	public function remote_upload( $args, $assoc ) {
		$id   = isset( $args[0] ) ? $args[0] : '';
		$meta = $id ? DBS_Storage::get( $id ) : ( DBS_Storage::all() ? DBS_Storage::all()[0] : null );
		if ( ! $meta ) {
			WP_CLI::error( 'Backup not found.' );
		}
		$r = DBS_Remote::upload( $meta );
		if ( is_wp_error( $r ) ) {
			WP_CLI::error( $r->get_error_message() );
		}
		WP_CLI::success( 'Uploaded.' );
	}

	/**
	 * Scan the database for injected scripts, hidden iframes and suspicious admins.
	 */
	public function scan( $args, $assoc ) {
		$st    = array( 'phase' => 'posts', 'last' => 0, 'scanned' => 0 );
		$total = 0;
		do {
			$r  = DBS_Tools::scan_step( $st );
			$st = $r['state'];
			foreach ( $r['findings'] as $f ) {
				$total++;
				WP_CLI::log( strtoupper( $f['sev'] ) . ' | ' . $f['rule'] . ' | ' . $f['where']['type'] . ' ' . $f['where']['label'] . ' | ' . $f['snippet'] );
			}
		} while ( empty( $r['done'] ) );
		WP_CLI::success( $total . ' finding(s).' );
	}
}
