<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBS_Admin {

	const SLUG = 'db-sentinel';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_ajax_dbs', array( __CLASS__, 'ajax' ) );
		add_action( 'admin_post_dbs_download', array( __CLASS__, 'download' ) );
		add_action( 'admin_post_dbs_csv', array( __CLASS__, 'csv' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( DBS_FILE ), array( __CLASS__, 'links' ) );
	}

	public static function links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">پنل نگهبان</a>' );
		return $links;
	}

	public static function menu() {
		add_menu_page( 'نگهبان دیتابیس', 'نگهبان دیتابیس', 'manage_options', self::SLUG, array( __CLASS__, 'page' ), 'dashicons-shield-alt', 81 );
	}

	public static function assets( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'dbs-admin', DBS_URL . 'assets/admin.css', array(), DBS_VERSION );
		wp_enqueue_script( 'dbs-admin', DBS_URL . 'assets/admin.js', array(), DBS_VERSION, true );

		$tz_name = wp_timezone_string();
		$cfg     = array(
			'ajax'     => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'dbs' ),
			'runner'   => DBS_Restore::runner_url(),
			'dl'       => admin_url( 'admin-post.php?action=dbs_download&_wpnonce=' . wp_create_nonce( 'dbs_dl' ) ),
			'csv'      => admin_url( 'admin-post.php?action=dbs_csv&_wpnonce=' . wp_create_nonce( 'dbs_dl' ) ),
			'now'      => time(),
			'tzName'   => ( '' !== $tz_name && '+' !== $tz_name[0] && '-' !== $tz_name[0] ) ? $tz_name : '',
			'tzOffset' => (int) wp_timezone()->getOffset( new DateTime( 'now', new DateTimeZone( 'UTC' ) ) ),
			'site'     => wp_parse_url( home_url(), PHP_URL_HOST ),
			'version'  => DBS_VERSION,
			'chunk'    => (int) min( wp_max_upload_size(), 8 * 1048576 ),
		);
		wp_add_inline_script( 'dbs-admin', 'window.DBS=' . wp_json_encode( $cfg ) . ';', 'before' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div class="wrap dbs-wrap"><h1 class="screen-reader-text">نگهبان دیتابیس</h1>';
		echo '<div id="dbs-app"><div class="dbs-boot">در حال بارگذاری نگهبان دیتابیس…</div></div>';
		echo '<noscript><p>برای استفاده از این صفحه جاوااسکریپت باید فعال باشد.</p></noscript></div>';
	}

	/* ------------------------------------------------------------------ *
	 * Helpers
	 * ------------------------------------------------------------------ */

	private static function fail( $msg, $code = 400, $extra = array() ) {
		wp_send_json_error( array_merge( array( 'message' => $msg ), $extra ), $code );
	}

	private static function req_json( $key ) {
		if ( empty( $_POST[ $key ] ) || ! is_string( $_POST[ $key ] ) ) {
			return array();
		}
		$d = json_decode( wp_unslash( $_POST[ $key ] ), true );
		return is_array( $d ) ? $d : array();
	}

	private static function req_id( $key = 'id' ) {
		$id = isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
		return DBS_Storage::valid_id( $id ) ? $id : '';
	}

	private static function req_str( $key ) {
		return isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
	}

	/** Sensitive actions ask for the password again (when enabled in settings). */
	private static function reauth() {
		if ( ! DBS_Settings::get( 'reauth' ) ) {
			return;
		}
		$u  = wp_get_current_user();
		$k  = 'dbs_pwfail_' . $u->ID;
		$n  = (int) get_transient( $k );
		if ( $n >= 5 ) {
			self::fail( 'تلاش‌های ناموفق زیاد بود؛ ۱۰ دقیقه بعد دوباره امتحان کنید.', 429, array( 'reauth' => true ) );
		}
		$pw = self::req_str( 'pw' );
		if ( '' === $pw || ! wp_check_password( $pw, $u->user_pass, $u->ID ) ) {
			set_transient( $k, $n + 1, 600 );
			self::fail( 'رمز عبور نادرست است.', 403, array( 'reauth' => true ) );
		}
		delete_transient( $k );
	}

	private static function wperr( $r ) {
		if ( is_wp_error( $r ) ) {
			self::fail( $r->get_error_message(), 500, array( 'code' => $r->get_error_code() ) );
		}
		return $r;
	}

	/* ------------------------------------------------------------------ *
	 * AJAX dispatcher
	 * ------------------------------------------------------------------ */

	public static function ajax() {
		if ( ! current_user_can( 'manage_options' ) ) {
			self::fail( 'دسترسی ندارید.', 403 );
		}
		check_ajax_referer( 'dbs', 'nonce' );

		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		try {
			switch ( $do ) {
				case 'overview':
					wp_send_json_success( self::overview() );
					break;

				case 'backups':
					wp_send_json_success( array( 'backups' => self::backups_ui() ) );
					break;

				case 'backup_now':
					$t    = self::req_str( 'type' );
					$type = in_array( $t, array( 'pre_restore', 'pre_tool' ), true ) ? $t : 'manual';
					if ( 'pre_restore' === $type ) {
						self::reauth();
					}
					$res  = self::wperr( DBS_Backup::run( $type, array( 'for' => self::req_str( 'for' ) ) ) );
					unset( $res['tables_info'] );
					wp_send_json_success( $res );
					break;

				case 'backup_delete':
					self::reauth();
					$id = self::req_id();
					if ( ! $id || ! DBS_Storage::delete( $id ) ) {
						self::fail( 'بکاپ پیدا نشد.', 404 );
					}
					DBS_Activity::record(
						array(
							'category'    => 'backup',
							'action'      => 'deleted',
							'severity'    => 'notice',
							'summary'     => 'یک بکاپ به صورت دستی حذف شد',
							'object_type' => 'backup',
							'object_id'   => $id,
						)
					);
					wp_send_json_success( array( 'deleted' => $id ) );
					break;

				case 'backup_lock':
					$id = self::req_id();
					if ( ! $id || ! DBS_Storage::get( $id ) ) {
						self::fail( 'بکاپ پیدا نشد.', 404 );
					}
					$m = DBS_Storage::update_meta(
						$id,
						array(
							'locked' => ! empty( $_POST['locked'] ),
							'note'   => DBS_Inspect::cut( sanitize_text_field( self::req_str( 'note' ) ), 200 ),
						)
					);
					wp_send_json_success( array( 'ok' => (bool) $m ) );
					break;

				case 'tables_of':
					$id   = self::req_id();
					$meta = $id ? DBS_Storage::get( $id ) : null;
					if ( ! $meta ) {
						self::fail( 'بکاپ پیدا نشد.', 404 );
					}
					$out = array();
					foreach ( DBS_Storage::table_info( $meta ) as $n => $i ) {
						$out[] = array( 'name' => $n, 'rows' => (int) $i['rows'] );
					}
					wp_send_json_success( array( 'tables' => $out, 'exact' => ! empty( $meta['rows_exact'] ) ) );
					break;

				case 'restore_init':
					self::reauth();
					$id = self::req_id();
					if ( ! $id ) {
						self::fail( 'شناسه بکاپ نامعتبر است.' );
					}
					$tables = array_map( 'strval', (array) self::req_json( 'tables' ) );
					wp_send_json_success( self::wperr( DBS_Restore::init_job( $id, array( 'tables' => $tables ) ) ) );
					break;

				case 'verify_init':
					$id = self::req_id();
					if ( ! $id ) {
						self::fail( 'شناسه بکاپ نامعتبر است.' );
					}
					wp_send_json_success( self::wperr( DBS_Restore::init_job( $id, array( 'mode' => 'verify' ) ) ) );
					break;

				case 'restore_abort':
					DBS_Restore::abort( self::req_str( 'job' ) );
					wp_send_json_success( array() );
					break;

				case 'changes_since':
					$id   = self::req_id();
					$meta = $id ? DBS_Storage::get( $id ) : null;
					if ( ! $meta ) {
						self::fail( 'بکاپ پیدا نشد.', 404 );
					}
					wp_send_json_success( self::changes_since( $meta ) );
					break;

				case 'compare':
					$a = self::req_id( 'a' );
					$b = ( 'live' === self::req_str( 'b' ) ) ? 'live' : self::req_id( 'b' );
					if ( ! $a || ! $b ) {
						self::fail( 'دو مورد را برای مقایسه انتخاب کنید.' );
					}
					wp_send_json_success( array( 'rows' => self::wperr( DBS_Tools::compare( $a, $b ) ) ) );
					break;

				case 'deep_check':
					wp_send_json_success( self::wperr( DBS_Tools::deep_check( self::req_str( 'table' ) ) ) );
					break;

				case 'activity':
					$f = self::clean_filters( self::req_json( 'f' ) );
					$o = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
					$l = isset( $_POST['limit'] ) ? (int) $_POST['limit'] : 40;
					wp_send_json_success( DBS_Activity::query( $f, $o, $l ) );
					break;

				case 'filters':
					wp_send_json_success( DBS_Activity::filter_options() );
					break;

				case 'undo':
					self::reauth();
					$r = DBS_Tools::undo( isset( $_POST['id'] ) ? (int) $_POST['id'] : 0, ! empty( $_POST['force'] ) );
					if ( is_wp_error( $r ) ) {
						self::fail( $r->get_error_message(), 409, array( 'code' => $r->get_error_code() ) );
					}
					wp_send_json_success( array( 'ok' => true ) );
					break;

				case 'insights':
					wp_send_json_success( self::insights( isset( $_POST['range'] ) ? (int) $_POST['range'] : 168 ) );
					break;

				case 'settings':
					wp_send_json_success( self::settings_payload() );
					break;

				case 'settings_save':
					DBS_Settings::save( self::req_json( 'data' ) );
					DBS_Plugin::reschedule();
					wp_send_json_success( array_merge( self::settings_payload(), array( 'next_run' => (int) wp_next_scheduled( DBS_Plugin::HOOK ) ) ) );
					break;

				case 'activity_clear':
					self::reauth();
					DBS_Activity::clear();
					wp_send_json_success( array() );
					break;

				case 'upload_chunk':
					self::upload_chunk();
					break;

				case 'upload_finish':
					self::upload_finish();
					break;

				case 'remote_test':
					self::wperr( DBS_Remote::test() );
					wp_send_json_success( array( 'ok' => true ) );
					break;

				case 'remote_list':
					wp_send_json_success( array( 'items' => self::wperr( DBS_Remote::items() ) ) );
					break;

				case 'remote_upload':
					$id   = self::req_id();
					$meta = $id ? DBS_Storage::get( $id ) : null;
					if ( ! $meta ) {
						self::fail( 'بکاپ پیدا نشد.', 404 );
					}
					self::wperr( DBS_Remote::upload( $meta ) );
					wp_send_json_success( array( 'ok' => true ) );
					break;

				case 'remote_import':
					$r = DBS_Remote::import( self::req_str( 'name' ), self::req_str( 'pass' ) );
					if ( is_wp_error( $r ) ) {
						self::fail( $r->get_error_message(), 400, array( 'need_pass' => 'dbs_pass' === $r->get_error_code() ) );
					}
					unset( $r['tables_info'] );
					wp_send_json_success( $r );
					break;

				case 'remote_delete':
					self::reauth();
					self::wperr( DBS_Remote::delete( self::req_str( 'name' ) ) );
					wp_send_json_success( array( 'ok' => true ) );
					break;

				case 'notify_test':
					wp_send_json_success( array( 'results' => DBS_Notify::send( 'test', 'آزمایش اعلان DB Sentinel', array( 'اگر این پیام را می‌بینید، اعلان‌ها درست کار می‌کنند.' ), true ) ) );
					break;

				case 'scan_step':
					wp_send_json_success( DBS_Tools::scan_step( self::req_json( 'state' ) ) );
					break;

				case 'sr_tables':
					wp_send_json_success( array( 'tables' => DBS_Tools::sr_tables() ) );
					break;

				case 'sr_step':
					$state  = self::req_json( 'state' );
					$valid  = DBS_Backup::tables();
					$state['tables'] = array_values( array_intersect( isset( $state['tables'] ) ? (array) $state['tables'] : array(), $valid ) );
					$state  = array_merge( array( 'i' => 0, 'last' => null, 'cells' => 0, 'rows' => 0, 'scanned' => 0, 'skipped' => array() ), $state );
					$r      = DBS_Tools::sr_step( self::req_str( 'search' ), self::req_str( 'replace' ), $state, ! empty( $_POST['dry'] ) );
					wp_send_json_success( self::wperr( $r ) );
					break;

				default:
					self::fail( 'درخواست نامعتبر.' );
			}
		} catch ( Throwable $e ) {
			self::fail( 'خطای داخلی: ' . $e->getMessage(), 500 );
		}
	}

	/* ------------------------------------------------------------------ *
	 * Uploads (chunked)
	 * ------------------------------------------------------------------ */

	private static function upload_chunk() {
		$uid = preg_replace( '/[^a-z0-9]/i', '', self::req_str( 'uid' ) );
		if ( strlen( $uid ) < 8 || strlen( $uid ) > 40 ) {
			self::fail( 'شناسه‌ی آپلود نامعتبر است.' );
		}
		$idx = isset( $_POST['index'] ) ? (int) $_POST['index'] : -1;
		if ( empty( $_FILES['chunk'] ) || UPLOAD_ERR_OK !== (int) $_FILES['chunk']['error'] ) {
			self::fail( 'دریافت تکه‌ی فایل ناموفق بود؛ مقدار upload_max_filesize و post_max_size سرور را بررسی کنید.' );
		}
		$dir = DBS_Storage::dir( true );
		if ( ! $dir || ! wp_is_writable( $dir ) ) {
			self::fail( 'پوشه‌ی بکاپ قابل نوشتن نیست.', 500 );
		}
		$part = $dir . '/upload-' . $uid . '.part';
		$ix   = $dir . '/upload-' . $uid . '.idx';
		if ( 0 === $idx ) {
			@unlink( $part );
			file_put_contents( $ix, '0' );
		}
		$next = is_file( $ix ) ? (int) file_get_contents( $ix ) : 0;
		if ( $idx !== $next ) {
			self::fail( 'ترتیب تکه‌ها به‌هم خورد؛ دوباره تلاش کنید.', 409, array( 'next' => $next ) );
		}
		if ( function_exists( 'disk_free_space' ) ) {
			$free = @disk_free_space( $dir );
			if ( false !== $free && $free < (int) $_FILES['chunk']['size'] * 4 + 20 * 1048576 ) {
				self::fail( 'فضای دیسک برای آپلود کافی نیست.', 507 );
			}
		}
		$in  = fopen( $_FILES['chunk']['tmp_name'], 'rb' );
		$out = fopen( $part, 'ab' );
		if ( ! $in || ! $out || false === stream_copy_to_stream( $in, $out ) ) {
			self::fail( 'ذخیره‌ی تکه‌ی فایل ناموفق بود.', 500 );
		}
		fclose( $in );
		fclose( $out );
		if ( filesize( $part ) > 8 * 1024 * 1048576 ) {
			@unlink( $part );
			self::fail( 'حجم فایل بیش از حد مجاز (۸ گیگابایت) است.' );
		}
		file_put_contents( $ix, (string) ( $idx + 1 ) );
		wp_send_json_success( array( 'next' => $idx + 1 ) );
	}

	private static function upload_finish() {
		$uid  = preg_replace( '/[^a-z0-9]/i', '', self::req_str( 'uid' ) );
		$dir  = DBS_Storage::dir( false );
		$part = $dir ? $dir . '/upload-' . $uid . '.part' : '';
		if ( ! $uid || ! $part || ! is_file( $part ) ) {
			self::fail( 'فایل آپلودشده پیدا نشد.', 404 );
		}
		$name = sanitize_file_name( self::req_str( 'name' ) );
		$res  = DBS_Import::register( $part, $name ? $name : 'upload.sql', 'uploaded', self::req_str( 'pass' ) );
		if ( is_wp_error( $res ) ) {
			if ( 'dbs_pass' !== $res->get_error_code() ) {
				@unlink( $part );
				@unlink( $dir . '/upload-' . $uid . '.idx' );
			}
			self::fail( $res->get_error_message(), 400, array( 'need_pass' => 'dbs_pass' === $res->get_error_code() ) );
		}
		@unlink( $part );
		@unlink( $dir . '/upload-' . $uid . '.idx' );
		unset( $res['tables_info'] );
		wp_send_json_success( $res );
	}

	/* ------------------------------------------------------------------ *
	 * Data builders
	 * ------------------------------------------------------------------ */

	private static function settings_payload() {
		return array(
			'settings' => DBS_Settings::for_ui(),
			'cron_url' => home_url( '/?dbs_cron=' . DBS_Settings::cron_key() ),
			'env'      => array(
				'openssl' => DBS_Crypt::available(),
				'curl'    => function_exists( 'curl_init' ),
				'ftp'     => function_exists( 'ftp_connect' ),
				'zlib'    => function_exists( 'gzopen' ),
			),
		);
	}

	private static function clean_filters( $f ) {
		$out = array();
		foreach ( array( 'q', 'kind', 'category', 'severity', 'user', 'actor', 'context' ) as $k ) {
			if ( isset( $f[ $k ] ) && is_string( $f[ $k ] ) && '' !== $f[ $k ] ) {
				$out[ $k ] = sanitize_text_field( $f[ $k ] );
			}
		}
		foreach ( array( 'id', 'since', 'until' ) as $k ) {
			if ( ! empty( $f[ $k ] ) ) {
				$out[ $k ] = (int) $f[ $k ];
			}
		}
		return $out;
	}

	private static function backups_ui() {
		$ret  = (int) DBS_Settings::get( 'retention_hours' ) * 3600;
		$list = DBS_Storage::all();
		foreach ( $list as &$b ) {
			$b['expires_at'] = (int) $b['created'] + $ret;
			$b['changes']    = DBS_Activity::count_since( $b['created'] );
			unset( $b['sha1'], $b['tables_info'] );
		}
		unset( $b );
		return $list;
	}

	private static function overview() {
		global $wpdb;
		$now = time();
		$s   = DBS_Settings::all();
		$ret = (int) $s['retention_hours'] * 3600;

		$list = self::backups_ui();
		$size = 0;
		foreach ( $list as $b ) {
			$size += (int) $b['size'];
		}

		$dir  = DBS_Storage::dir( false );
		$free = ( $dir && function_exists( 'disk_free_space' ) ) ? @disk_free_space( $dir ) : false;
		$dbsz = null;
		$sup  = $wpdb->suppress_errors( true );
		$q    = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = %s AND table_name LIKE %s',
				DB_NAME,
				$wpdb->esc_like( $wpdb->base_prefix ) . '%'
			)
		);
		$wpdb->suppress_errors( $sup );
		if ( null !== $q ) {
			$dbsz = (int) $q;
		}

		$c48 = DBS_Activity::count_since( $now - 172800 );

		return array(
			'now'        => $now,
			'settings'   => DBS_Settings::for_ui(),
			'next_run'   => (int) wp_next_scheduled( DBS_Plugin::HOOK ),
			'backups'    => $list,
			'totals'     => array(
				'count' => count( $list ),
				'size'  => $size,
			),
			'ticks'      => DBS_Activity::ticks( $now - $ret - 3600 ),
			'chart'      => DBS_Activity::buckets( $now - 172800, 'hour' ),
			'feed'       => DBS_Activity::query(
				array(
					'kind'     => 'event',
					'severity' => 'important',
					'since'    => $now - 7 * 86400,
				),
				0,
				8
			)['rows'],
			'top_users'  => DBS_Activity::top_users( $now - 172800, 6 ),
			'top_actors' => DBS_Activity::top_actors( $now - 172800, 6 ),
			'counts'     => array(
				'events48' => $c48['total'],
				'warn48'   => $c48['important'],
			),
			'remote'     => array(
				'configured' => DBS_Remote::configured(),
				'driver'     => $s['remote_driver'],
				'auto'       => (bool) $s['remote_auto'],
			),
			'health'     => array(
				'php'              => PHP_VERSION,
				'mysql'            => (string) $wpdb->db_version(),
				'gzip'             => function_exists( 'gzopen' ),
				'writable'         => $dir ? wp_is_writable( $dir ) : false,
				'dir_ok'           => (bool) $dir,
				'wp_cron_disabled' => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
				'disk_free'        => $free ? (int) $free : null,
				'db_size'          => $dbsz,
				'log_rows'         => DBS_Activity::total_rows(),
			),
		);
	}

	private static function changes_since( $meta ) {
		$since = (int) $meta['created'];
		$cnt   = DBS_Activity::count_since( $since );
		$res   = DBS_Activity::query( array( 'kind' => 'event', 'since' => $since ), 0, 60 );
		$top   = array();
		foreach ( $res['rows'] as $r ) {
			if ( 'backup' !== $r['category'] ) {
				$top[] = $r;
			}
		}
		usort(
			$top,
			function ( $a, $b ) {
				$rank = array( 'info' => 0, 'notice' => 1, 'warning' => 2, 'danger' => 3 );
				if ( $rank[ $a['severity'] ] !== $rank[ $b['severity'] ] ) {
					return $rank[ $b['severity'] ] - $rank[ $a['severity'] ];
				}
				return $b['ts'] - $a['ts'];
			}
		);
		return array(
			'since'     => $since,
			'total'     => $cnt['total'],
			'important' => $cnt['important'],
			'users'     => DBS_Activity::top_users( $since, 6 ),
			'actors'    => DBS_Activity::top_actors( $since, 6 ),
			'top'       => array_slice( $top, 0, 8 ),
		);
	}

	private static function insights( $range ) {
		$range = max( 1, min( 720, $range ) );
		$since = time() - $range * 3600;
		return array(
			'range'      => $range,
			'since'      => $since,
			'bucket'     => ( $range > 72 ) ? 'day' : 'hour',
			'buckets'    => DBS_Activity::buckets( $since, ( $range > 72 ) ? 'day' : 'hour' ),
			'users'      => DBS_Activity::top_users( $since, 10 ),
			'actors'     => DBS_Activity::top_actors( $since, 10 ),
			'tables'     => DBS_Activity::top_tables( $since, 10 ),
			'categories' => DBS_Activity::by_category( $since ),
			'severity'   => DBS_Activity::by_severity( $since ),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Downloads
	 * ------------------------------------------------------------------ */

	public static function download() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی ندارید.', 403 );
		}
		check_admin_referer( 'dbs_dl' );
		$id   = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( $_GET['id'] ) ) : '';
		$meta = DBS_Storage::get( $id );
		if ( ! $meta ) {
			wp_die( 'بکاپ پیدا نشد.', 404 );
		}
		$path = DBS_Storage::path( $meta );
		if ( ! is_file( $path ) ) {
			wp_die( 'فایل بکاپ پیدا نشد.', 404 );
		}
		@set_time_limit( 0 );
		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}
		$host = sanitize_file_name( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$name = $host . '-db-' . gmdate( 'Y-m-d-His', (int) $meta['created'] ) . ( $meta['compressed'] ? '.sql.gz' : '.sql' );
		nocache_headers();
		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		header( 'Content-Length: ' . filesize( $path ) );
		$fh = fopen( $path, 'rb' );
		while ( $fh && ! feof( $fh ) ) {
			echo fread( $fh, 1048576 ); // phpcs:ignore
			flush();
		}
		if ( $fh ) {
			fclose( $fh );
		}
		exit;
	}

	public static function csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی ندارید.', 403 );
		}
		check_admin_referer( 'dbs_dl' );
		$raw = isset( $_GET['f'] ) ? json_decode( wp_unslash( $_GET['f'] ), true ) : array();
		$f   = self::clean_filters( is_array( $raw ) ? $raw : array() );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="db-sentinel-activity-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'time_utc', 'severity', 'kind', 'category', 'action', 'user', 'role', 'actor_type', 'actor', 'context', 'request', 'ip', 'summary' ) );
		foreach ( DBS_Activity::export_rows( $f, 5000 ) as $r ) {
			fputcsv(
				$out,
				array(
					$r['created_at'],
					$r['severity'],
					$r['kind'],
					$r['category'],
					$r['action'],
					$r['user_login'],
					$r['user_role'],
					$r['actor_type'],
					DBS_Names::actor( $r['actor_type'], $r['actor_slug'] ),
					$r['context'],
					$r['request'],
					$r['ip'],
					ltrim( $r['summary'], "=+-@\t\r" ),
				)
			);
		}
		fclose( $out );
		exit;
	}
}
