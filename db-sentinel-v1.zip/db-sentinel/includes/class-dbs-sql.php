<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Streaming SQL helpers.
 *
 * normalize() converts ANY mysqldump / phpMyAdmin style dump (multi-line statements,
 * comments, DELIMITER blocks, other table prefix) into DB Sentinel's one-statement-per-line
 * format, so uploaded files use exactly the same restore path as native backups.
 */
class DBS_Sql {

	const HEAD_RE = '/^(DROP\s+TABLE(?:\s+IF\s+EXISTS)?\s+|CREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+|INSERT(?:\s+(?:LOW_PRIORITY|DELAYED|HIGH_PRIORITY))?(?:\s+IGNORE)?\s+INTO\s+|REPLACE(?:\s+INTO)?\s+|ALTER\s+(?:IGNORE\s+)?TABLE\s+|UPDATE\s+)`?([A-Za-z0-9_$]+)`?/i';

	/** Read one full line (no matter how long). Returns false at EOF. */
	public static function read_line( $h, $gz ) {
		$line = '';
		while ( true ) {
			$part = $gz ? gzgets( $h, 1048576 ) : fgets( $h, 1048576 );
			if ( false === $part ) {
				return ( '' === $line ) ? false : $line;
			}
			$line .= $part;
			if ( "\n" === substr( $part, -1 ) ) {
				return $line;
			}
		}
	}

	/** Rename the table in a one-line statement of our own format (used for verify mode). */
	public static function rewrite_line( $line, $from, $to ) {
		$c = $line[0];
		if ( 'D' !== $c && 'C' !== $c && 'I' !== $c && 'A' !== $c && 'U' !== $c && 'R' !== $c ) {
			return $line;
		}
		$head = substr( $line, 0, 300 );
		if ( ! preg_match( self::HEAD_RE, $head, $m ) ) {
			return $line;
		}
		$name = $m[2];
		$new  = ( 0 === strpos( $name, $from ) ) ? $to . substr( $name, strlen( $from ) ) : $to . $name;
		return substr( $head, 0, strlen( $m[1] ) ) . '`' . $new . '`' . substr( $line, strlen( $m[0] ) );
	}

	/** Guess the WordPress table prefix used by a dump (cheap scan of CREATE/DROP lines). */
	public static function detect_prefix( $path, $gz ) {
		$h = $gz ? @gzopen( $path, 'rb' ) : @fopen( $path, 'rb' );
		if ( ! $h ) {
			return '';
		}
		$names   = array();
		$atstart = true;
		while ( true ) {
			$part = $gz ? gzgets( $h, 4096 ) : fgets( $h, 4096 );
			if ( false === $part ) {
				break;
			}
			if ( $atstart && preg_match( '/^\s*(?:CREATE|DROP)\s+TABLE\s+(?:IF\s+(?:NOT\s+)?EXISTS\s+)?`?([A-Za-z0-9_$]+)`?/i', $part, $m ) ) {
				$names[ $m[1] ] = true;
				foreach ( $names as $n => $_ ) {
					if ( substr( $n, -7 ) === 'options' ) {
						$p = substr( $n, 0, -7 );
						if ( isset( $names[ $p . 'posts' ] ) && isset( $names[ $p . 'users' ] ) ) {
							$gz ? gzclose( $h ) : fclose( $h );
							return $p;
						}
					}
				}
			}
			$atstart = ( "\n" === substr( $part, -1 ) );
		}
		$gz ? gzclose( $h ) : fclose( $h );
		return '';
	}

	/**
	 * Convert a dump to DB Sentinel format.
	 *
	 * @param string     $path        Input file (plain or gzip).
	 * @param bool       $gz          Whether the input is gzip.
	 * @param DBS_Writer $w           Output writer.
	 * @param string     $site_prefix Table prefix of this site.
	 * @param array      $rep         Report (tables, prefix mapping, charset...).
	 */
	public static function normalize( $path, $gz, DBS_Writer $w, $site_prefix, &$rep ) {
		global $wpdb;
		$from = self::detect_prefix( $path, $gz );
		$map  = ( '' !== $from && $from !== $site_prefix );
		$h    = $gz ? @gzopen( $path, 'rb' ) : @fopen( $path, 'rb' );
		if ( ! $h ) {
			throw new Exception( 'باز کردن فایل ممکن نیست.' );
		}
		$rep = array(
			'tables'      => array(),
			'stmts'       => 0,
			'skipped'     => 0,
			'prefix_from' => $from,
			'prefix_to'   => $site_prefix,
			'mapped'      => $map,
			'charset'     => '',
		);

		$state = array( 'header' => false, 'lastdrop' => '' );

		$emit = function ( $stmt ) use ( &$rep, &$state, $w, $from, $site_prefix, $map, $wpdb ) {
			$s = trim( $stmt );
			if ( '' === $s ) {
				return;
			}
			if ( ! preg_match( '/^([A-Za-z]+)/', $s, $km ) ) {
				$rep['skipped']++;
				return;
			}
			$kw = strtoupper( $km[1] );

			if ( 'SET' === $kw ) {
				if ( preg_match( '/^SET\s+NAMES\s+([A-Za-z0-9_]+)/i', $s, $cm ) && 'binary' !== strtolower( $cm[1] ) ) {
					$rep['charset'] = strtolower( $cm[1] );
				}
				return;
			}
			if ( ! in_array( $kw, array( 'DROP', 'CREATE', 'INSERT', 'REPLACE', 'ALTER', 'UPDATE' ), true ) ) {
				$rep['skipped']++;
				return;
			}
			if ( ! preg_match( self::HEAD_RE, substr( $s, 0, 400 ), $m ) ) {
				$rep['skipped']++; // VIEW / TRIGGER / PROCEDURE ...
				return;
			}
			$verb = strtoupper( preg_replace( '/\s+/', ' ', trim( $m[1] ) ) );
			$name = $m[2];
			if ( $map && 0 === strpos( $name, $from ) ) {
				$name = $site_prefix . substr( $name, strlen( $from ) );
			}
			$rest = substr( $s, strlen( $m[0] ) );

			if ( ! $state['header'] ) {
				$cs = $rep['charset'] ? $rep['charset'] : ( $wpdb->charset ? $wpdb->charset : 'utf8mb4' );
				$rep['charset'] = $cs;
				$w->write( "-- DB Sentinel dump\n-- Imported and normalised\n-- Prefix: {$site_prefix}\nSET NAMES {$cs};\nSET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n" );
				$state['header'] = true;
			}

			if ( 0 === strpos( $verb, 'DROP TABLE' ) ) {
				$w->write( "DROP TABLE IF EXISTS `{$name}`;\n" );
				$state['lastdrop'] = $name;
				return;
			}
			if ( 0 === strpos( $verb, 'CREATE TABLE' ) ) {
				if ( $state['lastdrop'] !== $name ) {
					$w->write( "DROP TABLE IF EXISTS `{$name}`;\n" );
				}
				$state['lastdrop'] = '';
				$rep['tables'][ $name ] = array( 'rows' => 0, 'crc' => '' );
				$w->write( 'CREATE TABLE `' . $name . '`' . $rest . ";\n" );
				$rep['stmts']++;
				return;
			}
			if ( 0 === strpos( $verb, 'INSERT' ) || 0 === strpos( $verb, 'REPLACE' ) ) {
				if ( ! isset( $rep['tables'][ $name ] ) ) {
					$rep['tables'][ $name ] = array( 'rows' => 0, 'crc' => '' );
				}
				$rep['tables'][ $name ]['rows'] += substr_count( $rest, '),(' ) + 1;
				$head = ( 0 === strpos( $verb, 'REPLACE' ) ) ? 'REPLACE INTO' : ( false !== strpos( $verb, 'IGNORE' ) ? 'INSERT IGNORE INTO' : 'INSERT INTO' );
				$w->write( $head . ' `' . $name . '`' . $rest . ";\n" );
				$rep['stmts']++;
				return;
			}
			if ( 0 === strpos( $verb, 'ALTER' ) ) {
				$w->write( 'ALTER TABLE `' . $name . '`' . $rest . ";\n" );
				$rep['stmts']++;
				return;
			}
			if ( 0 === strpos( $verb, 'UPDATE' ) ) {
				$w->write( 'UPDATE `' . $name . '`' . $rest . ";\n" );
				$rep['stmts']++;
			}
		};

		$buf       = '';
		$in        = null;   // Current quote char or null.
		$bc        = false;  // Inside /* */ comment.
		$skipdelim = false;

		while ( false !== ( $line = self::read_line( $h, $gz ) ) ) {
			if ( $skipdelim ) {
				if ( preg_match( '/^\s*DELIMITER\s+;\s*$/i', $line ) ) {
					$skipdelim = false;
				}
				continue;
			}
			if ( null === $in && ! $bc && '' === trim( $buf ) && preg_match( '/^\s*DELIMITER\s+(\S+)/i', $line, $dm ) ) {
				if ( ';' !== $dm[1] ) {
					$skipdelim = true;
				}
				continue;
			}

			$len = strlen( $line );
			$i   = 0;
			while ( $i < $len ) {
				if ( $bc ) {
					$e = strpos( $line, '*/', $i );
					if ( false === $e ) {
						break;
					}
					$bc = false;
					$i  = $e + 2;
					continue;
				}

				if ( null !== $in ) {
					$q = $in;
					$j = strcspn( $line, $q . "\\\r\n", $i );
					if ( $j > 0 ) {
						$buf .= substr( $line, $i, $j );
						$i   += $j;
					}
					if ( $i >= $len ) {
						break;
					}
					$c = $line[ $i ];
					if ( $c === $q ) {
						if ( $i + 1 < $len && $line[ $i + 1 ] === $q ) {
							$buf .= $q . $q;
							$i   += 2;
						} else {
							$buf .= $q;
							$in   = null;
							$i++;
						}
					} elseif ( '\\' === $c ) {
						if ( '`' === $q || $i + 1 >= $len ) {
							$buf .= '\\';
							$i++;
						} else {
							$n    = $line[ $i + 1 ];
							$buf .= ( "\n" === $n ) ? '\\n' : ( ( "\r" === $n ) ? '\\r' : '\\' . $n );
							$i   += 2;
						}
					} elseif ( "\n" === $c ) {
						$buf .= ( '`' === $q ) ? ' ' : '\\n';
						$i++;
					} else { // "\r"
						$buf .= ( '`' === $q ) ? '' : '\\r';
						$i++;
					}
					continue;
				}

				$j = strcspn( $line, "'\"`;-#/\r\n", $i );
				if ( $j > 0 ) {
					$buf .= substr( $line, $i, $j );
					$i   += $j;
				}
				if ( $i >= $len ) {
					break;
				}
				$c = $line[ $i ];
				if ( "'" === $c || '"' === $c || '`' === $c ) {
					$buf .= $c;
					$in   = $c;
					$i++;
				} elseif ( ';' === $c ) {
					$emit( $buf );
					$buf = '';
					$i++;
				} elseif ( '-' === $c ) {
					$n1 = ( $i + 1 < $len ) ? $line[ $i + 1 ] : '';
					$n2 = ( $i + 2 < $len ) ? $line[ $i + 2 ] : ' ';
					if ( '-' === $n1 && ctype_space( $n2 ) ) {
						$i = $len; // Line comment.
					} else {
						$buf .= '-';
						$i++;
					}
				} elseif ( '#' === $c ) {
					$i = $len;
				} elseif ( '/' === $c ) {
					if ( $i + 1 < $len && '*' === $line[ $i + 1 ] ) {
						$bc = true;
						$i += 2;
					} else {
						$buf .= '/';
						$i++;
					}
				} else { // Newline / CR outside strings.
					$buf .= ' ';
					$i++;
				}
			}
		}
		$gz ? gzclose( $h ) : fclose( $h );
		if ( '' !== trim( $buf ) ) {
			$emit( $buf );
		}

		if ( empty( $rep['tables'] ) ) {
			throw new Exception( 'در این فایل هیچ جدول معتبری پیدا نشد. مطمئن شوید فایل SQL دیتابیس وردپرس است.' );
		}

		if ( $map ) {
			$n  = strlen( $from );
			$to = $site_prefix;
			if ( isset( $rep['tables'][ $to . 'options' ] ) ) {
				$w->write( "UPDATE `{$to}options` SET `option_name` = CONCAT('{$to}', SUBSTRING(`option_name`, " . ( $n + 1 ) . ")) WHERE LEFT(`option_name`, {$n}) = '{$from}';\n" );
			}
			if ( isset( $rep['tables'][ $to . 'usermeta' ] ) ) {
				$w->write( "UPDATE `{$to}usermeta` SET `meta_key` = CONCAT('{$to}', SUBSTRING(`meta_key`, " . ( $n + 1 ) . ")) WHERE LEFT(`meta_key`, {$n}) = '{$from}';\n" );
			}
		}
		$w->write( "SET FOREIGN_KEY_CHECKS=1;\n-- DBS-COMPLETE\n" );
	}
}
