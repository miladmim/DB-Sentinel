<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AES-256-CBC streaming file encryption with HMAC-SHA256 (encrypt-then-MAC).
 * Layout: MAGIC(8) | salt(16) | iv(16) | ciphertext | hmac(32)
 */
class DBS_Crypt {

	const MAGIC = "DBSENC01";
	const CHUNK = 1048576;

	public static function available() {
		return function_exists( 'openssl_encrypt' ) && function_exists( 'hash_pbkdf2' ) && in_array( 'aes-256-cbc', openssl_get_cipher_methods(), true );
	}

	private static function keys( $pass, $salt ) {
		$k = hash_pbkdf2( 'sha256', $pass, $salt, 20000, 64, true );
		return array( substr( $k, 0, 32 ), substr( $k, 32, 32 ) );
	}

	public static function encrypt_file( $src, $dst, $pass ) {
		if ( ! self::available() ) {
			return new WP_Error( 'dbs_crypt', 'افزونه OpenSSL در PHP فعال نیست.' );
		}
		$in  = @fopen( $src, 'rb' );
		$out = @fopen( $dst, 'wb' );
		if ( ! $in || ! $out ) {
			return new WP_Error( 'dbs_crypt', 'باز کردن فایل برای رمزنگاری ممکن نیست.' );
		}
		$salt = random_bytes( 16 );
		$iv   = random_bytes( 16 );
		list( $ek, $mk ) = self::keys( $pass, $salt );
		$mac  = hash_init( 'sha256', HASH_HMAC, $mk );
		$head = self::MAGIC . $salt . $iv;
		fwrite( $out, $head );
		hash_update( $mac, $head );

		$chunk = (string) fread( $in, self::CHUNK );
		while ( true ) {
			$next  = (string) fread( $in, self::CHUNK );
			$final = ( '' === $next );
			$ct    = openssl_encrypt( $chunk, 'aes-256-cbc', $ek, $final ? OPENSSL_RAW_DATA : ( OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING ), $iv );
			if ( false === $ct ) {
				fclose( $in );
				fclose( $out );
				return new WP_Error( 'dbs_crypt', 'رمزنگاری ناموفق بود.' );
			}
			fwrite( $out, $ct );
			hash_update( $mac, $ct );
			if ( $final ) {
				break;
			}
			$iv    = substr( $ct, -16 );
			$chunk = $next;
		}
		fwrite( $out, hash_final( $mac, true ) );
		fclose( $in );
		fclose( $out );
		return true;
	}

	public static function decrypt_file( $src, $dst, $pass ) {
		if ( ! self::available() ) {
			return new WP_Error( 'dbs_crypt', 'افزونه OpenSSL در PHP فعال نیست.' );
		}
		$size = (int) filesize( $src );
		if ( $size < 8 + 16 + 16 + 32 + 16 ) {
			return new WP_Error( 'dbs_crypt', 'فایل رمزنگاری‌شده نامعتبر است.' );
		}
		$in = @fopen( $src, 'rb' );
		if ( ! $in ) {
			return new WP_Error( 'dbs_crypt', 'باز کردن فایل ممکن نیست.' );
		}
		if ( fread( $in, 8 ) !== self::MAGIC ) {
			fclose( $in );
			return new WP_Error( 'dbs_crypt', 'این فایل با DB Sentinel رمزنگاری نشده است.' );
		}
		$salt = fread( $in, 16 );
		$iv   = fread( $in, 16 );
		list( $ek, $mk ) = self::keys( $pass, $salt );

		// Pass 1: verify the MAC (also detects a wrong passphrase).
		$mac = hash_init( 'sha256', HASH_HMAC, $mk );
		hash_update( $mac, self::MAGIC . $salt . $iv );
		$remaining = $size - 40 - 32;
		$left      = $remaining;
		while ( $left > 0 ) {
			$part = fread( $in, min( self::CHUNK, $left ) );
			if ( '' === $part || false === $part ) {
				break;
			}
			hash_update( $mac, $part );
			$left -= strlen( $part );
		}
		$tag = fread( $in, 32 );
		if ( ! hash_equals( hash_final( $mac, true ), (string) $tag ) ) {
			fclose( $in );
			return new WP_Error( 'dbs_crypt', 'رمز اشتباه است یا فایل خراب شده است.' );
		}

		// Pass 2: decrypt.
		fseek( $in, 40 );
		$out = @fopen( $dst, 'wb' );
		if ( ! $out ) {
			fclose( $in );
			return new WP_Error( 'dbs_crypt', 'ساخت فایل خروجی ممکن نیست.' );
		}
		$left = $remaining;
		while ( $left > 0 ) {
			$final = ( $left <= self::CHUNK + 16 );
			$n     = $final ? $left : self::CHUNK;
			$ct    = (string) fread( $in, $n );
			$pt    = openssl_decrypt( $ct, 'aes-256-cbc', $ek, $final ? OPENSSL_RAW_DATA : ( OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING ), $iv );
			if ( false === $pt ) {
				fclose( $in );
				fclose( $out );
				return new WP_Error( 'dbs_crypt', 'رمزگشایی ناموفق بود.' );
			}
			fwrite( $out, $pt );
			$iv    = substr( $ct, -16 );
			$left -= $n;
		}
		fclose( $in );
		fclose( $out );
		return true;
	}
}

/**
 * Minimal S3-compatible client (AWS Signature V4, path or virtual-host style).
 * Works with AWS S3, Cloudflare R2, Wasabi, MinIO, DigitalOcean Spaces, Backblaze B2...
 */
class DBS_S3 {

	private $c;

	public function __construct( $cfg ) {
		$this->c = $cfg;
	}

	private function prefix() {
		$p = trim( (string) $this->c['s3_prefix'], '/' );
		return ( '' === $p ) ? '' : $p . '/';
	}

	private function request( $method, $key, $query = array(), $file = null, $out = null ) {
		$c = $this->c;
		if ( empty( $c['s3_endpoint'] ) || empty( $c['s3_bucket'] ) || empty( $c['s3_key'] ) || empty( $c['s3_secret'] ) ) {
			return new WP_Error( 'dbs_s3', 'اطلاعات S3 کامل نیست (Endpoint، Bucket، Access Key، Secret).' );
		}
		if ( ! function_exists( 'curl_init' ) ) {
			return new WP_Error( 'dbs_s3', 'افزونه cURL در PHP فعال نیست.' );
		}
		$ep     = parse_url( $c['s3_endpoint'] );
		$scheme = isset( $ep['scheme'] ) ? $ep['scheme'] : 'https';
		$host   = isset( $ep['host'] ) ? $ep['host'] : '';
		$port   = isset( $ep['port'] ) ? ':' . $ep['port'] : '';
		if ( ! $host ) {
			return new WP_Error( 'dbs_s3', 'آدرس Endpoint نامعتبر است.' );
		}
		$segs = array();
		if ( ! empty( $c['s3_pathstyle'] ) ) {
			$segs[] = $c['s3_bucket'];
			$hosth  = $host . $port;
		} else {
			$hosth = $c['s3_bucket'] . '.' . $host . $port;
		}
		foreach ( explode( '/', $key ) as $s ) {
			if ( '' !== $s ) {
				$segs[] = $s;
			}
		}
		$uri = '/' . implode( '/', array_map( 'rawurlencode', $segs ) );
		if ( '' !== $key && '/' === substr( $key, -1 ) ) {
			$uri .= '/';
		}

		ksort( $query );
		$qs = array();
		foreach ( $query as $k => $v ) {
			$qs[] = rawurlencode( $k ) . '=' . rawurlencode( $v );
		}
		$qstr = implode( '&', $qs );

		$date  = gmdate( 'Ymd\THis\Z' );
		$day   = gmdate( 'Ymd' );
		$phash = $file ? hash_file( 'sha256', $file ) : hash( 'sha256', '' );

		$canon_headers = "host:{$hosth}\nx-amz-content-sha256:{$phash}\nx-amz-date:{$date}\n";
		$signed        = 'host;x-amz-content-sha256;x-amz-date';
		$canon         = "{$method}\n{$uri}\n{$qstr}\n{$canon_headers}\n{$signed}\n{$phash}";
		$region        = $c['s3_region'] ? $c['s3_region'] : 'us-east-1';
		$scope         = "{$day}/{$region}/s3/aws4_request";
		$sts           = "AWS4-HMAC-SHA256\n{$date}\n{$scope}\n" . hash( 'sha256', $canon );
		$k1            = hash_hmac( 'sha256', $day, 'AWS4' . $c['s3_secret'], true );
		$k2            = hash_hmac( 'sha256', $region, $k1, true );
		$k3            = hash_hmac( 'sha256', 's3', $k2, true );
		$k4            = hash_hmac( 'sha256', 'aws4_request', $k3, true );
		$sig           = hash_hmac( 'sha256', $sts, $k4 );
		$auth          = "AWS4-HMAC-SHA256 Credential={$c['s3_key']}/{$scope}, SignedHeaders={$signed}, Signature={$sig}";

		$url = $scheme . '://' . $hosth . $uri . ( $qstr ? '?' . $qstr : '' );
		$ch  = curl_init( $url );
		$hdr = array( "Authorization: {$auth}", "x-amz-content-sha256: {$phash}", "x-amz-date: {$date}", 'Expect:' );
		curl_setopt_array(
			$ch,
			array(
				CURLOPT_CUSTOMREQUEST  => $method,
				CURLOPT_HTTPHEADER     => $hdr,
				CURLOPT_CONNECTTIMEOUT => 20,
				CURLOPT_TIMEOUT        => 0,
				CURLOPT_FOLLOWLOCATION => false,
			)
		);
		$fh = null;
		if ( $file ) {
			$fh = fopen( $file, 'rb' );
			curl_setopt_array(
				$ch,
				array(
					CURLOPT_UPLOAD       => true,
					CURLOPT_INFILE       => $fh,
					CURLOPT_INFILESIZE   => filesize( $file ),
					CURLOPT_RETURNTRANSFER => true,
				)
			);
		} elseif ( $out ) {
			$fh = fopen( $out, 'wb' );
			curl_setopt( $ch, CURLOPT_FILE, $fh );
		} else {
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		}
		$body = curl_exec( $ch );
		$err  = curl_error( $ch );
		$code = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
		curl_close( $ch );
		if ( $fh ) {
			fclose( $fh );
		}
		if ( false === $body && $err ) {
			return new WP_Error( 'dbs_s3', 'خطای شبکه: ' . $err );
		}
		if ( $code < 200 || $code >= 300 ) {
			$msg = 'HTTP ' . $code;
			if ( is_string( $body ) && preg_match( '#<Message>(.*?)</Message>#s', $body, $m ) ) {
				$msg .= ' — ' . wp_strip_all_tags( $m[1] );
			} elseif ( $out && is_file( $out ) ) {
				$msg .= ' — ' . substr( (string) file_get_contents( $out, false, null, 0, 300 ), 0, 300 );
				@unlink( $out );
			}
			return new WP_Error( 'dbs_s3', 'S3: ' . $msg );
		}
		return is_string( $body ) ? $body : '';
	}

	public function test() {
		$r = $this->request( 'GET', '', array( 'list-type' => '2', 'max-keys' => '1', 'prefix' => $this->prefix() ) );
		return is_wp_error( $r ) ? $r : true;
	}

	public function put( $local, $name ) {
		$r = $this->request( 'PUT', $this->prefix() . $name, array(), $local );
		return is_wp_error( $r ) ? $r : true;
	}

	public function get( $name, $local ) {
		$r = $this->request( 'GET', $this->prefix() . $name, array(), null, $local );
		return is_wp_error( $r ) ? $r : true;
	}

	public function delete( $name ) {
		$r = $this->request( 'DELETE', $this->prefix() . $name );
		return is_wp_error( $r ) ? $r : true;
	}

	public function items() {
		$out   = array();
		$token = '';
		for ( $i = 0; $i < 20; $i++ ) {
			$q = array( 'list-type' => '2', 'prefix' => $this->prefix() );
			if ( $token ) {
				$q['continuation-token'] = $token;
			}
			$r = $this->request( 'GET', '', $q );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			if ( preg_match_all( '#<Contents>(.*?)</Contents>#s', $r, $m ) ) {
				foreach ( $m[1] as $blk ) {
					if ( preg_match( '#<Key>(.*?)</Key>#s', $blk, $k ) ) {
						$size = preg_match( '#<Size>(\d+)</Size>#', $blk, $s ) ? (int) $s[1] : 0;
						$out[] = array( 'name' => substr( html_entity_decode( $k[1] ), strlen( $this->prefix() ) ), 'size' => $size );
					}
				}
			}
			if ( preg_match( '#<IsTruncated>true</IsTruncated>#', $r ) && preg_match( '#<NextContinuationToken>(.*?)</NextContinuationToken>#s', $r, $t ) ) {
				$token = html_entity_decode( $t[1] );
			} else {
				break;
			}
		}
		return $out;
	}
}

/**
 * FTP / FTPS driver.
 */
class DBS_Ftp {

	private $c;
	private $conn = null;

	public function __construct( $cfg ) {
		$this->c = $cfg;
	}

	private function connect() {
		if ( $this->conn ) {
			return true;
		}
		$c = $this->c;
		if ( ! function_exists( 'ftp_connect' ) ) {
			return new WP_Error( 'dbs_ftp', 'افزونه FTP در PHP فعال نیست.' );
		}
		if ( empty( $c['ftp_host'] ) || empty( $c['ftp_user'] ) ) {
			return new WP_Error( 'dbs_ftp', 'اطلاعات FTP کامل نیست.' );
		}
		$conn = ! empty( $c['ftp_ssl'] ) && function_exists( 'ftp_ssl_connect' ) ? @ftp_ssl_connect( $c['ftp_host'], (int) $c['ftp_port'], 20 ) : @ftp_connect( $c['ftp_host'], (int) $c['ftp_port'], 20 );
		if ( ! $conn ) {
			return new WP_Error( 'dbs_ftp', 'اتصال به سرور FTP برقرار نشد.' );
		}
		if ( ! @ftp_login( $conn, $c['ftp_user'], $c['ftp_pass'] ) ) {
			return new WP_Error( 'dbs_ftp', 'نام کاربری یا رمز FTP اشتباه است.' );
		}
		@ftp_pasv( $conn, ! empty( $c['ftp_passive'] ) );
		$dir = trim( (string) $c['ftp_dir'], '/' );
		if ( '' !== $dir ) {
			$path = '';
			foreach ( explode( '/', $dir ) as $seg ) {
				$path .= '/' . $seg;
				if ( ! @ftp_chdir( $conn, $path ) ) {
					@ftp_mkdir( $conn, $path );
					if ( ! @ftp_chdir( $conn, $path ) ) {
						return new WP_Error( 'dbs_ftp', 'ساخت یا ورود به پوشه‌ی ' . $path . ' ممکن نیست.' );
					}
				}
			}
		}
		$this->conn = $conn;
		return true;
	}

	public function test() {
		$r = $this->connect();
		return is_wp_error( $r ) ? $r : true;
	}

	public function put( $local, $name ) {
		$r = $this->connect();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return @ftp_put( $this->conn, $name, $local, FTP_BINARY ) ? true : new WP_Error( 'dbs_ftp', 'ارسال فایل با FTP ناموفق بود.' );
	}

	public function get( $name, $local ) {
		$r = $this->connect();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return @ftp_get( $this->conn, $local, $name, FTP_BINARY ) ? true : new WP_Error( 'dbs_ftp', 'دریافت فایل با FTP ناموفق بود.' );
	}

	public function delete( $name ) {
		$r = $this->connect();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return @ftp_delete( $this->conn, $name ) ? true : new WP_Error( 'dbs_ftp', 'حذف فایل با FTP ناموفق بود.' );
	}

	public function items() {
		$r = $this->connect();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$names = @ftp_nlist( $this->conn, '.' );
		$out   = array();
		foreach ( (array) $names as $n ) {
			$n = basename( $n );
			if ( ! preg_match( '/^dbs-\d{8}-\d{6}-[a-f0-9]{8}\./', $n ) ) {
				continue;
			}
			$size  = @ftp_size( $this->conn, $n );
			$out[] = array( 'name' => $n, 'size' => ( $size > 0 ) ? (int) $size : 0 );
		}
		return $out;
	}
}

/**
 * Remote storage facade: upload after every backup, retention (daily / weekly), import.
 */
class DBS_Remote {

	const NAME_RE = '/^dbs-(\d{8}-\d{6}-[a-f0-9]{8})\.sql(\.gz)?(\.enc)?$/';

	public static function driver() {
		$s = DBS_Settings::all();
		if ( 's3' === $s['remote_driver'] ) {
			return new DBS_S3( $s );
		}
		if ( 'ftp' === $s['remote_driver'] ) {
			return new DBS_Ftp( $s );
		}
		return null;
	}

	public static function configured() {
		return null !== self::driver();
	}

	public static function auto_ready() {
		return self::configured() && DBS_Settings::get( 'remote_auto' );
	}

	public static function test() {
		$d = self::driver();
		if ( ! $d ) {
			return new WP_Error( 'dbs_remote', 'ذخیره‌ساز بیرونی انتخاب نشده است.' );
		}
		return $d->test();
	}

	public static function id_time( $id ) {
		return (int) strtotime( substr( $id, 0, 8 ) . 'T' . substr( $id, 9, 6 ) . 'Z' );
	}

	public static function upload( $meta ) {
		$d = self::driver();
		if ( ! $d ) {
			return new WP_Error( 'dbs_remote', 'ذخیره‌ساز بیرونی تنظیم نشده است.' );
		}
		@set_time_limit( 0 );
		$s     = DBS_Settings::all();
		$local = DBS_Storage::path( $meta );
		$name  = basename( $meta['file'] );
		$tmp   = '';
		if ( ! empty( $s['remote_encrypt'] ) ) {
			if ( '' === (string) $s['remote_pass'] ) {
				return new WP_Error( 'dbs_remote', 'رمزنگاری روشن است ولی رمز تعیین نشده.' );
			}
			$tmp = DBS_Storage::dir( false ) . '/enc-' . $meta['id'] . '.tmp';
			$r   = DBS_Crypt::encrypt_file( $local, $tmp, $s['remote_pass'] );
			if ( is_wp_error( $r ) ) {
				@unlink( $tmp );
				return $r;
			}
			$local = $tmp;
			$name .= '.enc';
		}
		$r = $d->put( $local, $name );
		if ( $tmp ) {
			@unlink( $tmp );
		}
		if ( is_wp_error( $r ) ) {
			DBS_Storage::update_meta( $meta['id'], array( 'remote' => array( 'ok' => false, 'error' => $r->get_error_message(), 'ts' => time() ) ) );
			DBS_Notify::send( 'fail', 'ارسال بکاپ به ذخیره‌ساز بیرونی ناموفق بود', array( $r->get_error_message() ) );
			return $r;
		}
		DBS_Storage::update_meta( $meta['id'], array( 'remote' => array( 'ok' => true, 'driver' => $s['remote_driver'], 'name' => $name, 'enc' => ! empty( $s['remote_encrypt'] ), 'ts' => time() ) ) );
		self::retention();
		return true;
	}

	public static function items() {
		$d = self::driver();
		if ( ! $d ) {
			return new WP_Error( 'dbs_remote', 'ذخیره‌ساز بیرونی تنظیم نشده است.' );
		}
		$list = $d->items();
		if ( is_wp_error( $list ) ) {
			return $list;
		}
		$out = array();
		foreach ( $list as $it ) {
			if ( preg_match( self::NAME_RE, $it['name'], $m ) ) {
				$out[] = array(
					'id'      => $m[1],
					'name'    => $it['name'],
					'size'    => $it['size'],
					'created' => self::id_time( $m[1] ),
					'enc'     => ! empty( $m[3] ),
					'local'   => (bool) DBS_Storage::get( $m[1] ),
				);
			}
		}
		usort(
			$out,
			function ( $a, $b ) {
				return $b['created'] - $a['created'];
			}
		);
		return $out;
	}

	/** Grandfather-father-son style retention for remote copies. */
	public static function retention() {
		$s = DBS_Settings::all();
		if ( ! $s['remote_daily'] && ! $s['remote_weekly'] ) {
			return;
		}
		$items = self::items();
		if ( is_wp_error( $items ) || ! $items ) {
			return;
		}
		$keep = array();
		$days = array();
		$wks  = array();
		foreach ( $items as $i => $it ) { // Newest first.
			if ( 0 === $i ) {
				$keep[ $it['name'] ] = true;
			}
			$dk = gmdate( 'Y-m-d', $it['created'] );
			$wk = gmdate( 'o-W', $it['created'] );
			if ( ! isset( $days[ $dk ] ) && count( $days ) < (int) $s['remote_daily'] ) {
				$days[ $dk ]         = true;
				$keep[ $it['name'] ] = true;
			}
			if ( ! isset( $wks[ $wk ] ) && count( $wks ) < (int) $s['remote_weekly'] ) {
				$wks[ $wk ]          = true;
				$keep[ $it['name'] ] = true;
			}
			// Everything newer than the local retention window is kept as well.
			if ( $it['created'] > time() - (int) $s['retention_hours'] * 3600 ) {
				$keep[ $it['name'] ] = true;
			}
		}
		$d = self::driver();
		foreach ( $items as $it ) {
			if ( empty( $keep[ $it['name'] ] ) ) {
				$d->delete( $it['name'] );
			}
		}
	}

	public static function delete( $name ) {
		if ( ! preg_match( self::NAME_RE, $name ) ) {
			return new WP_Error( 'dbs_remote', 'نام فایل نامعتبر است.' );
		}
		$d = self::driver();
		return $d ? $d->delete( $name ) : new WP_Error( 'dbs_remote', 'ذخیره‌ساز بیرونی تنظیم نشده است.' );
	}

	/** Download a remote backup and register it as a local backup. */
	public static function import( $name, $pass = '' ) {
		if ( ! preg_match( self::NAME_RE, $name ) ) {
			return new WP_Error( 'dbs_remote', 'نام فایل نامعتبر است.' );
		}
		$d = self::driver();
		if ( ! $d ) {
			return new WP_Error( 'dbs_remote', 'ذخیره‌ساز بیرونی تنظیم نشده است.' );
		}
		@set_time_limit( 0 );
		$dir = DBS_Storage::dir( true );
		$tmp = $dir . '/import-' . bin2hex( random_bytes( 6 ) ) . '.part';
		$r   = $d->get( $name, $tmp );
		if ( is_wp_error( $r ) ) {
			@unlink( $tmp );
			return $r;
		}
		if ( '' === $pass ) {
			$pass = (string) DBS_Settings::get( 'remote_pass' );
		}
		$res = DBS_Import::register( $tmp, $name, 'imported', $pass );
		@unlink( $tmp );
		return $res;
	}
}

/**
 * Turns any file (native backup, foreign dump, gzip, encrypted) into a registered local backup.
 */
class DBS_Import {

	public static function register( $path, $orig_name, $type = 'imported', $pass = '' ) {
		global $wpdb;
		@set_time_limit( 0 );
		@ignore_user_abort( true );

		$dir = DBS_Storage::dir( true );
		if ( ! $dir || ! wp_is_writable( $dir ) ) {
			return new WP_Error( 'dbs_dir', 'پوشه بکاپ قابل نوشتن نیست.' );
		}
		$work = array();
		$fail = function ( $err ) use ( &$work ) {
			foreach ( $work as $w ) {
				@unlink( $w );
			}
			return $err;
		};

		$fh    = @fopen( $path, 'rb' );
		$magic = $fh ? fread( $fh, 8 ) : '';
		if ( $fh ) {
			fclose( $fh );
		}
		if ( DBS_Crypt::MAGIC === $magic ) {
			if ( '' === $pass ) {
				return new WP_Error( 'dbs_pass', 'این فایل رمزنگاری شده است؛ رمز را وارد کنید.' );
			}
			$dec = $dir . '/import-' . bin2hex( random_bytes( 6 ) ) . '.tmp';
			$work[] = $dec;
			$r = DBS_Crypt::decrypt_file( $path, $dec, $pass );
			if ( is_wp_error( $r ) ) {
				return $fail( $r );
			}
			$path = $dec;
		}
		$fh = @fopen( $path, 'rb' );
		$m2 = $fh ? fread( $fh, 2 ) : '';
		if ( $fh ) {
			fclose( $fh );
		}
		$gz = ( "\x1f\x8b" === $m2 );
		if ( $gz && ! function_exists( 'gzopen' ) ) {
			return $fail( new WP_Error( 'dbs_gz', 'افزونه zlib برای خواندن فایل فشرده لازم است.' ) );
		}

		$settings = DBS_Settings::all();
		$compress = ! empty( $settings['compress'] ) && function_exists( 'gzopen' );
		$id       = DBS_Storage::new_id();
		$file     = 'dbs-' . $id . ( $compress ? '.sql.gz' : '.sql' );
		$tmp      = $dir . '/' . $file . '.tmp';
		$started  = microtime( true );
		$w        = null;
		try {
			$w   = new DBS_Writer( $tmp, $compress );
			$rep = array();
			DBS_Sql::normalize( $path, $gz, $w, $wpdb->base_prefix, $rep );
			$w->close();
			if ( ! @rename( $tmp, $dir . '/' . $file ) ) {
				throw new Exception( 'تغییر نام فایل ناموفق بود.' );
			}
		} catch ( Exception $e ) {
			if ( $w ) {
				$w->close();
			}
			@unlink( $tmp );
			return $fail( new WP_Error( 'dbs_import', $e->getMessage() ) );
		}
		foreach ( $work as $wf ) {
			@unlink( $wf );
		}

		$final = $dir . '/' . $file;
		$user  = wp_get_current_user();
		$rows  = 0;
		foreach ( $rep['tables'] as $t ) {
			$rows += (int) $t['rows'];
		}
		$note = 'وارد شده از «' . sanitize_text_field( $orig_name ) . '»' . ( $rep['mapped'] ? ' — پیشوند جدول‌ها از ' . $rep['prefix_from'] . ' به ' . $rep['prefix_to'] . ' تبدیل شد' : '' );
		$meta = array(
			'id'          => $id,
			'created'     => time(),
			'type'        => in_array( $type, array( 'uploaded', 'imported' ), true ) ? $type : 'imported',
			'file'        => $file,
			'size'        => (int) filesize( $final ),
			'sha1'        => sha1_file( $final ),
			'compressed'  => $compress ? 1 : 0,
			'tables'      => count( $rep['tables'] ),
			'rows'        => $rows,
			'tables_info' => $rep['tables'],
			'rows_exact'  => false,
			'duration'    => round( microtime( true ) - $started, 2 ),
			'for'         => '',
			'by'          => ( $user && $user->ID ) ? $user->user_login : '',
			'wp'          => get_bloginfo( 'version' ),
			'prefix'      => $wpdb->base_prefix,
			'charset'     => $rep['charset'],
			'locked'      => true,
			'note'        => $note,
		);
		file_put_contents( $dir . '/dbs-' . $id . '.json', wp_json_encode( $meta ), LOCK_EX );

		DBS_Activity::record(
			array(
				'category'    => 'backup',
				'action'      => 'imported',
				'severity'    => 'notice',
				'summary'     => 'یک بکاپ وارد شد: ' . sanitize_text_field( $orig_name ) . ' (' . size_format( $meta['size'] ) . ')',
				'object_type' => 'backup',
				'object_id'   => $id,
				'actor_type'  => 'plugin',
				'actor_slug'  => 'db-sentinel',
			)
		);
		return $meta;
	}
}
