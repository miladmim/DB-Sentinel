<?php
/**
 * DB Sentinel - restore runner (standalone endpoint).
 *
 * It does NOT load plugins, themes or options: restoring replaces wp_options / wp_users
 * mid-way, so a normal admin-ajax request would break as soon as the active plugin list or
 * the login session is overwritten. Authentication is a random per-job token created by an
 * authenticated administrator and stored only in the private backup directory.
 */

@ini_set( 'display_errors', '0' );
ob_start();

header( 'Content-Type: application/json; charset=utf-8' );
header( 'Cache-Control: no-store, no-cache, must-revalidate' );
header( 'X-Robots-Tag: noindex' );

function dbs_out( $data, $code = 200 ) {
	while ( ob_get_level() > 0 ) {
		ob_end_clean();
	}
	if ( ! headers_sent() ) {
		http_response_code( $code );
	}
	echo json_encode( $data );
	exit;
}

register_shutdown_function(
	function () {
		$e = error_get_last();
		if ( $e && in_array( $e['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR ), true ) ) {
			while ( ob_get_level() > 0 ) {
				ob_end_clean();
			}
			if ( ! headers_sent() ) {
				http_response_code( 500 );
			}
			echo json_encode( array( 'ok' => false, 'error' => 'خطای PHP: ' . $e['message'] ) );
		}
	}
);

define( 'SHORTINIT', true );

$dbs_load = getenv( 'DBS_WP_LOAD' ) ? getenv( 'DBS_WP_LOAD' ) : '';
if ( ! $dbs_load ) {
	$dbs_dir = __DIR__;
	for ( $i = 0; $i < 8; $i++ ) {
		$dbs_dir = dirname( $dbs_dir );
		if ( is_file( $dbs_dir . '/wp-load.php' ) ) {
			$dbs_load = $dbs_dir . '/wp-load.php';
			break;
		}
	}
}
if ( ! $dbs_load || ! is_file( $dbs_load ) ) {
	dbs_out( array( 'ok' => false, 'error' => 'wp-load.php پیدا نشد.' ), 500 );
}

require_once $dbs_load;
require_once __DIR__ . '/paths.php';
require_once __DIR__ . '/restore-engine.php';

global $wpdb;
if ( ! isset( $wpdb ) || empty( $wpdb->ready ) ) {
	dbs_out( array( 'ok' => false, 'error' => 'اتصال به دیتابیس برقرار نشد.' ), 500 );
}

if ( isset( $_GET['ping'] ) ) {
	dbs_out( array( 'ok' => true, 'pong' => true ) );
}
if ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
	dbs_out( array( 'ok' => false, 'error' => 'method' ), 405 );
}

try {
	$job   = isset( $_POST['job'] ) ? preg_replace( '/[^a-z0-9]/i', '', (string) $_POST['job'] ) : '';
	$token = isset( $_POST['token'] ) ? (string) $_POST['token'] : '';
	$do    = isset( $_POST['do'] ) ? (string) $_POST['do'] : 'step';
	$dir   = dbs_backup_dir( false );
	if ( ! $dir ) {
		dbs_out( array( 'ok' => false, 'error' => 'پوشه بکاپ پیدا نشد.' ), 404 );
	}

	if ( 'abort' === $do ) {
		$sf = $dir . '/restore-' . $job . '.json';
		$st = is_file( $sf ) ? json_decode( (string) file_get_contents( $sf ), true ) : null;
		if ( ! is_array( $st ) || ! hash_equals( (string) $st['token'], $token ) ) {
			dbs_out( array( 'ok' => false, 'error' => 'دسترسی نامعتبر.' ), 403 );
		}
		@unlink( $dir . '/' . basename( $st['sql'] ) );
		$st['status'] = 'aborted';
		file_put_contents( $sf, json_encode( $st ), LOCK_EX );
		dbs_out( array( 'ok' => true, 'status' => 'aborted' ) );
	}

	$r    = dbs_engine_step( $dir, $job, $token, 8.0 );
	$code = isset( $r['code'] ) ? (int) $r['code'] : 200;
	unset( $r['code'] );
	dbs_out( $r, $code );
} catch ( Throwable $e ) {
	dbs_out( array( 'ok' => false, 'error' => $e->getMessage() ), 500 );
}
