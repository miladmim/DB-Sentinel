<?php
/**
 * Path helpers. This file must stay free of WordPress function calls because it is
 * also loaded by the standalone restore runner (which boots WordPress with SHORTINIT).
 */

if ( ! function_exists( 'dbs_backup_dir' ) ) {

	/**
	 * Write the protective files (deny web access) into a backup directory.
	 */
	function dbs_protect_dir( $dir ) {
		$files = array(
			'.htaccess'  => "# DB Sentinel\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n",
			'index.php'  => "<?php\n// Silence is golden.\n",
			'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n",
		);
		foreach ( $files as $name => $content ) {
			if ( ! file_exists( $dir . '/' . $name ) ) {
				@file_put_contents( $dir . '/' . $name, $content );
			}
		}
	}

	/**
	 * Find (or create) the private backup directory.
	 *
	 * The directory has a random name, so it is discovered by scanning for the marker
	 * file instead of being derived from secrets that may be rotated.
	 *
	 * @param bool $create Create the directory when it does not exist.
	 * @return string|false Absolute path without trailing slash.
	 */
	function dbs_backup_dir( $create = false ) {
		static $cache = null;
		if ( null !== $cache && is_dir( $cache ) ) {
			return $cache;
		}

		// Custom location: define( 'DBS_BACKUP_DIR', '/path/outside/webroot' ); in wp-config.php
		if ( defined( 'DBS_BACKUP_DIR' ) && DBS_BACKUP_DIR ) {
			$custom = rtrim( DBS_BACKUP_DIR, '/\\' );
			if ( ! is_dir( $custom ) && $create ) {
				@mkdir( $custom, 0755, true );
			}
			if ( is_dir( $custom ) ) {
				dbs_protect_dir( $custom );
				return $cache = $custom;
			}
			return false;
		}

		$content = rtrim( WP_CONTENT_DIR, '/\\' );
		$roots   = array( $content, $content . '/uploads' );

		foreach ( $roots as $root ) {
			if ( ! is_dir( $root ) ) {
				continue;
			}
			$items = @scandir( $root );
			if ( ! $items ) {
				continue;
			}
			foreach ( $items as $item ) {
				if ( 0 === strpos( $item, 'dbs-backups-' ) && is_file( $root . '/' . $item . '/.dbs-marker' ) ) {
					return $cache = $root . '/' . $item;
				}
			}
		}

		if ( ! $create ) {
			return false;
		}

		$name = 'dbs-backups-' . bin2hex( random_bytes( 8 ) );
		foreach ( $roots as $root ) {
			if ( ! is_dir( $root ) || ! is_writable( $root ) ) {
				continue;
			}
			$path = $root . '/' . $name;
			if ( @mkdir( $path, 0755, true ) || is_dir( $path ) ) {
				@file_put_contents( $path . '/.dbs-marker', 'DB Sentinel backup directory' );
				dbs_protect_dir( $path );
				return $cache = $path;
			}
		}
		return false;
	}
}
