<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Who / how / from where: user, responsible component (plugin/theme/core), request type.
 */
class DBS_Context {

	private static $paths = null;

	public static function ip() {
		// Behind Cloudflare the real visitor address is in this header.
		$cands = array();
		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			$cands[] = $_SERVER['HTTP_CF_CONNECTING_IP'];
		}
		if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			$cands[] = $_SERVER['REMOTE_ADDR'];
		}
		foreach ( $cands as $ip ) {
			$ip = trim( (string) $ip );
			if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
				return $ip;
			}
		}
		return '';
	}

	public static function user() {
		$out = array(
			'user_id'    => 0,
			'user_login' => '',
			'user_role'  => '',
		);
		if ( ! function_exists( 'wp_get_current_user' ) || ! did_action( 'plugins_loaded' ) ) {
			return $out;
		}
		$u = wp_get_current_user();
		if ( $u && $u->ID ) {
			$roles             = (array) $u->roles;
			$out['user_id']    = (int) $u->ID;
			$out['user_login'] = (string) $u->user_login;
			$out['user_role']  = $roles ? (string) reset( $roles ) : '';
		}
		return $out;
	}

	/**
	 * Walk the PHP call stack and find the code that is responsible for the current write:
	 * the innermost plugin / mu-plugin / theme file. If none is found the change was made
	 * by WordPress core itself (i.e. directly from the admin panel).
	 */
	public static function actor() {
		if ( null === self::$paths ) {
			self::$paths = array(
				'self'    => wp_normalize_path( DBS_DIR ),
				'plugins' => trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) ),
				'mu'      => trailingslashit( wp_normalize_path( WPMU_PLUGIN_DIR ) ),
				'themes'  => trailingslashit( wp_normalize_path( WP_CONTENT_DIR . '/themes' ) ),
			);
		}
		$trace = debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 60 ); // phpcs:ignore
		foreach ( $trace as $f ) {
			if ( empty( $f['file'] ) ) {
				continue;
			}
			$p = wp_normalize_path( $f['file'] );
			if ( 0 === strpos( $p, self::$paths['self'] ) ) {
				continue;
			}
			if ( 0 === strpos( $p, self::$paths['plugins'] ) ) {
				return array(
					'actor_type' => 'plugin',
					'actor_slug' => substr( (string) strtok( substr( $p, strlen( self::$paths['plugins'] ) ), '/' ), 0, 120 ),
				);
			}
			if ( 0 === strpos( $p, self::$paths['mu'] ) ) {
				return array(
					'actor_type' => 'mu-plugin',
					'actor_slug' => substr( (string) strtok( substr( $p, strlen( self::$paths['mu'] ) ), '/' ), 0, 120 ),
				);
			}
			if ( 0 === strpos( $p, self::$paths['themes'] ) ) {
				return array(
					'actor_type' => 'theme',
					'actor_slug' => substr( (string) strtok( substr( $p, strlen( self::$paths['themes'] ) ), '/' ), 0, 120 ),
				);
			}
		}
		return array(
			'actor_type' => 'core',
			'actor_slug' => 'wordpress',
		);
	}

	public static function request() {
		$ctx = 'frontend';
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			$ctx = 'cli';
		} elseif ( defined( 'DOING_CRON' ) && DOING_CRON ) {
			$ctx = 'cron';
		} elseif ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			$ctx = 'rest';
		} elseif ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) {
			$ctx = 'ajax';
		} elseif ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			$ctx = 'xmlrpc';
		} elseif ( defined( 'WP_INSTALLING' ) && WP_INSTALLING ) {
			$ctx = 'install';
		} elseif ( function_exists( 'is_admin' ) && is_admin() ) {
			$ctx = 'admin';
		}

		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( substr( preg_replace( '/[^A-Za-z]/', '', (string) $_SERVER['REQUEST_METHOD'] ), 0, 7 ) ) : '';
		$uri    = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
		$path   = (string) wp_parse_url( $uri, PHP_URL_PATH );

		switch ( $ctx ) {
			case 'cli':
				$req = 'wp-cli';
				break;
			case 'cron':
				$req = 'wp-cron.php';
				break;
			case 'rest':
				if ( isset( $_GET['rest_route'] ) && is_string( $_GET['rest_route'] ) ) {
					$route = $_GET['rest_route'];
				} elseif ( false !== strpos( $path, '/wp-json/' ) ) {
					$route = substr( $path, strpos( $path, '/wp-json/' ) + 8 );
				} else {
					$route = $path;
				}
				$req = $method . ' ' . $route;
				break;
			case 'ajax':
				$a   = ( isset( $_REQUEST['action'] ) && is_string( $_REQUEST['action'] ) ) ? preg_replace( '/[^A-Za-z0-9_\-:]/', '', $_REQUEST['action'] ) : '';
				$req = 'admin-ajax: ' . $a;
				break;
			case 'admin':
				$req  = basename( $path );
				$page = ( isset( $_GET['page'] ) && is_string( $_GET['page'] ) ) ? preg_replace( '/[^A-Za-z0-9_\-]/', '', $_GET['page'] ) : '';
				if ( $page ) {
					$req .= '?page=' . $page;
				}
				break;
			default:
				$req = trim( $method . ' ' . $path );
		}
		return array(
			'context' => $ctx,
			'request' => substr( $req, 0, 250 ),
		);
	}

	public static function snapshot( $req = null ) {
		if ( null === $req ) {
			$req = self::request();
		}
		return array_merge(
			self::user(),
			self::actor(),
			$req,
			array( 'ip' => self::ip() )
		);
	}
}

/**
 * Human readable names for plugin / theme slugs.
 */
class DBS_Names {

	public static function plugins() {
		static $map = null;
		if ( null !== $map ) {
			return $map;
		}
		$map = array();
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		foreach ( get_plugins() as $file => $data ) {
			$slug         = ( false !== strpos( $file, '/' ) ) ? strtok( $file, '/' ) : $file;
			$map[ $slug ] = $data['Name'];
		}
		return $map;
	}

	public static function actor( $type, $slug ) {
		if ( 'plugin' === $type ) {
			if ( 'db-sentinel' === $slug ) {
				return 'DB Sentinel';
			}
			$m = self::plugins();
			return isset( $m[ $slug ] ) ? $m[ $slug ] : $slug;
		}
		if ( 'theme' === $type ) {
			$t = wp_get_theme( $slug );
			return $t->exists() ? (string) $t->get( 'Name' ) : $slug;
		}
		if ( 'core' === $type ) {
			return 'هسته وردپرس';
		}
		return $slug ? $slug : 'سیستم';
	}
}

/**
 * Content inspection: finds injected scripts / iframes (ads, trackers, malware) and
 * builds readable change descriptions.
 */
class DBS_Inspect {

	const AD_RE     = '/adsbygoogle|googlesyndication|doubleclick|adservice|adsystem|taboola|outbrain|adsterra|propellerads|popcash|popads|yektanet|mediaad|tapsell|adivery|clickyab|sabavision|adro\.co|adnxs|criteo|amazon-adsystem|revcontent|mgid|exoclick|juicyads|hilltopads|monetag/i';
	const OBF_RE    = '/eval\s*\(|atob\s*\(|fromCharCode|unescape\s*\(|(?:\\\\x[0-9a-f]{2}){4,}|base64_decode|function\s*\(\s*p\s*,\s*a\s*,\s*c\s*,\s*k/i';
	const SECRET_RE = '/(pass(word)?|secret|token|api[_\-]?key|private|salt|nonce|license|credential|auth)/i';

	private static $rank = array(
		'info'    => 0,
		'notice'  => 1,
		'warning' => 2,
		'danger'  => 3,
	);

	public static function max_sev( $a, $b ) {
		return ( self::$rank[ $b ] > self::$rank[ $a ] ) ? $b : $a;
	}

	public static function cut( $s, $n ) {
		$s = wp_check_invalid_utf8( (string) $s, true );
		if ( function_exists( 'mb_strlen' ) ) {
			return ( mb_strlen( $s, 'UTF-8' ) > $n ) ? mb_substr( $s, 0, $n, 'UTF-8' ) . '…' : $s;
		}
		return ( strlen( $s ) > $n ) ? substr( $s, 0, $n ) . '…' : $s;
	}

	public static function len( $s ) {
		return function_exists( 'mb_strlen' ) ? mb_strlen( (string) $s, 'UTF-8' ) : strlen( (string) $s );
	}

	public static function str( $v ) {
		if ( is_string( $v ) ) {
			return $v;
		}
		if ( is_bool( $v ) ) {
			return $v ? 'true' : 'false';
		}
		if ( null === $v ) {
			return '';
		}
		if ( is_scalar( $v ) ) {
			return (string) $v;
		}
		$j = wp_json_encode( $v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR );
		return is_string( $j ) ? $j : '';
	}

	private static function short_url( $u ) {
		$p    = wp_parse_url( preg_match( '#^//#', $u ) ? 'https:' . $u : $u );
		$host = isset( $p['host'] ) ? $p['host'] : '';
		$path = isset( $p['path'] ) ? $p['path'] : '';
		return $host ? $host . self::cut( $path, 40 ) : self::cut( $u, 70 );
	}

	/**
	 * Extract <script> and <iframe> elements from a string (HTML, JSON or serialized data).
	 */
	public static function extract( $s ) {
		$out = array();
		if ( ! is_string( $s ) || '' === $s ) {
			return $out;
		}
		if ( false === stripos( $s, '<script' ) && false === stripos( $s, '<iframe' ) && false === stripos( $s, 'u003cscript' ) && false === stripos( $s, 'u003ciframe' ) ) {
			return $out;
		}
		if ( strlen( $s ) > 2000000 ) {
			$s = substr( $s, 0, 2000000 );
		}
		if ( false !== strpos( $s, '\\' ) ) {
			$s = str_replace(
				array( '\\/', '\\"', '\\n', '\\r', '\\t', '\\u003c', '\\u003C', '\\u003e', '\\u003E' ),
				array( '/', '"', "\n", "\r", "\t", '<', '<', '>', '>' ),
				$s
			);
		}

		if ( preg_match_all( '#<script\b([^>]*)>(.*?)</script\s*>#is', $s, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $x ) {
				$attrs = $x[1];
				$body  = trim( $x[2] );
				$src   = '';
				if ( preg_match( '#\bsrc\s*=\s*["\']?([^"\'\s>]+)#i', $attrs, $sm ) ) {
					$src = $sm[1];
				}
				if ( '' !== $src ) {
					$key         = 'src:' . strtolower( preg_replace( '#^https?:#i', '', $src ) );
					$out[ $key ] = array(
						'kind'  => 'script',
						'label' => self::short_url( $src ),
						'ad'    => (bool) preg_match( self::AD_RE, $src ),
						'obf'   => false,
					);
				} elseif ( '' !== $body ) {
					$key         = 'inl:' . md5( preg_replace( '/\s+/', '', $body ) );
					$out[ $key ] = array(
						'kind'  => 'inline',
						'label' => 'اسکریپت درون‌خطی (' . self::len( $body ) . ' کاراکتر): ' . self::cut( preg_replace( '/\s+/', ' ', $body ), 60 ),
						'ad'    => (bool) preg_match( self::AD_RE, $body ),
						'obf'   => (bool) preg_match( self::OBF_RE, $body ),
					);
				}
				if ( count( $out ) >= 50 ) {
					break;
				}
			}
		}
		if ( preg_match_all( '#<iframe\b([^>]*)>#i', $s, $m2, PREG_SET_ORDER ) ) {
			foreach ( $m2 as $x ) {
				$src = '';
				if ( preg_match( '#\bsrc\s*=\s*["\']?([^"\'\s>]+)#i', $x[1], $sm ) ) {
					$src = $sm[1];
				}
				$key         = 'ifr:' . strtolower( $src ? preg_replace( '#^https?:#i', '', $src ) : md5( $x[1] ) );
				$out[ $key ] = array(
					'kind'  => 'iframe',
					'label' => $src ? self::short_url( $src ) : 'iframe بدون آدرس',
					'ad'    => (bool) preg_match( self::AD_RE, $src ),
					'obf'   => false,
				);
				if ( count( $out ) >= 60 ) {
					break;
				}
			}
		}
		return $out;
	}

	public static function diff( $old, $new ) {
		$a = self::extract( $old );
		$b = self::extract( $new );
		return array(
			'added'   => array_values( array_diff_key( $b, $a ) ),
			'removed' => array_values( array_diff_key( $a, $b ) ),
		);
	}

	public static function has( $d ) {
		return ! empty( $d['added'] ) || ! empty( $d['removed'] );
	}

	public static function diff_severity( $d, $user_id ) {
		foreach ( $d['added'] as $it ) {
			if ( ! empty( $it['obf'] ) ) {
				return 'danger';
			}
		}
		if ( $d['added'] && ! $user_id ) {
			return 'danger';
		}
		return 'warning';
	}

	private static function item_text( $it ) {
		if ( 'inline' === $it['kind'] ) {
			return $it['label'] . ( $it['ad'] ? ' (تبلیغاتی)' : '' ) . ( $it['obf'] ? ' (مشکوک/مبهم‌سازی‌شده)' : '' );
		}
		$name = ( 'iframe' === $it['kind'] ) ? 'iframe' : 'اسکریپت';
		return $name . ( $it['ad'] ? ' تبلیغاتی' : '' ) . ': ' . $it['label'];
	}

	public static function diff_summary( $d ) {
		$parts = array();
		foreach ( array_slice( $d['removed'], 0, 3 ) as $it ) {
			$parts[] = 'حذف ' . self::item_text( $it );
		}
		foreach ( array_slice( $d['added'], 0, 3 ) as $it ) {
			$parts[] = 'افزودن ' . self::item_text( $it );
		}
		$extra = max( 0, count( $d['removed'] ) - 3 ) + max( 0, count( $d['added'] ) - 3 );
		$s     = implode( '؛ ', $parts );
		if ( $extra ) {
			$s .= ' و ' . $extra . ' مورد دیگر';
		}
		return $s;
	}

	public static function option_label( $name ) {
		static $map = array(
			'siteurl'            => 'آدرس وردپرس (siteurl)',
			'home'               => 'آدرس سایت (home)',
			'blogname'           => 'عنوان سایت',
			'blogdescription'    => 'توضیح کوتاه سایت',
			'admin_email'        => 'ایمیل مدیر',
			'users_can_register' => 'ثبت‌نام کاربران',
			'default_role'       => 'نقش پیش‌فرض کاربران',
			'permalink_structure' => 'ساختار پیوند یکتا',
			'blog_public'        => 'نمایش در موتورهای جستجو',
			'template'           => 'پوسته (template)',
			'stylesheet'         => 'پوسته (stylesheet)',
			'sidebars_widgets'   => 'چیدمان ابزارک‌ها',
			'widget_custom_html' => 'ابزارک HTML سفارشی',
			'widget_text'        => 'ابزارک متن',
			'widget_block'       => 'ابزارک‌های بلوکی',
			'nav_menu_options'   => 'تنظیمات منو',
			'WPLANG'             => 'زبان سایت',
		);
		if ( isset( $map[ $name ] ) ) {
			return $map[ $name ];
		}
		if ( preg_match( '/^theme_mods_(.+)$/', $name, $m ) ) {
			return 'تنظیمات پوسته (' . $m[1] . ')';
		}
		if ( preg_match( '/user_roles$/', $name ) ) {
			return 'نقش‌ها و دسترسی‌ها';
		}
		return $name;
	}

	public static function option_category( $name ) {
		if ( 'sidebars_widgets' === $name || 0 === strpos( $name, 'widget_' ) ) {
			return 'widget';
		}
		if ( 0 === strpos( $name, 'theme_mods_' ) || 'template' === $name || 'stylesheet' === $name ) {
			return 'theme';
		}
		return 'option';
	}

	/**
	 * Build an event description for an option change.
	 */
	public static function describe_option( $name, $old, $new, $action, $user_id ) {
		$label  = self::option_label( $name );
		$secret = (bool) preg_match( self::SECRET_RE, $name );
		$o      = self::str( $old );
		$n      = self::str( $new );
		$diff   = $secret ? array( 'added' => array(), 'removed' => array() ) : self::diff( $o, $n );
		$sev    = 'info';
		$det    = array( 'name' => $name );
		$keys   = array();

		if ( is_array( $old ) && is_array( $new ) ) {
			foreach ( array_unique( array_merge( array_keys( $old ), array_keys( $new ) ) ) as $k ) {
				if ( ! array_key_exists( $k, $old ) || ! array_key_exists( $k, $new ) || $old[ $k ] !== $new[ $k ] ) {
					$keys[] = (string) $k;
				}
			}
			$keys = array_slice( $keys, 0, 50 );
		}

		if ( self::has( $diff ) ) {
			$sev            = self::diff_severity( $diff, $user_id );
			$summary        = 'تغییر کد در «' . $label . '»: ' . self::diff_summary( $diff );
			$det['diff']    = $diff;
		} elseif ( 'added' === $action ) {
			$summary = 'گزینه «' . $label . '» ایجاد شد';
		} elseif ( 'deleted' === $action ) {
			$summary = 'گزینه «' . $label . '» حذف شد';
		} else {
			if ( ! $secret && ! is_array( $old ) && ! is_array( $new ) && self::len( $o ) <= 60 && self::len( $n ) <= 60 ) {
				$summary = '«' . $label . '» از «' . $o . '» به «' . $n . '» تغییر کرد';
			} else {
				$summary = '«' . $label . '» تغییر کرد';
				if ( $secret ) {
					$summary .= ' (مقدار مخفی)';
				} elseif ( $keys ) {
					$summary .= ' (کلیدها: ' . implode( '، ', array_slice( $keys, 0, 4 ) ) . ( count( $keys ) > 4 ? '…' : '' ) . ')';
				}
			}
		}

		$sens = array(
			'siteurl'            => 'warning',
			'home'               => 'warning',
			'admin_email'        => 'warning',
			'users_can_register' => 'warning',
			'default_role'       => 'warning',
			'template'           => 'notice',
			'stylesheet'         => 'notice',
			'permalink_structure' => 'notice',
			'blog_public'        => 'notice',
		);
		if ( isset( $sens[ $name ] ) ) {
			$sev = self::max_sev( $sev, $sens[ $name ] );
		}
		if ( 'default_role' === $name && 'administrator' === $n ) {
			$sev = 'danger';
		}
		if ( preg_match( '/user_roles$/', $name ) ) {
			$sev = self::max_sev( $sev, 'warning' );
		}

		$det['before'] = $secret ? '[مخفی]' : ( 'added' === $action ? '' : self::cut( $o, 3000 ) );
		$det['after']  = $secret ? '[مخفی]' : ( 'deleted' === $action ? '' : self::cut( $n, 3000 ) );
		if ( $keys ) {
			$det['keys'] = $keys;
		}

		return array(
			'category'     => self::option_category( $name ),
			'action'       => $action,
			'severity'     => $sev,
			'summary'      => $summary,
			'object_type'  => 'option',
			'object_id'    => $name,
			'object_label' => $label,
			'details'      => $det,
		);
	}
}

/**
 * The audit log: captures semantic changes through WordPress hooks (with before / after
 * values) and raw SQL writes (aggregated per request), and exposes query helpers for the UI.
 */
class DBS_Activity {

	private static $busy = false;
	private static $buf  = array();
	private static $agg  = array();
	private static $conf = null;
	private static $noise = null;

	/** When true nothing is logged (used while the plugin itself applies an undo / bulk tool). */
	public static $suppress = false;

	private static $skip_types = array( 'revision', 'auto-draft', 'oembed_cache', 'customize_changeset', 'scheduled-action', 'nav_menu_item', 'shop_order_placehold', 'user_request' );

	public static function table() {
		global $wpdb;
		return $wpdb->base_prefix . 'dbs_activity';
	}

	/* --------------------------------------------------------------------- *
	 * Installation
	 * --------------------------------------------------------------------- */

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t       = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$t} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  created_at datetime NOT NULL,
  kind varchar(8) NOT NULL DEFAULT 'event',
  category varchar(24) NOT NULL DEFAULT '',
  action varchar(24) NOT NULL DEFAULT '',
  severity varchar(8) NOT NULL DEFAULT 'info',
  summary varchar(500) NOT NULL DEFAULT '',
  object_type varchar(32) NOT NULL DEFAULT '',
  object_id varchar(191) NOT NULL DEFAULT '',
  object_label varchar(255) NOT NULL DEFAULT '',
  details longtext NULL,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  user_login varchar(60) NOT NULL DEFAULT '',
  user_role varchar(40) NOT NULL DEFAULT '',
  actor_type varchar(12) NOT NULL DEFAULT '',
  actor_slug varchar(120) NOT NULL DEFAULT '',
  context varchar(12) NOT NULL DEFAULT '',
  request varchar(255) NOT NULL DEFAULT '',
  ip varchar(64) NOT NULL DEFAULT '',
  table_name varchar(64) NOT NULL DEFAULT '',
  sql_op varchar(12) NOT NULL DEFAULT '',
  row_count int(10) unsigned NOT NULL DEFAULT 1,
  undo longtext NULL,
  undone tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY created_at (created_at),
  KEY kind_created (kind,created_at),
  KEY user_login (user_login),
  KEY actor (actor_type,actor_slug),
  KEY category (category)
) {$charset};";
		dbDelta( $sql );
	}

	public static function maybe_install() {
		if ( get_option( 'dbs_db_version' ) !== DBS_VERSION ) {
			self::install();
			update_option( 'dbs_db_version', DBS_VERSION, false );
		}
	}

	/* --------------------------------------------------------------------- *
	 * Hooks
	 * --------------------------------------------------------------------- */

	public static function init() {
		self::$conf = DBS_Settings::all();

		if ( ! empty( self::$conf['log_sql'] ) ) {
			add_filter( 'query', array( __CLASS__, 'on_query' ), 1 );
		}

		if ( ! empty( self::$conf['log_events'] ) ) {
			add_action( 'added_option', array( __CLASS__, 'on_added_option' ), 10, 2 );
			add_action( 'updated_option', array( __CLASS__, 'on_updated_option' ), 10, 3 );
			add_action( 'delete_option', array( __CLASS__, 'on_delete_option' ), 10, 1 );

			add_action( 'wp_after_insert_post', array( __CLASS__, 'on_post' ), 10, 4 );
			add_action( 'before_delete_post', array( __CLASS__, 'on_delete_post' ), 10, 2 );
			add_action( 'wp_trash_post', array( __CLASS__, 'on_trash_post' ), 10, 1 );
			add_filter( 'update_post_metadata', array( __CLASS__, 'on_update_meta' ), 10, 4 );
			add_filter( 'add_post_metadata', array( __CLASS__, 'on_add_meta' ), 10, 4 );

			add_action( 'user_register', array( __CLASS__, 'on_user_register' ), 10, 1 );
			add_action( 'profile_update', array( __CLASS__, 'on_profile_update' ), 10, 2 );
			add_action( 'set_user_role', array( __CLASS__, 'on_set_role' ), 10, 3 );
			add_action( 'add_user_role', array( __CLASS__, 'on_add_role' ), 10, 2 );
			add_action( 'remove_user_role', array( __CLASS__, 'on_remove_role' ), 10, 2 );
			add_action( 'delete_user', array( __CLASS__, 'on_delete_user' ), 10, 1 );

			add_action( 'deleted_plugin', array( __CLASS__, 'on_deleted_plugin' ), 10, 2 );
			add_action( 'switch_theme', array( __CLASS__, 'on_switch_theme' ), 10, 3 );
			add_action( 'upgrader_process_complete', array( __CLASS__, 'on_upgrader' ), 10, 2 );
			add_action( 'wp_update_nav_menu', array( __CLASS__, 'on_nav_menu' ), 10, 1 );
		}

		add_action( 'shutdown', array( __CLASS__, 'flush' ), 9999 );
		add_action( 'admin_init', array( __CLASS__, 'maybe_install' ) );
	}

	/* --------------------------------------------------------------------- *
	 * Noise filter
	 * --------------------------------------------------------------------- */

	private static function is_noise( $name ) {
		if ( null === self::$noise ) {
			self::$noise = array(
				'sub'   => array( '_transient', '_site_transient', 'action_scheduler', '_wc_session', '_edit_', 'session_tokens', 'user-settings', 'dismissed_wp_pointers', '_woocommerce_persistent_cart', 'persisted_preferences' ),
				'exact' => array( 'cron', 'rewrite_rules', 'recently_activated' ),
			);
			$extra = preg_split( '/\R/', (string) ( self::$conf ? self::$conf['ignore_patterns'] : '' ) );
			foreach ( (array) $extra as $x ) {
				$x = trim( $x );
				if ( '' !== $x ) {
					self::$noise['sub'][] = $x;
				}
			}
		}
		if ( in_array( $name, self::$noise['exact'], true ) ) {
			return true;
		}
		foreach ( self::$noise['sub'] as $p ) {
			if ( false !== stripos( $name, $p ) ) {
				return true;
			}
		}
		return false;
	}

	private static function skip_option( $name ) {
		return ( 0 === strpos( $name, 'dbs_' ) ) || self::is_noise( $name );
	}

	/* --------------------------------------------------------------------- *
	 * Event buffer
	 * --------------------------------------------------------------------- */

	/**
	 * Queue a semantic event. The context (user / component / request) is captured now,
	 * while the call stack still shows who triggered the change.
	 */
	public static function record( $e ) {
		if ( self::$busy || self::$suppress ) {
			return;
		}
		$row = array_merge(
			array(
				'created_at'   => gmdate( 'Y-m-d H:i:s' ),
				'kind'         => 'event',
				'category'     => '',
				'action'       => '',
				'severity'     => 'info',
				'summary'      => '',
				'object_type'  => '',
				'object_id'    => '',
				'object_label' => '',
				'details'      => null,
				'table_name'   => '',
				'sql_op'       => '',
				'row_count'    => 1,
			),
			DBS_Context::snapshot(),
			$e
		);
		self::$buf[] = $row;
		if ( count( self::$buf ) >= 50 || did_action( 'shutdown' ) ) {
			self::flush();
		}
	}

	public static function flush() {
		global $wpdb;
		if ( self::$busy || ( empty( self::$buf ) && empty( self::$agg ) ) ) {
			return;
		}
		self::$busy = true;

		$rows = self::$buf;
		foreach ( self::$agg as $a ) {
			$ops   = array(
				'INSERT'   => 'درج در',
				'UPDATE'   => 'به‌روزرسانی',
				'DELETE'   => 'حذف از',
				'REPLACE'  => 'جایگزینی در',
				'ALTER'    => 'تغییر ساختار',
				'DROP'     => 'حذف جدول',
				'CREATE'   => 'ساخت جدول',
				'TRUNCATE' => 'خالی‌کردن',
				'RENAME'   => 'تغییر نام',
			);
			$label = isset( $ops[ $a['sql_op'] ] ) ? $ops[ $a['sql_op'] ] : $a['sql_op'];

			$a['summary']      = $label . ' ' . $a['table_name'] . ' (' . $a['row_count'] . ' دستور)';
			$a['object_label'] = implode( '، ', $a['objs'] );
			$a['details']      = array(
				'sample'  => $a['sample'],
				'objects' => $a['objs'],
			);
			if ( ! in_array( $a['sql_op'], array( 'INSERT', 'UPDATE', 'DELETE', 'REPLACE' ), true ) ) {
				$a['severity'] = 'notice';
			}
			if ( empty( $a['user_id'] ) ) {
				$a = array_merge( $a, DBS_Context::user() );
			}
			unset( $a['objs'], $a['sample'] );
			$rows[] = $a;
		}
		self::$buf = array();
		self::$agg = array();

		$danger   = array();
		$suppress = $wpdb->suppress_errors( true );
		$t        = self::table();
		$formats  = array(
			'created_at' => '%s', 'kind' => '%s', 'category' => '%s', 'action' => '%s', 'severity' => '%s',
			'summary' => '%s', 'object_type' => '%s', 'object_id' => '%s', 'object_label' => '%s', 'details' => '%s',
			'user_id' => '%d', 'user_login' => '%s', 'user_role' => '%s', 'actor_type' => '%s', 'actor_slug' => '%s',
			'context' => '%s', 'request' => '%s', 'ip' => '%s', 'table_name' => '%s', 'sql_op' => '%s', 'row_count' => '%d', 'undo' => '%s', 'undone' => '%d',
		);
		$limits   = array(
			'category' => 24, 'action' => 24, 'severity' => 8, 'summary' => 480, 'object_type' => 32, 'object_id' => 190,
			'object_label' => 250, 'user_login' => 60, 'user_role' => 40, 'actor_type' => 12, 'actor_slug' => 120,
			'context' => 12, 'request' => 250, 'ip' => 64, 'table_name' => 64, 'sql_op' => 12,
		);
		foreach ( $rows as $row ) {
			$data = array();
			$fmt  = array();
			foreach ( $formats as $col => $f ) {
				$v = isset( $row[ $col ] ) ? $row[ $col ] : ( '%d' === $f ? 0 : '' );
				if ( 'details' === $col ) {
					$v = ( is_array( $v ) && $v ) ? wp_json_encode( $v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR ) : null;
					if ( is_string( $v ) && strlen( $v ) > 60000 ) {
						$v = null;
					}
				} elseif ( 'undo' === $col ) {
					$v = ( is_array( $v ) && $v ) ? wp_json_encode( $v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR ) : null;
					if ( is_string( $v ) && strlen( $v ) > 400000 ) {
						$v = null;
					}
				} elseif ( isset( $limits[ $col ] ) ) {
					$v = DBS_Inspect::cut( $v, $limits[ $col ] );
				}
				$data[ $col ] = $v;
				$fmt[]        = $f;
			}
			$wpdb->insert( $t, $data, $fmt );
			if ( isset( $row['severity'] ) && 'danger' === $row['severity'] && ( ! isset( $row['category'] ) || 'anomaly' !== $row['category'] ) ) {
				$danger[] = $row;
			}
		}
		$wpdb->suppress_errors( $suppress );
		self::$busy = false;

		if ( $danger ) {
			DBS_Notify::danger( $danger );
		}
		DBS_Anomaly::check( $rows );
	}

	/* --------------------------------------------------------------------- *
	 * Raw SQL layer
	 * --------------------------------------------------------------------- */

	public static function on_query( $sql ) {
		if ( self::$busy || self::$suppress || ! is_string( $sql ) ) {
			return $sql;
		}
		if ( ! preg_match( '/^\s*(INSERT|UPDATE|DELETE|REPLACE|ALTER|DROP|CREATE|TRUNCATE|RENAME)\b/i', substr( $sql, 0, 60 ), $m ) ) {
			return $sql;
		}
		self::$busy = true;
		try {
			self::capture_sql( strtoupper( $m[1] ), $sql );
		} catch ( Throwable $e ) {
			// Never break a query because of logging.
			unset( $e );
		}
		self::$busy = false;
		return $sql;
	}

	private static function parse_table( $op, $head ) {
		static $re = array(
			'INSERT'  => '/^\s*INSERT\s+(?:LOW_PRIORITY\s+|DELAYED\s+|HIGH_PRIORITY\s+)?(?:IGNORE\s+)?(?:INTO\s+)?`?([\w$]+)`?/i',
			'REPLACE' => '/^\s*REPLACE\s+(?:LOW_PRIORITY\s+|DELAYED\s+)?(?:INTO\s+)?`?([\w$]+)`?/i',
			'UPDATE'  => '/^\s*UPDATE\s+(?:LOW_PRIORITY\s+)?(?:IGNORE\s+)?`?([\w$]+)`?/i',
			'DELETE'  => '/^\s*DELETE\s+(?:LOW_PRIORITY\s+|QUICK\s+|IGNORE\s+)*FROM\s+`?([\w$]+)`?/i',
		);
		$r = isset( $re[ $op ] ) ? $re[ $op ] : '/^\s*(?:ALTER|DROP|CREATE|TRUNCATE|RENAME)\s+(?:TEMPORARY\s+)?(?:TABLE\s+)?(?:IF\s+(?:NOT\s+)?EXISTS\s+)?`?([\w$]+)`?/i';
		return preg_match( $r, $head, $m ) ? $m[1] : '';
	}

	private static function sql_object( $table, $sql ) {
		$tail = ( strlen( $sql ) > 600 ) ? substr( $sql, -400 ) : $sql;
		if ( preg_match( '/_options$/', $table ) ) {
			if ( preg_match( "/option_name`?\s*=\s*'([^']{1,190})'/", $tail, $m ) ) {
				return $m[1];
			}
			if ( preg_match( "/VALUES\s*\(\s*'([^']{1,190})'/i", substr( $sql, 0, 500 ), $m ) ) {
				return $m[1];
			}
		} elseif ( preg_match( '/(postmeta|usermeta|termmeta|commentmeta)$/', $table ) ) {
			if ( preg_match( "/meta_key`?\s*=\s*'([^']{1,190})'/", $tail, $m ) ) {
				return $m[1];
			}
			if ( preg_match( "/VALUES\s*\(\s*'?\d+'?\s*,\s*'([^']{1,190})'/i", substr( $sql, 0, 500 ), $m ) ) {
				return $m[1];
			}
		}
		return '';
	}

	private static function mask_sql( $table, $sql, $obj ) {
		if ( preg_match( '/(users|usermeta)$/', $table ) ) {
			return '(مقادیر جدول کاربران نمایش داده نمی‌شود)';
		}
		if ( $obj && preg_match( DBS_Inspect::SECRET_RE, $obj ) ) {
			return '(مقدار مخفی)';
		}
		$s = substr( $sql, 0, 3000 );
		$r = preg_replace_callback(
			"/'((?:[^'\\\\]|\\\\.|'')*)'/s",
			function ( $m ) {
				return ( strlen( $m[1] ) > 40 ) ? "'" . DBS_Inspect::cut( $m[1], 40 ) . "'" : $m[0];
			},
			$s
		);
		if ( null === $r ) {
			$r = substr( $sql, 0, 200 );
		}
		return DBS_Inspect::cut( $r, 600 );
	}

	private static function capture_sql( $op, $sql ) {
		global $wpdb;
		$table = self::parse_table( $op, substr( $sql, 0, 500 ) );
		if ( '' === $table || self::table() === $table ) {
			return;
		}
		$low = strtolower( $table );
		if ( false !== strpos( $low, 'actionscheduler' ) || false !== strpos( $low, 'woocommerce_sessions' ) ) {
			return;
		}

		$req = DBS_Context::request();
		if ( 'frontend' === $req['context'] && empty( self::$conf['log_sql_frontend'] ) ) {
			return;
		}

		$obj = self::sql_object( $table, $sql );
		if ( '' !== $obj && ( 0 === strpos( $obj, 'dbs_' ) || self::is_noise( $obj ) ) ) {
			return;
		}

		$ctx = DBS_Context::snapshot( $req );
		$key = $table . '|' . $op . '|' . $ctx['actor_type'] . ':' . $ctx['actor_slug'] . '|' . $ctx['user_id'];
		if ( isset( self::$agg[ $key ] ) ) {
			self::$agg[ $key ]['row_count']++;
			if ( '' !== $obj && count( self::$agg[ $key ]['objs'] ) < 6 && ! in_array( $obj, self::$agg[ $key ]['objs'], true ) ) {
				self::$agg[ $key ]['objs'][] = $obj;
			}
			return;
		}
		self::$agg[ $key ] = array_merge(
			$ctx,
			array(
				'created_at'  => gmdate( 'Y-m-d H:i:s' ),
				'kind'        => 'sql',
				'category'    => 'db',
				'action'      => strtolower( $op ),
				'severity'    => 'info',
				'object_type' => 'table',
				'object_id'   => $table,
				'table_name'  => $table,
				'sql_op'      => $op,
				'row_count'   => 1,
				'objs'        => ( '' !== $obj ) ? array( $obj ) : array(),
				'sample'      => self::mask_sql( $table, $sql, $obj ),
			)
		);
	}

	/* --------------------------------------------------------------------- *
	 * Semantic events: options
	 * --------------------------------------------------------------------- */

	private static function option_event( $name, $old, $new, $action ) {
		$u  = DBS_Context::user();
		$ev = DBS_Inspect::describe_option( $name, $old, $new, $action, $u['user_id'] );
		if ( ! preg_match( DBS_Inspect::SECRET_RE, $name ) ) {
			$h = md5( maybe_serialize( $new ) );
			if ( 'updated' === $action ) {
				$ev['undo'] = array( 't' => 'option', 'op' => 'set', 'name' => $name, 'value' => maybe_serialize( $old ), 'h' => $h );
			} elseif ( 'added' === $action ) {
				$ev['undo'] = array( 't' => 'option', 'op' => 'delete', 'name' => $name, 'h' => $h );
			} else {
				$ev['undo'] = array( 't' => 'option', 'op' => 'add', 'name' => $name, 'value' => maybe_serialize( $old ) );
			}
		}
		self::record( $ev );
	}

	public static function on_added_option( $name, $value ) {
		if ( self::$busy || self::skip_option( $name ) ) {
			return;
		}
		self::option_event( $name, null, $value, 'added' );
	}

	public static function on_updated_option( $name, $old, $new ) {
		if ( self::$busy || self::skip_option( $name ) ) {
			return;
		}
		if ( 'active_plugins' === $name ) {
			self::plugins_diff( $old, $new );
			return;
		}
		self::option_event( $name, $old, $new, 'updated' );
	}

	public static function on_delete_option( $name ) {
		if ( self::$busy || self::skip_option( $name ) ) {
			return;
		}
		$old = get_option( $name, '__dbs_none__' );
		if ( '__dbs_none__' === $old ) {
			return;
		}
		self::option_event( $name, $old, null, 'deleted' );
	}

	/* --------------------------------------------------------------------- *
	 * Semantic events: posts
	 * --------------------------------------------------------------------- */

	private static function type_label( $type ) {
		$o = get_post_type_object( $type );
		return ( $o && ! empty( $o->labels->singular_name ) ) ? $o->labels->singular_name : $type;
	}

	private static function post_title( $post ) {
		return $post->post_title ? DBS_Inspect::cut( wp_strip_all_tags( $post->post_title ), 60 ) : '(بدون عنوان)';
	}

	public static function on_post( $post_id, $post, $update, $before ) {
		if ( self::$busy || ! $post || in_array( $post->post_type, self::$skip_types, true ) || 'auto-draft' === $post->post_status ) {
			return;
		}
		$tl    = self::type_label( $post->post_type );
		$title = self::post_title( $post );
		$user  = DBS_Context::user();

		if ( ! $update ) {
			$d   = DBS_Inspect::diff( '', $post->post_content );
			$sev = DBS_Inspect::has( $d ) ? DBS_Inspect::diff_severity( $d, $user['user_id'] ) : 'info';
			$det = array( 'status' => $post->post_status );
			if ( DBS_Inspect::has( $d ) ) {
				$det['diff'] = $d;
			}
			self::record(
				array(
					'category'     => 'post',
					'action'       => 'created',
					'severity'     => $sev,
					'summary'      => $tl . ' جدید «' . $title . '» ساخته شد' . ( DBS_Inspect::has( $d ) ? ' — ' . DBS_Inspect::diff_summary( $d ) : '' ),
					'object_type'  => $post->post_type,
					'object_id'    => (string) $post_id,
					'object_label' => $title,
					'details'      => $det,
					'undo'         => array( 't' => 'post_trash', 'id' => (int) $post_id ),
				)
			);
			return;
		}

		if ( ! $before ) {
			return;
		}
		$fields  = array(
			'post_title'    => 'عنوان',
			'post_content'  => 'محتوا',
			'post_excerpt'  => 'خلاصه',
			'post_status'   => 'وضعیت',
			'post_name'     => 'نامک',
			'post_author'   => 'نویسنده',
			'post_parent'   => 'والد',
			'post_password' => 'رمز نوشته',
		);
		$changed = array();
		$changes = array();
		foreach ( $fields as $f => $lbl ) {
			if ( (string) $post->$f !== (string) $before->$f ) {
				$changed[] = $lbl;
				if ( 'post_content' === $f ) {
					$changes[] = array(
						'field'  => $lbl,
						'before' => ( DBS_Inspect::len( $before->$f ) ) . ' کاراکتر',
						'after'  => ( DBS_Inspect::len( $post->$f ) ) . ' کاراکتر',
					);
				} elseif ( 'post_password' === $f ) {
					$changes[] = array( 'field' => $lbl, 'before' => '[مخفی]', 'after' => '[مخفی]' );
				} else {
					$changes[] = array(
						'field'  => $lbl,
						'before' => DBS_Inspect::cut( (string) $before->$f, 200 ),
						'after'  => DBS_Inspect::cut( (string) $post->$f, 200 ),
					);
				}
			}
		}
		if ( ! $changed ) {
			return;
		}
		$d   = DBS_Inspect::diff( $before->post_content, $post->post_content );
		$sev = 'info';
		if ( DBS_Inspect::has( $d ) ) {
			$sev = DBS_Inspect::diff_severity( $d, $user['user_id'] );
		} elseif ( array_intersect( $changed, array( 'نویسنده', 'رمز نوشته' ) ) ) {
			$sev = 'notice';
		}
		$det = array( 'changes' => $changes );
		if ( DBS_Inspect::has( $d ) ) {
			$det['diff'] = $d;
		}
		$undo_fields = array();
		$after_vals  = array();
		foreach ( array_keys( $fields ) as $f ) {
			if ( 'post_password' !== $f && (string) $post->$f !== (string) $before->$f ) {
				$undo_fields[ $f ] = (string) $before->$f;
				$after_vals[ $f ]  = (string) $post->$f;
			}
		}
		self::record(
			array(
				'category'     => 'post',
				'action'       => 'updated',
				'severity'     => $sev,
				'summary'      => 'ویرایش ' . $tl . ' «' . $title . '»: ' . implode( '، ', $changed ) . ( DBS_Inspect::has( $d ) ? ' — ' . DBS_Inspect::diff_summary( $d ) : '' ),
				'object_type'  => $post->post_type,
				'object_id'    => (string) $post_id,
				'object_label' => $title,
				'details'      => $det,
				'undo'         => $undo_fields ? array( 't' => 'post', 'id' => (int) $post_id, 'fields' => $undo_fields, 'k' => array_keys( $after_vals ), 'h' => md5( wp_json_encode( $after_vals ) ) ) : null,
			)
		);
	}

	public static function on_delete_post( $post_id, $post = null ) {
		if ( self::$busy ) {
			return;
		}
		$post = $post ? $post : get_post( $post_id );
		if ( ! $post || in_array( $post->post_type, self::$skip_types, true ) || 'auto-draft' === $post->post_status ) {
			return;
		}
		self::record(
			array(
				'category'     => 'post',
				'action'       => 'deleted',
				'severity'     => 'notice',
				'summary'      => 'حذف دائمی ' . self::type_label( $post->post_type ) . ' «' . self::post_title( $post ) . '»',
				'object_type'  => $post->post_type,
				'object_id'    => (string) $post_id,
				'object_label' => self::post_title( $post ),
			)
		);
	}

	public static function on_trash_post( $post_id ) {
		if ( self::$busy ) {
			return;
		}
		$post = get_post( $post_id );
		if ( ! $post || in_array( $post->post_type, self::$skip_types, true ) ) {
			return;
		}
		self::record(
			array(
				'category'     => 'post',
				'action'       => 'trashed',
				'severity'     => 'info',
				'summary'      => 'انتقال ' . self::type_label( $post->post_type ) . ' «' . self::post_title( $post ) . '» به زباله‌دان',
				'object_type'  => $post->post_type,
				'object_id'    => (string) $post_id,
				'object_label' => self::post_title( $post ),
				'undo'         => array( 't' => 'post_untrash', 'id' => (int) $post_id ),
			)
		);
	}

	private static function meta_check( $post_id, $key, $value, $is_add ) {
		if ( self::$busy || ! is_string( $key ) ) {
			return;
		}
		if ( 0 === strpos( $key, '_edit_' ) || 0 === strpos( $key, '_wp_' ) || 0 === strpos( $key, '_thumbnail' ) ) {
			return;
		}
		if ( ! is_string( $value ) && ! is_array( $value ) && ! is_object( $value ) ) {
			return;
		}
		$post = get_post( $post_id );
		if ( ! $post || in_array( $post->post_type, self::$skip_types, true ) ) {
			return;
		}
		$new = DBS_Inspect::str( $value );
		$old = $is_add ? '' : DBS_Inspect::str( get_post_meta( $post_id, $key, true ) );
		$d   = DBS_Inspect::diff( $old, $new );
		if ( ! DBS_Inspect::has( $d ) ) {
			return;
		}
		$u = DBS_Context::user();
		self::record(
			array(
				'category'     => 'meta',
				'action'       => $is_add ? 'added' : 'updated',
				'severity'     => DBS_Inspect::diff_severity( $d, $u['user_id'] ),
				'summary'      => 'تغییر کد در فیلد «' . DBS_Inspect::cut( $key, 40 ) . '» (' . self::type_label( $post->post_type ) . ' «' . self::post_title( $post ) . '»): ' . DBS_Inspect::diff_summary( $d ),
				'object_type'  => 'postmeta',
				'object_id'    => $post_id . ':' . $key,
				'object_label' => self::post_title( $post ),
				'details'      => array(
					'diff' => $d,
					'key'  => $key,
				),
				'undo'         => $is_add ? array( 't' => 'meta', 'op' => 'delete', 'id' => (int) $post_id, 'key' => $key ) : array( 't' => 'meta', 'op' => 'set', 'id' => (int) $post_id, 'key' => $key, 'value' => maybe_serialize( get_post_meta( $post_id, $key, true ) ) ),
			)
		);
	}

	public static function on_update_meta( $check, $post_id, $key, $value ) {
		self::meta_check( $post_id, $key, $value, false );
		return $check;
	}

	public static function on_add_meta( $check, $post_id, $key, $value ) {
		self::meta_check( $post_id, $key, $value, true );
		return $check;
	}

	/* --------------------------------------------------------------------- *
	 * Semantic events: users
	 * --------------------------------------------------------------------- */

	private static function role_label( $role ) {
		static $map = array(
			'administrator' => 'مدیر کل',
			'editor'        => 'ویرایشگر',
			'author'        => 'نویسنده',
			'contributor'   => 'مشارکت‌کننده',
			'subscriber'    => 'مشترک',
			'shop_manager'  => 'مدیر فروشگاه',
			'customer'      => 'مشتری',
		);
		return isset( $map[ $role ] ) ? $map[ $role ] : $role;
	}

	public static function on_user_register( $user_id ) {
		$u = get_userdata( $user_id );
		if ( self::$busy || ! $u ) {
			return;
		}
		$roles = (array) $u->roles;
		self::record(
			array(
				'category'     => 'user',
				'action'       => 'created',
				'severity'     => in_array( 'administrator', $roles, true ) ? 'danger' : 'notice',
				'summary'      => 'کاربر جدید «' . $u->user_login . '» با نقش ' . self::role_label( (string) reset( $roles ) ) . ' ساخته شد',
				'object_type'  => 'user',
				'object_id'    => (string) $user_id,
				'object_label' => $u->user_login,
				'details'      => array( 'roles' => $roles ),
			)
		);
	}

	public static function on_profile_update( $user_id, $old ) {
		$u = get_userdata( $user_id );
		if ( self::$busy || ! $u || ! $old ) {
			return;
		}
		$ch = array();
		if ( $u->user_email !== $old->user_email ) {
			$ch[] = 'ایمیل';
		}
		if ( $u->user_pass !== $old->user_pass ) {
			$ch[] = 'رمز عبور';
		}
		if ( $u->display_name !== $old->display_name ) {
			$ch[] = 'نام نمایشی';
		}
		if ( $u->user_url !== $old->user_url ) {
			$ch[] = 'وب‌سایت';
		}
		if ( ! $ch ) {
			return;
		}
		$cur = DBS_Context::user();
		$sev = ( array_intersect( $ch, array( 'ایمیل', 'رمز عبور' ) ) && (int) $cur['user_id'] !== (int) $user_id ) ? 'warning' : 'notice';
		self::record(
			array(
				'category'     => 'user',
				'action'       => 'updated',
				'severity'     => $sev,
				'summary'      => 'ویرایش کاربر «' . $u->user_login . '»: ' . implode( '، ', $ch ),
				'object_type'  => 'user',
				'object_id'    => (string) $user_id,
				'object_label' => $u->user_login,
				'details'      => array( 'fields' => $ch ),
			)
		);
	}

	private static function role_event( $user_id, $text, $role, $undo = null ) {
		$u = get_userdata( $user_id );
		if ( self::$busy || ! $u ) {
			return;
		}
		self::record(
			array(
				'category'     => 'user',
				'action'       => 'role',
				'severity'     => ( 'administrator' === $role ) ? 'danger' : 'warning',
				'summary'      => sprintf( $text, $u->user_login ),
				'object_type'  => 'user',
				'object_id'    => (string) $user_id,
				'object_label' => $u->user_login,
				'undo'         => $undo,
			)
		);
	}

	public static function on_set_role( $user_id, $role, $old_roles ) {
		$old = $old_roles ? implode( '، ', array_map( array( __CLASS__, 'role_label' ), (array) $old_roles ) ) : 'بدون نقش';
		self::role_event( $user_id, 'نقش کاربر «%s» از ' . $old . ' به ' . self::role_label( $role ) . ' تغییر کرد', $role, array( 't' => 'roles', 'user_id' => (int) $user_id, 'roles' => array_values( (array) $old_roles ) ) );
	}

	public static function on_add_role( $user_id, $role ) {
		self::role_event( $user_id, 'نقش ' . self::role_label( $role ) . ' به کاربر «%s» اضافه شد', $role );
	}

	public static function on_remove_role( $user_id, $role ) {
		self::role_event( $user_id, 'نقش ' . self::role_label( $role ) . ' از کاربر «%s» حذف شد', '' );
	}

	public static function on_delete_user( $user_id ) {
		$u = get_userdata( $user_id );
		if ( self::$busy || ! $u ) {
			return;
		}
		self::record(
			array(
				'category'     => 'user',
				'action'       => 'deleted',
				'severity'     => 'warning',
				'summary'      => 'کاربر «' . $u->user_login . '» حذف شد',
				'object_type'  => 'user',
				'object_id'    => (string) $user_id,
				'object_label' => $u->user_login,
			)
		);
	}

	/* --------------------------------------------------------------------- *
	 * Semantic events: plugins, themes, updates, menus
	 * --------------------------------------------------------------------- */

	private static function plugin_name( $file ) {
		$slug = ( false !== strpos( $file, '/' ) ) ? strtok( $file, '/' ) : $file;
		$map  = DBS_Names::plugins();
		return isset( $map[ $slug ] ) ? $map[ $slug ] : $slug;
	}

	private static function plugins_diff( $old, $new ) {
		$old = is_array( $old ) ? $old : array();
		$new = is_array( $new ) ? $new : array();
		foreach ( array_diff( $new, $old ) as $p ) {
			self::record(
				array(
					'category'     => 'plugin',
					'action'       => 'activated',
					'severity'     => 'notice',
					'summary'      => 'افزونه «' . self::plugin_name( $p ) . '» فعال شد',
					'object_type'  => 'plugin',
					'object_id'    => $p,
					'object_label' => self::plugin_name( $p ),
					'undo'         => array( 't' => 'plugin', 'file' => $p, 'activate' => false ),
				)
			);
		}
		foreach ( array_diff( $old, $new ) as $p ) {
			self::record(
				array(
					'category'     => 'plugin',
					'action'       => 'deactivated',
					'severity'     => 'notice',
					'summary'      => 'افزونه «' . self::plugin_name( $p ) . '» غیرفعال شد',
					'object_type'  => 'plugin',
					'object_id'    => $p,
					'object_label' => self::plugin_name( $p ),
					'undo'         => array( 't' => 'plugin', 'file' => $p, 'activate' => true ),
				)
			);
		}
	}

	public static function on_deleted_plugin( $plugin, $deleted ) {
		if ( ! $deleted ) {
			return;
		}
		self::record(
			array(
				'category'     => 'plugin',
				'action'       => 'deleted',
				'severity'     => 'notice',
				'summary'      => 'افزونه «' . $plugin . '» حذف شد',
				'object_type'  => 'plugin',
				'object_id'    => $plugin,
				'object_label' => $plugin,
			)
		);
	}

	public static function on_switch_theme( $new_name, $new_theme, $old_theme ) {
		$old = ( $old_theme && is_object( $old_theme ) ) ? $old_theme->get( 'Name' ) : '';
		self::record(
			array(
				'category'     => 'theme',
				'action'       => 'switched',
				'severity'     => 'warning',
				'summary'      => 'پوسته از «' . $old . '» به «' . $new_name . '» تغییر کرد',
				'object_type'  => 'theme',
				'object_id'    => $new_name,
				'object_label' => $new_name,
			)
		);
	}

	public static function on_upgrader( $upgrader, $extra ) {
		if ( empty( $extra['type'] ) || empty( $extra['action'] ) || ! in_array( $extra['action'], array( 'install', 'update' ), true ) ) {
			return;
		}
		$verb = ( 'update' === $extra['action'] ) ? 'به‌روزرسانی شد' : 'نصب شد';
		$type = $extra['type'];

		if ( 'plugin' === $type ) {
			$list = array();
			if ( ! empty( $extra['plugins'] ) ) {
				$list = (array) $extra['plugins'];
			} elseif ( ! empty( $extra['plugin'] ) ) {
				$list = array( $extra['plugin'] );
			} elseif ( 'install' === $extra['action'] && is_object( $upgrader ) && method_exists( $upgrader, 'plugin_info' ) && $upgrader->plugin_info() ) {
				$list = array( $upgrader->plugin_info() );
			}
			foreach ( $list as $p ) {
				self::record(
					array(
						'category'     => 'plugin',
						'action'       => $extra['action'],
						'severity'     => 'notice',
						'summary'      => 'افزونه «' . self::plugin_name( $p ) . '» ' . $verb,
						'object_type'  => 'plugin',
						'object_id'    => $p,
						'object_label' => self::plugin_name( $p ),
					)
				);
			}
		} elseif ( 'theme' === $type ) {
			$list = ! empty( $extra['themes'] ) ? (array) $extra['themes'] : ( ! empty( $extra['theme'] ) ? array( $extra['theme'] ) : array() );
			foreach ( $list as $slug ) {
				self::record(
					array(
						'category'     => 'theme',
						'action'       => $extra['action'],
						'severity'     => 'notice',
						'summary'      => 'پوسته «' . DBS_Names::actor( 'theme', $slug ) . '» ' . $verb,
						'object_type'  => 'theme',
						'object_id'    => $slug,
						'object_label' => $slug,
					)
				);
			}
		} elseif ( 'core' === $type ) {
			self::record(
				array(
					'category'    => 'core',
					'action'      => 'update',
					'severity'    => 'notice',
					'summary'     => 'هسته وردپرس به‌روزرسانی شد',
					'object_type' => 'core',
				)
			);
		}
	}

	public static function on_nav_menu( $menu_id ) {
		$m = wp_get_nav_menu_object( $menu_id );
		self::record(
			array(
				'category'     => 'menu',
				'action'       => 'updated',
				'severity'     => 'info',
				'summary'      => 'منوی «' . ( $m ? $m->name : $menu_id ) . '» به‌روزرسانی شد',
				'object_type'  => 'menu',
				'object_id'    => (string) $menu_id,
				'object_label' => $m ? $m->name : '',
			)
		);
	}

	/* --------------------------------------------------------------------- *
	 * Maintenance
	 * --------------------------------------------------------------------- */

	public static function prune() {
		global $wpdb;
		$t   = self::table();
		$s   = DBS_Settings::all();
		$cut = gmdate( 'Y-m-d H:i:s', time() - (int) $s['log_retention_days'] * 86400 );
		$was = self::$busy;
		self::$busy = true;
		$wpdb->query( $wpdb->prepare( "DELETE FROM `{$t}` WHERE created_at < %s", $cut ) );
		$max = (int) $s['log_max_rows'];
		if ( $max > 0 ) {
			$id = $wpdb->get_var( "SELECT id FROM `{$t}` ORDER BY id DESC LIMIT 1 OFFSET {$max}" );
			if ( $id ) {
				$wpdb->query( 'DELETE FROM `' . $t . '` WHERE id <= ' . (int) $id );
			}
		}
		self::$busy = $was;
	}

	public static function clear() {
		global $wpdb;
		$was = self::$busy;
		self::$busy = true;
		$wpdb->query( 'TRUNCATE TABLE `' . self::table() . '`' );
		self::$busy = $was;
	}

	/* --------------------------------------------------------------------- *
	 * Read API (used by the admin UI)
	 * --------------------------------------------------------------------- */

	private static function where( $f, &$args ) {
		global $wpdb;
		$w = array( '1=1' );
		if ( ! empty( $f['id'] ) ) {
			$w[]    = 'id = %d';
			$args[] = (int) $f['id'];
		}
		if ( ! empty( $f['kind'] ) && in_array( $f['kind'], array( 'event', 'sql' ), true ) ) {
			$w[]    = 'kind = %s';
			$args[] = $f['kind'];
		}
		if ( ! empty( $f['category'] ) ) {
			$w[]    = 'category = %s';
			$args[] = (string) $f['category'];
		}
		if ( ! empty( $f['severity'] ) ) {
			if ( 'important' === $f['severity'] ) {
				$w[] = "severity IN ('warning','danger')";
			} else {
				$w[]    = 'severity = %s';
				$args[] = (string) $f['severity'];
			}
		}
		if ( ! empty( $f['user'] ) ) {
			$w[]    = ( '__none__' === $f['user'] ) ? "user_login = ''" : 'user_login = %s';
			if ( '__none__' !== $f['user'] ) {
				$args[] = (string) $f['user'];
			}
		}
		if ( ! empty( $f['actor'] ) && false !== strpos( (string) $f['actor'], ':' ) ) {
			list( $at, $as ) = explode( ':', (string) $f['actor'], 2 );
			$w[]    = '(actor_type = %s AND actor_slug = %s)';
			$args[] = $at;
			$args[] = $as;
		}
		if ( ! empty( $f['context'] ) ) {
			$w[]    = 'context = %s';
			$args[] = (string) $f['context'];
		}
		if ( ! empty( $f['since'] ) ) {
			$w[]    = 'created_at >= %s';
			$args[] = gmdate( 'Y-m-d H:i:s', (int) $f['since'] );
		}
		if ( ! empty( $f['until'] ) ) {
			$w[]    = 'created_at <= %s';
			$args[] = gmdate( 'Y-m-d H:i:s', (int) $f['until'] );
		}
		if ( isset( $f['q'] ) && '' !== trim( (string) $f['q'] ) ) {
			$like = '%' . $wpdb->esc_like( trim( (string) $f['q'] ) ) . '%';
			$w[]  = '(summary LIKE %s OR object_label LIKE %s OR user_login LIKE %s OR actor_slug LIKE %s OR request LIKE %s OR table_name LIKE %s)';
			array_push( $args, $like, $like, $like, $like, $like, $like );
		}
		return implode( ' AND ', $w );
	}

	private static function prep( $sql, $args ) {
		global $wpdb;
		return $args ? $wpdb->prepare( $sql, $args ) : $sql;
	}

	private static function fmt( $r ) {
		$d = ! empty( $r['details'] ) ? json_decode( $r['details'], true ) : null;
		return array(
			'id'           => (int) $r['id'],
			'ts'           => (int) strtotime( $r['created_at'] . ' UTC' ),
			'kind'         => $r['kind'],
			'category'     => $r['category'],
			'action'       => $r['action'],
			'severity'     => $r['severity'],
			'summary'      => $r['summary'],
			'object_type'  => $r['object_type'],
			'object_id'    => $r['object_id'],
			'object_label' => $r['object_label'],
			'details'      => is_array( $d ) ? $d : null,
			'user_id'      => (int) $r['user_id'],
			'user_login'   => $r['user_login'],
			'user_role'    => $r['user_role'],
			'actor_type'   => $r['actor_type'],
			'actor_slug'   => $r['actor_slug'],
			'actor_name'   => DBS_Names::actor( $r['actor_type'], $r['actor_slug'] ),
			'context'      => $r['context'],
			'request'      => $r['request'],
			'ip'           => $r['ip'],
			'table_name'   => $r['table_name'],
			'sql_op'       => $r['sql_op'],
			'row_count'    => (int) $r['row_count'],
			'undoable'     => ! empty( $r['has_undo'] ) && empty( $r['undone'] ),
			'undone'       => ! empty( $r['undone'] ),
		);
	}

	public static function query( $f, $offset = 0, $limit = 50 ) {
		global $wpdb;
		$t     = self::table();
		$args  = array();
		$where = self::where( $f, $args );
		$total = (int) $wpdb->get_var( self::prep( "SELECT COUNT(*) FROM `{$t}` WHERE {$where}", $args ) );
		$a2    = array_merge( $args, array( max( 1, min( 200, (int) $limit ) ), max( 0, (int) $offset ) ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, created_at, kind, category, action, severity, summary, object_type, object_id, object_label, details, user_id, user_login, user_role, actor_type, actor_slug, context, request, ip, table_name, sql_op, row_count, undone, (undo IS NOT NULL AND undo <> '') AS has_undo FROM `{$t}` WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d", $a2 ), ARRAY_A );
		$out   = array();
		foreach ( (array) $rows as $r ) {
			$out[] = self::fmt( $r );
		}
		return array(
			'rows'  => $out,
			'total' => $total,
		);
	}

	/** Raw rows for CSV export (no details decoding). */
	public static function export_rows( $f, $limit = 5000 ) {
		global $wpdb;
		$t     = self::table();
		$args  = array();
		$where = self::where( $f, $args );
		$a2    = array_merge( $args, array( (int) $limit ) );
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$t}` WHERE {$where} ORDER BY id DESC LIMIT %d", $a2 ), ARRAY_A );
	}

	public static function count_since( $ts ) {
		global $wpdb;
		$t   = self::table();
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT COUNT(*) AS total, SUM(severity IN ('warning','danger')) AS important FROM `{$t}` WHERE kind='event' AND category <> 'backup' AND created_at > %s", gmdate( 'Y-m-d H:i:s', (int) $ts ) ),
			ARRAY_A
		);
		return array(
			'total'     => $row ? (int) $row['total'] : 0,
			'important' => $row ? (int) $row['important'] : 0,
		);
	}

	public static function ticks( $since, $limit = 800 ) {
		global $wpdb;
		$t    = self::table();
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT created_at, severity FROM `{$t}` WHERE kind='event' AND category <> 'backup' AND created_at >= %s ORDER BY id DESC LIMIT %d", gmdate( 'Y-m-d H:i:s', (int) $since ), (int) $limit ),
			ARRAY_A
		);
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array( (int) strtotime( $r['created_at'] . ' UTC' ), $r['severity'] );
		}
		return $out;
	}

	public static function buckets( $since, $bucket = 'hour' ) {
		global $wpdb;
		$t    = self::table();
		$fmt  = ( 'day' === $bucket ) ? '%%Y-%%m-%%d 00:00:00' : '%%Y-%%m-%%d %%H:00:00';
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT DATE_FORMAT(created_at, '{$fmt}') AS b, COUNT(*) AS c, SUM(severity IN ('warning','danger')) AS w FROM `{$t}` WHERE kind='event' AND category <> 'backup' AND created_at >= %s GROUP BY b ORDER BY b ASC", gmdate( 'Y-m-d H:i:s', (int) $since ) ),
			ARRAY_A
		);
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				't' => (int) strtotime( $r['b'] . ' UTC' ),
				'c' => (int) $r['c'],
				'w' => (int) $r['w'],
			);
		}
		return $out;
	}

	public static function top_users( $since, $limit = 8 ) {
		global $wpdb;
		$t    = self::table();
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT user_login, COUNT(*) AS c FROM `{$t}` WHERE kind='event' AND category <> 'backup' AND created_at >= %s GROUP BY user_login ORDER BY c DESC LIMIT %d", gmdate( 'Y-m-d H:i:s', (int) $since ), (int) $limit ),
			ARRAY_A
		);
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'login' => $r['user_login'],
				'c'     => (int) $r['c'],
			);
		}
		return $out;
	}

	public static function top_actors( $since, $limit = 8 ) {
		global $wpdb;
		$t    = self::table();
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT actor_type, actor_slug, SUM(CASE WHEN kind='sql' THEN row_count ELSE 1 END) AS c FROM `{$t}` WHERE category <> 'backup' AND created_at >= %s GROUP BY actor_type, actor_slug ORDER BY c DESC LIMIT %d", gmdate( 'Y-m-d H:i:s', (int) $since ), (int) $limit ),
			ARRAY_A
		);
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'type' => $r['actor_type'],
				'slug' => $r['actor_slug'],
				'name' => DBS_Names::actor( $r['actor_type'], $r['actor_slug'] ),
				'c'    => (int) $r['c'],
			);
		}
		return $out;
	}

	public static function top_tables( $since, $limit = 8 ) {
		global $wpdb;
		$t    = self::table();
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT table_name, SUM(row_count) AS c FROM `{$t}` WHERE kind='sql' AND created_at >= %s GROUP BY table_name ORDER BY c DESC LIMIT %d", gmdate( 'Y-m-d H:i:s', (int) $since ), (int) $limit ),
			ARRAY_A
		);
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'name' => $r['table_name'],
				'c'    => (int) $r['c'],
			);
		}
		return $out;
	}

	public static function by_category( $since ) {
		global $wpdb;
		$t    = self::table();
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT category, COUNT(*) AS c FROM `{$t}` WHERE kind='event' AND category <> 'backup' AND created_at >= %s GROUP BY category ORDER BY c DESC", gmdate( 'Y-m-d H:i:s', (int) $since ) ),
			ARRAY_A
		);
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'name' => $r['category'],
				'c'    => (int) $r['c'],
			);
		}
		return $out;
	}

	public static function by_severity( $since ) {
		global $wpdb;
		$t    = self::table();
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT severity, COUNT(*) AS c FROM `{$t}` WHERE kind='event' AND category <> 'backup' AND created_at >= %s GROUP BY severity", gmdate( 'Y-m-d H:i:s', (int) $since ) ),
			ARRAY_A
		);
		$out  = array( 'info' => 0, 'notice' => 0, 'warning' => 0, 'danger' => 0 );
		foreach ( (array) $rows as $r ) {
			$out[ $r['severity'] ] = (int) $r['c'];
		}
		return $out;
	}

	public static function filter_options() {
		global $wpdb;
		$t      = self::table();
		$users  = $wpdb->get_col( "SELECT DISTINCT user_login FROM `{$t}` WHERE user_login <> '' ORDER BY user_login ASC LIMIT 200" );
		$actors = $wpdb->get_results( "SELECT DISTINCT actor_type, actor_slug FROM `{$t}` WHERE actor_slug <> '' ORDER BY actor_type, actor_slug LIMIT 300", ARRAY_A );
		$cats   = $wpdb->get_col( "SELECT DISTINCT category FROM `{$t}` WHERE category <> '' ORDER BY category ASC" );
		$out    = array();
		foreach ( (array) $actors as $a ) {
			$out[] = array(
				'key'  => $a['actor_type'] . ':' . $a['actor_slug'],
				'name' => DBS_Names::actor( $a['actor_type'], $a['actor_slug'] ),
				'type' => $a['actor_type'],
			);
		}
		return array(
			'users'      => (array) $users,
			'actors'     => $out,
			'categories' => (array) $cats,
		);
	}

	public static function total_rows() {
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . self::table() . '`' );
	}
}
