<?php
/**
 * DB Sentinel restore engine.
 *
 * Executes a prepared job (restore-<job>.sql + restore-<job>.json) in time-boxed chunks.
 * It depends only on the global $wpdb, so it keeps working while the database is being
 * replaced underneath WordPress.
 */

if ( ! function_exists( 'dbs_exec' ) ) {

	function dbs_exec( $sql ) {
		global $wpdb;
		$dbh = $wpdb->dbh;
		try {
			if ( is_object( $dbh ) && $dbh instanceof mysqli ) {
				$r = mysqli_query( $dbh, $sql );
				if ( false === $r ) {
					return mysqli_error( $dbh ) . ' (#' . mysqli_errno( $dbh ) . ')';
				}
				return true;
			}
			$wpdb->suppress_errors( true );
			$r = $wpdb->query( $sql );
			return ( false === $r ) ? (string) $wpdb->last_error : true;
		} catch ( Throwable $e ) {
			return $e->getMessage();
		}
	}

	function dbs_save_state( $fp, $st ) {
		$st['updated'] = time();
		ftruncate( $fp, 0 );
		rewind( $fp );
		fwrite( $fp, json_encode( $st ) );
		fflush( $fp );
	}

	function dbs_log_event( $st, $action, $summary, $severity = 'danger' ) {
		global $wpdb;
		$wpdb->suppress_errors( true );
		$wpdb->insert(
			$wpdb->base_prefix . 'dbs_activity',
			array(
				'created_at'  => gmdate( 'Y-m-d H:i:s' ),
				'kind'        => 'event',
				'category'    => 'backup',
				'action'      => $action,
				'severity'    => $severity,
				'summary'     => $summary,
				'object_type' => 'backup',
				'object_id'   => isset( $st['backup_id'] ) ? $st['backup_id'] : '',
				'user_id'     => isset( $st['user']['id'] ) ? (int) $st['user']['id'] : 0,
				'user_login'  => isset( $st['user']['login'] ) ? (string) $st['user']['login'] : '',
				'actor_type'  => 'plugin',
				'actor_slug'  => 'db-sentinel',
				'context'     => 'ajax',
				'ip'          => isset( $st['ip'] ) ? (string) $st['ip'] : '',
			)
		);
	}

	function dbs_patch_meta( $dir, $id, $patch ) {
		if ( ! preg_match( '/^\d{8}-\d{6}-[a-f0-9]{8}$/', (string) $id ) ) {
			return;
		}
		$p = $dir . '/dbs-' . $id . '.json';
		$m = json_decode( (string) @file_get_contents( $p ), true );
		if ( is_array( $m ) ) {
			file_put_contents( $p, json_encode( array_merge( $m, $patch ) ), LOCK_EX );
		}
	}

	/** Count rows of the temporary tables, compare with the backup, then drop them. */
	function dbs_engine_verify( &$st, $dir ) {
		global $wpdb;
		$res = array( 'ok' => true, 'checked' => 0, 'mismatch' => array() );
		$wpdb->suppress_errors( true );
		foreach ( (array) $st['verify']['tables'] as $t => $rows ) {
			$q = str_replace( '`', '``', $t );
			$c = $wpdb->get_var( "SELECT COUNT(*) FROM `{$q}`" );
			if ( null === $c ) {
				$res['ok']         = false;
				$res['mismatch'][] = $t . ': جدول ساخته نشد';
				continue;
			}
			$res['checked']++;
			if ( ! empty( $st['verify']['exact'] ) && (int) $c !== (int) $rows ) {
				$res['ok']         = false;
				$res['mismatch'][] = $t . ': ' . (int) $c . ' ردیف به‌جای ' . (int) $rows;
			}
		}
		foreach ( array_keys( (array) $st['verify']['tables'] ) as $t ) {
			$wpdb->query( 'DROP TABLE IF EXISTS `' . str_replace( '`', '``', $t ) . '`' );
		}
		$res['mismatch'] = array_slice( $res['mismatch'], 0, 10 );
		dbs_patch_meta( $dir, $st['backup_id'], array( 'verified' => array_merge( $res, array( 'ts' => time() ) ) ) );
		return $res;
	}
}

/**
 * Run one time-boxed step of a job.
 *
 * @param string      $dir    Backup directory.
 * @param string      $job    Job id.
 * @param string|null $token  Job token (null = trusted caller such as WP-CLI / cron).
 * @param float       $budget Seconds to spend in this step.
 * @return array
 */
function dbs_engine_step( $dir, $job, $token = null, $budget = 8.0 ) {
	global $wpdb;

	$job = preg_replace( '/[^a-z0-9]/i', '', (string) $job );
	$sf  = $dir . '/restore-' . $job . '.json';
	if ( '' === $job || ! is_file( $sf ) ) {
		return array( 'ok' => false, 'error' => 'عملیات پیدا نشد.', 'code' => 404 );
	}
	$fp = fopen( $sf, 'c+' );
	if ( ! $fp ) {
		return array( 'ok' => false, 'error' => 'دسترسی به فایل وضعیت ممکن نیست.', 'code' => 500 );
	}
	if ( ! flock( $fp, LOCK_EX | LOCK_NB ) ) {
		return array( 'ok' => true, 'busy' => true );
	}
	$st = json_decode( (string) stream_get_contents( $fp ), true );
	if ( ! is_array( $st ) || empty( $st['token'] ) ) {
		return array( 'ok' => false, 'error' => 'فایل وضعیت خراب است.', 'code' => 500 );
	}
	if ( null !== $token && ! hash_equals( (string) $st['token'], (string) $token ) ) {
		return array( 'ok' => false, 'error' => 'دسترسی نامعتبر.', 'code' => 403 );
	}

	$sqlfile = $dir . '/' . basename( $st['sql'] );
	$total   = max( 1, (int) $st['total'] );
	$mode    = isset( $st['mode'] ) ? $st['mode'] : 'restore';

	if ( 'done' === $st['status'] ) {
		return array( 'ok' => true, 'status' => 'done', 'percent' => 100, 'stmts' => (int) $st['stmts'], 'verify' => isset( $st['result'] ) ? $st['result'] : null );
	}
	if ( 'failed' === $st['status'] || 'aborted' === $st['status'] ) {
		return array( 'ok' => false, 'status' => $st['status'], 'error' => $st['error'], 'percent' => round( $st['offset'] / $total * 100, 1 ) );
	}
	if ( time() - (int) $st['created'] > 6 * 3600 ) {
		return array( 'ok' => false, 'status' => 'failed', 'error' => 'مهلت این عملیات تمام شده است.', 'code' => 410 );
	}

	$fh = @fopen( $sqlfile, 'rb' );
	if ( ! $fh || 0 !== fseek( $fh, (int) $st['offset'] ) ) {
		$st['status'] = 'failed';
		$st['error']  = 'فایل موقت در دسترس نیست.';
		dbs_save_state( $fp, $st );
		return array( 'ok' => false, 'status' => 'failed', 'error' => $st['error'] );
	}

	@ignore_user_abort( true );
	@set_time_limit( 120 );

	dbs_exec( 'SET SESSION FOREIGN_KEY_CHECKS=0' );
	dbs_exec( 'SET SESSION UNIQUE_CHECKS=0' );
	dbs_exec( "SET SESSION SQL_MODE='NO_AUTO_VALUE_ON_ZERO'" );
	if ( ! empty( $st['charset'] ) && preg_match( '/^[a-z0-9_]+$/i', $st['charset'] ) && is_object( $wpdb->dbh ) && $wpdb->dbh instanceof mysqli ) {
		@mysqli_set_charset( $wpdb->dbh, $st['charset'] );
	}

	$t0   = microtime( true );
	$err  = '';
	$done = false;

	while ( true ) {
		$line = fgets( $fh );
		if ( false === $line ) {
			$done = true;
			break;
		}
		$pos  = ftell( $fh );
		$stmt = trim( $line );
		if ( '' === $stmt || 0 === strncmp( $stmt, '--', 2 ) ) {
			$st['offset'] = $pos;
			continue;
		}
		$r = dbs_exec( $stmt );
		if ( true !== $r ) {
			$err = $r . ' | ' . substr( $stmt, 0, 140 );
			break;
		}
		$st['offset'] = $pos;
		$st['stmts']  = (int) $st['stmts'] + 1;
		if ( microtime( true ) - $t0 > $budget ) {
			break;
		}
	}
	fclose( $fh );

	$extra = array();
	if ( '' !== $err ) {
		$st['status'] = 'failed';
		$st['error']  = $err;
		if ( 'verify' === $mode ) {
			$res = array( 'ok' => false, 'checked' => 0, 'mismatch' => array( 'اجرای بکاپ در جدول‌های موقت ناموفق بود: ' . substr( $err, 0, 160 ) ) );
			foreach ( array_keys( (array) $st['verify']['tables'] ) as $t ) {
				$wpdb->query( 'DROP TABLE IF EXISTS `' . str_replace( '`', '``', $t ) . '`' );
			}
			dbs_patch_meta( $dir, $st['backup_id'], array( 'verified' => array_merge( $res, array( 'ts' => time() ) ) ) );
			@unlink( $sqlfile );
			$extra['verify'] = $res;
		} else {
			if ( function_exists( 'wp_cache_flush' ) ) {
				wp_cache_flush();
			}
			dbs_log_event( $st, 'restore_failed', 'بازگردانی دیتابیس با خطا متوقف شد' );
		}
	} elseif ( $done ) {
		@unlink( $sqlfile );
		$st['status'] = 'done';
		$st['offset'] = $total;
		if ( 'verify' === $mode ) {
			$res = dbs_engine_verify( $st, $dir );
			$st['result']    = $res;
			$extra['verify'] = $res;
			dbs_log_event( $st, 'verified', $res['ok'] ? 'تست بازگردانی بکاپ با موفقیت انجام شد' : 'تست بازگردانی بکاپ مشکل پیدا کرد', $res['ok'] ? 'info' : 'warning' );
		} else {
			if ( function_exists( 'wp_cache_flush' ) ) {
				wp_cache_flush();
			}
			dbs_log_event( $st, 'restore_done', ( ! empty( $st['partial'] ) ? 'بازگردانی ' . (int) $st['partial'] . ' جدول' : 'بازگردانی کامل دیتابیس' ) . ' با موفقیت انجام شد (' . (int) $st['stmts'] . ' دستور)' );
		}
	} else {
		$st['status'] = 'running';
	}

	dbs_save_state( $fp, $st );

	return array_merge(
		array(
			'ok'      => ( 'failed' !== $st['status'] ),
			'status'  => $st['status'],
			'percent' => ( 'done' === $st['status'] ) ? 100 : round( min( 100, $st['offset'] / $total * 100 ), 1 ),
			'stmts'   => (int) $st['stmts'],
			'error'   => $st['error'],
		),
		$extra
	);
}
