<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Small wrapper that writes plain or gzip files with error checking.
 */
class DBS_Writer {

	private $h;
	private $gz;

	public function __construct( $path, $compress ) {
		$this->gz = (bool) $compress;
		$this->h  = $this->gz ? @gzopen( $path, 'wb6' ) : @fopen( $path, 'wb' );
		if ( ! $this->h ) {
			throw new Exception( 'امکان ساخت فایل بکاپ وجود ندارد (دسترسی نوشتن را بررسی کنید).' );
		}
	}

	public function write( $s ) {
		if ( '' === $s ) {
			return;
		}
		$n = $this->gz ? @gzwrite( $this->h, $s ) : @fwrite( $this->h, $s );
		if ( false === $n || 0 === $n ) {
			throw new Exception( 'نوشتن روی دیسک ناموفق بود (فضای دیسک کافی نیست؟).' );
		}
	}

	public function close() {
		if ( $this->h ) {
			$this->gz ? @gzclose( $this->h ) : @fclose( $this->h );
			$this->h = null;
		}
	}
}

/**
 * Database-only backup. Every statement is on exactly one line, which lets the restore
 * runner stream it safely in small chunks.
 */
class DBS_Backup {

	public static $types = array( 'auto', 'manual', 'pre_restore', 'pre_update', 'pre_tool' );

	public static function run( $type = 'manual', $extra = array() ) {
		global $wpdb;

		$dir = DBS_Storage::dir( true );
		if ( ! $dir || ! wp_is_writable( $dir ) ) {
			return new WP_Error( 'dbs_dir', 'پوشه بکاپ ساخته نشد یا قابل نوشتن نیست. مجوز پوشه wp-content را بررسی کنید.' );
		}

		$lock = @fopen( $dir . '/.lock', 'c' );
		if ( ! $lock || ! flock( $lock, LOCK_EX | LOCK_NB ) ) {
			return new WP_Error( 'dbs_locked', 'یک بکاپ دیگر همین الان در حال ساخت است. کمی بعد دوباره تلاش کنید.' );
		}

		@ignore_user_abort( true );
		@set_time_limit( 0 );
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}

		$settings = DBS_Settings::all();

		// Disk guard: never fill the disk (which could take the whole site down).
		if ( ! empty( $settings['disk_guard'] ) && function_exists( 'disk_free_space' ) ) {
			$free = @disk_free_space( $dir );
			if ( false !== $free ) {
				$prev = DBS_Storage::all();
				$need = $prev ? max( 5 * 1048576, (int) $prev[0]['size'] * 2 ) : 20 * 1048576;
				if ( $free < $need ) {
					flock( $lock, LOCK_UN );
					fclose( $lock );
					$err = new WP_Error( 'dbs_disk', 'فضای آزاد دیسک کم است؛ بکاپ برای جلوگیری از پر شدن سرور انجام نشد.' );
					DBS_Notify::send( 'fail', 'بکاپ انجام نشد: کمبود فضای دیسک', array( 'فضای آزاد: ' . size_format( $free ) ) );
					return $err;
				}
			}
		}

		$started  = microtime( true );
		$id       = DBS_Storage::new_id();
		$compress = ! empty( $settings['compress'] ) && function_exists( 'gzopen' );
		$file     = 'dbs-' . $id . ( $compress ? '.sql.gz' : '.sql' );
		$tmp      = $dir . '/' . $file . '.tmp';
		$writer   = null;
		$tx       = false;

		try {
			$writer  = new DBS_Writer( $tmp, $compress );
			$charset = $wpdb->charset ? $wpdb->charset : 'utf8mb4';
			if ( ! preg_match( '/^[a-z0-9_]+$/i', $charset ) ) {
				$charset = 'utf8mb4';
			}

			$packet = (int) $wpdb->get_var( 'SELECT @@max_allowed_packet' );
			$cap    = max( 65536, min( 1048576, (int) ( $packet / 2 ) ) );

			$wpdb->query( 'SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ' );
			$tx = ( false !== $wpdb->query( 'START TRANSACTION WITH CONSISTENT SNAPSHOT' ) );

			$tables = self::tables();

			$writer->write( "-- DB Sentinel dump\n" );
			$writer->write( '-- Generated: ' . gmdate( 'Y-m-d H:i:s' ) . " UTC\n" );
			$writer->write( '-- Site: ' . preg_replace( '/[\r\n]+/', ' ', home_url() ) . "\n" );
			$writer->write( '-- Prefix: ' . $wpdb->base_prefix . "\n" );
			$writer->write( '-- Database server: ' . preg_replace( '/[\r\n]+/', ' ', (string) $wpdb->db_version() ) . "\n" );
			$writer->write( "SET NAMES {$charset};\nSET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n" );

			$rows_total = 0;
			$info       = array();
			foreach ( $tables as $table ) {
				$r              = self::dump_table( $writer, $table, $cap );
				$rows_total    += $r['rows'];
				$info[ $table ] = $r;
			}

			$writer->write( "SET FOREIGN_KEY_CHECKS=1;\n-- DBS-COMPLETE\n" );
			$writer->close();

			if ( $tx ) {
				$wpdb->query( 'COMMIT' );
				$tx = false;
			}

			$final = $dir . '/' . $file;
			if ( ! @rename( $tmp, $final ) ) {
				throw new Exception( 'تغییر نام فایل بکاپ ناموفق بود.' );
			}

			$user = function_exists( 'wp_get_current_user' ) ? wp_get_current_user() : null;
			$meta = array(
				'id'          => $id,
				'created'     => time(),
				'type'        => in_array( $type, self::$types, true ) ? $type : 'manual',
				'file'        => $file,
				'size'        => (int) filesize( $final ),
				'sha1'        => sha1_file( $final ),
				'compressed'  => $compress ? 1 : 0,
				'tables'      => count( $tables ),
				'rows'        => (int) $rows_total,
				'tables_info' => $info,
				'rows_exact'  => true,
				'duration'    => round( microtime( true ) - $started, 2 ),
				'for'         => ( ! empty( $extra['for'] ) && DBS_Storage::valid_id( $extra['for'] ) ) ? $extra['for'] : '',
				'by'          => ( $user && $user->ID ) ? $user->user_login : '',
				'wp'          => get_bloginfo( 'version' ),
				'prefix'      => $wpdb->base_prefix,
				'charset'     => $charset,
			);
			file_put_contents( $dir . '/dbs-' . $id . '.json', wp_json_encode( $meta ), LOCK_EX );

			$labels = array(
				'auto'        => 'بکاپ خودکار دیتابیس گرفته شد',
				'manual'      => 'بکاپ دستی دیتابیس گرفته شد',
				'pre_restore' => 'بکاپ ایمنی قبل از بازگردانی گرفته شد',
				'pre_update'  => 'بکاپ ایمنی قبل از به‌روزرسانی گرفته شد',
				'pre_tool'    => 'بکاپ ایمنی قبل از اجرای ابزار گرفته شد',
			);
			DBS_Activity::record(
				array(
					'category'    => 'backup',
					'action'      => 'created',
					'severity'    => 'info',
					'summary'     => $labels[ $meta['type'] ] . ' (' . size_format( $meta['size'] ) . ')',
					'object_type' => 'backup',
					'object_id'   => $id,
					'actor_type'  => 'plugin',
					'actor_slug'  => 'db-sentinel',
				)
			);

			flock( $lock, LOCK_UN );
			fclose( $lock );

			// Off-site copy (failures are reported but never fail the local backup).
			if ( DBS_Remote::auto_ready() ) {
				DBS_Remote::upload( $meta );
				$fresh = DBS_Storage::get( $id );
				if ( $fresh ) {
					$meta = $fresh;
				}
			}

			DBS_Storage::prune();
			DBS_Activity::prune();
			return $meta;

		} catch ( Exception $e ) {
			if ( $writer ) {
				$writer->close();
			}
			@unlink( $tmp );
			if ( $tx ) {
				$wpdb->query( 'ROLLBACK' );
			}
			flock( $lock, LOCK_UN );
			fclose( $lock );
			DBS_Notify::send( 'fail', 'ساخت بکاپ ناموفق بود', array( $e->getMessage() ) );
			return new WP_Error( 'dbs_failed', 'ساخت بکاپ ناموفق بود: ' . $e->getMessage() );
		}
	}

	private static function excluded( $name ) {
		global $wpdb;
		static $pats = null;
		if ( null === $pats ) {
			$pats = array();
			foreach ( (array) preg_split( '/\R/', (string) DBS_Settings::get( 'exclude_tables' ) ) as $l ) {
				$l = trim( $l );
				if ( '' !== $l ) {
					$pats[] = $l;
				}
			}
		}
		foreach ( $pats as $p ) {
			if ( fnmatch( $p, $name ) || fnmatch( $wpdb->base_prefix . $p, $name ) ) {
				return true;
			}
		}
		return false;
	}

	/** Tables of this WordPress install. The plugin's own log table is never included. */
	public static function tables() {
		global $wpdb;
		$rows   = $wpdb->get_results( 'SHOW FULL TABLES', ARRAY_N );
		$prefix = $wpdb->base_prefix;
		$skip   = DBS_Activity::table();
		$out    = array();
		foreach ( (array) $rows as $r ) {
			if ( isset( $r[1] ) && 'BASE TABLE' !== strtoupper( $r[1] ) ) {
				continue;
			}
			$name = $r[0];
			if ( 0 !== strpos( $name, $prefix ) || $name === $skip || 0 === strpos( $name, 'dbsvt_' ) || self::excluded( $name ) ) {
				continue;
			}
			$out[] = $name;
		}
		return $out;
	}

	private static function q( $id ) {
		return str_replace( '`', '``', $id );
	}

	private static function esc( $v ) {
		global $wpdb;
		if ( is_object( $wpdb->dbh ) && $wpdb->dbh instanceof mysqli ) {
			return mysqli_real_escape_string( $wpdb->dbh, $v );
		}
		return strtr(
			$v,
			array(
				'\\'   => '\\\\',
				"'"    => "\\'",
				"\0"   => '\\0',
				"\n"   => '\\n',
				"\r"   => '\\r',
				"\x1a" => '\\Z',
			)
		);
	}

	/** Checksum of a live table computed exactly like the one stored in backups. */
	public static function digest_table( $table ) {
		$r = self::dump_table( null, $table, 1048576 );
		return $r;
	}

	/**
	 * Dump (or only digest, when $w is null) one table.
	 *
	 * @return array rows + crc (crc is empty for tables without a primary key).
	 */
	private static function dump_table( $w, $table, $cap ) {
		global $wpdb;

		$q      = self::q( $table );
		$create = $wpdb->get_row( "SHOW CREATE TABLE `{$q}`", ARRAY_N );
		if ( ! $create || empty( $create[1] ) ) {
			throw new Exception( 'خواندن ساختار جدول ' . $table . ' ممکن نشد.' );
		}
		if ( $w ) {
			$ddl = preg_replace( '/\s*[\r\n]+\s*/', ' ', $create[1] );
			$w->write( "DROP TABLE IF EXISTS `{$q}`;\n{$ddl};\n" );
		}

		$info  = $wpdb->get_results( "SHOW COLUMNS FROM `{$q}`", ARRAY_A );
		$cols  = array();
		$types = array();
		$bin   = array();
		$wide  = false;
		foreach ( (array) $info as $c ) {
			if ( false !== stripos( (string) $c['Extra'], 'GENERATED' ) ) {
				continue;
			}
			$cols[]               = $c['Field'];
			$types[ $c['Field'] ] = strtolower( (string) $c['Type'] );
			if ( preg_match( '/blob|binary|^bit/i', $c['Type'] ) ) {
				$bin[ $c['Field'] ] = true;
			}
			if ( preg_match( '/text|blob|json/i', $c['Type'] ) ) {
				$wide = true;
			}
		}
		if ( empty( $cols ) ) {
			return array( 'rows' => 0, 'crc' => '' );
		}

		$collist = '`' . implode( '`,`', array_map( array( __CLASS__, 'q' ), $cols ) ) . '`';

		$keys = $wpdb->get_results( "SHOW KEYS FROM `{$q}` WHERE Key_name = 'PRIMARY'", ARRAY_A );
		$pk   = array();
		foreach ( (array) $keys as $k ) {
			$pk[ (int) $k['Seq_in_index'] ] = $k['Column_name'];
		}
		ksort( $pk );
		$pk = array_values( $pk );

		$keyset = ( 1 === count( $pk ) && isset( $types[ $pk[0] ] ) && preg_match( '/^(tiny|small|medium|big)?int/', $types[ $pk[0] ] ) );
		$order  = $pk ? ' ORDER BY `' . implode( '`,`', array_map( array( __CLASS__, 'q' ), $pk ) ) . '`' : '';
		$limit  = $wide ? 200 : 500;
		$head   = "INSERT INTO `{$q}` ({$collist}) VALUES ";
		$hash   = $pk ? hash_init( 'crc32b' ) : null;

		$total  = 0;
		$last   = null;
		$offset = 0;

		while ( true ) {
			if ( $keyset ) {
				$pkq   = self::q( $pk[0] );
				$where = ( null === $last ) ? '' : " WHERE `{$pkq}` > {$last}";
				$sql   = "SELECT {$collist} FROM `{$q}`{$where} ORDER BY `{$pkq}` ASC LIMIT {$limit}";
			} else {
				$sql = "SELECT {$collist} FROM `{$q}`{$order} LIMIT {$limit} OFFSET {$offset}";
			}

			$rows = $wpdb->get_results( $sql, ARRAY_A );
			if ( $wpdb->last_error ) {
				throw new Exception( $wpdb->last_error );
			}
			if ( empty( $rows ) ) {
				break;
			}

			$buf = '';
			$n   = 0;
			foreach ( $rows as $row ) {
				$vals = array();
				foreach ( $cols as $c ) {
					$v = $row[ $c ];
					if ( null === $v ) {
						$vals[] = 'NULL';
					} elseif ( isset( $bin[ $c ] ) && '' !== $v ) {
						$vals[] = '0x' . bin2hex( $v );
					} else {
						$vals[] = "'" . self::esc( $v ) . "'";
					}
				}
				$tuple = '(' . implode( ',', $vals ) . ')';
				if ( $hash ) {
					hash_update( $hash, $tuple );
				}
				if ( $w ) {
					if ( $n > 0 && strlen( $buf ) + strlen( $tuple ) > $cap ) {
						$w->write( $head . $buf . ";\n" );
						$buf = '';
						$n   = 0;
					}
					$buf .= ( $n ? ',' : '' ) . $tuple;
					$n++;
				}
			}
			if ( $w && $n > 0 ) {
				$w->write( $head . $buf . ";\n" );
			}

			$count = count( $rows );
			if ( $keyset ) {
				$lastrow = end( $rows );
				$last    = (string) $lastrow[ $pk[0] ];
				if ( ! preg_match( '/^-?\d+$/', $last ) ) {
					throw new Exception( 'مقدار کلید اصلی در جدول ' . $table . ' نامعتبر است.' );
				}
			} else {
				$offset += $count;
			}
			$total += $count;

			unset( $rows, $buf );
			$wpdb->flush();
			if ( defined( 'SAVEQUERIES' ) && SAVEQUERIES ) {
				$wpdb->queries = array();
			}
			if ( $count < $limit ) {
				break;
			}
		}
		return array(
			'rows' => $total,
			'crc'  => $hash ? hash_final( $hash ) : '',
		);
	}
}

/**
 * Prepares restore / verify jobs. The heavy lifting is done by restore-engine.php, called
 * either from the standalone runner endpoint (browser) or in a loop (CLI / cron).
 */
class DBS_Restore {

	public static function runner_url() {
		return DBS_URL . 'includes/restore-runner.php';
	}

	/**
	 * @param string $id   Backup id.
	 * @param array  $opts mode (restore|verify), tables (array of table names for a partial restore).
	 */
	public static function init_job( $id, $opts = array() ) {
		global $wpdb;

		$mode   = ( isset( $opts['mode'] ) && 'verify' === $opts['mode'] ) ? 'verify' : 'restore';
		$tables = ( ! empty( $opts['tables'] ) && is_array( $opts['tables'] ) ) ? array_values( array_filter( $opts['tables'], 'is_string' ) ) : array();

		$meta = DBS_Storage::get( $id );
		if ( ! $meta ) {
			return new WP_Error( 'dbs_nf', 'این بکاپ پیدا نشد.' );
		}
		$dir = DBS_Storage::dir( false );
		if ( ! $dir ) {
			return new WP_Error( 'dbs_dir', 'پوشه بکاپ پیدا نشد.' );
		}
		if ( 'restore' === $mode && ! empty( $meta['prefix'] ) && $meta['prefix'] !== $wpdb->base_prefix ) {
			return new WP_Error( 'dbs_prefix', 'پیشوند جدول‌های این بکاپ (' . $meta['prefix'] . ') با پیشوند این سایت (' . $wpdb->base_prefix . ') فرق دارد.' );
		}

		foreach ( (array) @scandir( $dir ) as $n ) {
			if ( ! preg_match( '/^restore-([a-z0-9]+)\.json$/i', $n, $m ) ) {
				continue;
			}
			$st = json_decode( (string) @file_get_contents( $dir . '/' . $n ), true );
			if ( is_array( $st ) && in_array( $st['status'], array( 'ready', 'running' ), true ) && time() - (int) $st['updated'] < 900 ) {
				return new WP_Error( 'dbs_busy', 'یک بازگردانی یا تست دیگر در حال انجام است.' );
			}
			@unlink( $dir . '/' . $n );
			@unlink( $dir . '/restore-' . $m[1] . '.sql' );
		}

		$path = DBS_Storage::path( $meta );
		if ( ! is_file( $path ) || (int) filesize( $path ) !== (int) $meta['size'] ) {
			return new WP_Error( 'dbs_corrupt', 'فایل بکاپ ناقص است (اندازه فایل با اطلاعات ثبت‌شده نمی‌خواند).' );
		}
		if ( ! empty( $meta['sha1'] ) && sha1_file( $path ) !== $meta['sha1'] ) {
			return new WP_Error( 'dbs_corrupt', 'فایل بکاپ خراب شده است (چک‌سام نمی‌خواند).' );
		}

		@ignore_user_abort( true );
		@set_time_limit( 0 );

		$job   = strtolower( wp_generate_password( 16, false, false ) );
		$token = bin2hex( random_bytes( 20 ) );
		$sql   = $dir . '/restore-' . $job . '.sql';
		$out   = @fopen( $sql, 'wb' );
		if ( ! $out ) {
			return new WP_Error( 'dbs_write', 'امکان ساخت فایل موقت وجود ندارد.' );
		}
		$gz = ! empty( $meta['compressed'] );
		$in = $gz ? @gzopen( $path, 'rb' ) : @fopen( $path, 'rb' );
		if ( ! $in ) {
			fclose( $out );
			@unlink( $sql );
			return new WP_Error( 'dbs_write', 'باز کردن فایل بکاپ ممکن نیست.' );
		}

		$sel         = $tables ? array_flip( $tables ) : null;
		$verify_from = $wpdb->base_prefix;
		$verify_to   = 'dbsvt_';
		$vt          = array();
		$info        = ! empty( $meta['tables_info'] ) ? $meta['tables_info'] : array();
		$cur         = null;
		$bad         = false;
		$found       = 0;

		while ( false !== ( $line = DBS_Sql::read_line( $in, $gz ) ) ) {
			$c     = $line[0];
			$owner = $cur;
			if ( 'D' === $c && 0 === strncmp( $line, 'DROP TABLE IF EXISTS `', 22 ) ) {
				if ( preg_match( '/^DROP TABLE IF EXISTS `((?:[^`]|``)+)`;/', $line, $m ) ) {
					$cur   = str_replace( '``', '`', $m[1] );
					$owner = $cur;
				}
			} elseif ( 'U' === $c && preg_match( '/^UPDATE `((?:[^`]|``)+)`/', substr( $line, 0, 300 ), $m ) ) {
				$owner = str_replace( '``', '`', $m[1] );
			}
			if ( null !== $sel && null !== $owner && 'S' !== $c && '-' !== $c && ! isset( $sel[ $owner ] ) ) {
				continue;
			}
			if ( 'verify' === $mode ) {
				if ( 'D' === $c && null !== $cur && 0 === strncmp( $line, 'DROP TABLE IF EXISTS `', 22 ) ) {
					$new        = ( 0 === strpos( $cur, $verify_from ) ) ? $verify_to . substr( $cur, strlen( $verify_from ) ) : $verify_to . $cur;
					$vt[ $new ] = isset( $info[ $cur ]['rows'] ) ? (int) $info[ $cur ]['rows'] : 0;
					$found++;
				}
				$line = DBS_Sql::rewrite_line( $line, $verify_from, $verify_to );
			} elseif ( 'D' === $c && null !== $cur && 0 === strncmp( $line, 'DROP TABLE IF EXISTS `', 22 ) ) {
				$found++;
			}
			if ( strlen( $line ) !== fwrite( $out, $line ) ) {
				$bad = true;
				break;
			}
		}
		$gz ? gzclose( $in ) : fclose( $in );
		fclose( $out );

		if ( $bad ) {
			@unlink( $sql );
			return new WP_Error( 'dbs_write', 'فضای دیسک برای آماده‌سازی کافی نیست.' );
		}
		if ( ! $found ) {
			@unlink( $sql );
			return new WP_Error( 'dbs_empty', 'هیچ جدولی برای بازگردانی انتخاب نشده یا در بکاپ پیدا نشد.' );
		}

		$size = (int) filesize( $sql );
		$fh   = fopen( $sql, 'rb' );
		fseek( $fh, max( 0, $size - 128 ), SEEK_SET );
		$tail = (string) fread( $fh, 128 );
		fclose( $fh );
		if ( false === strpos( $tail, '-- DBS-COMPLETE' ) ) {
			@unlink( $sql );
			return new WP_Error( 'dbs_corrupt', 'این بکاپ کامل نیست و قابل استفاده نیست.' );
		}

		$user  = function_exists( 'wp_get_current_user' ) ? wp_get_current_user() : null;
		$state = array(
			'job'       => $job,
			'token'     => $token,
			'mode'      => $mode,
			'sql'       => basename( $sql ),
			'total'     => $size,
			'offset'    => 0,
			'stmts'     => 0,
			'status'    => 'ready',
			'error'     => '',
			'backup_id' => $id,
			'created'   => time(),
			'updated'   => time(),
			'charset'   => ! empty( $meta['charset'] ) ? $meta['charset'] : ( $wpdb->charset ? $wpdb->charset : 'utf8mb4' ),
			'prefix'    => $wpdb->base_prefix,
			'partial'   => count( $tables ),
			'verify'    => ( 'verify' === $mode ) ? array( 'tables' => $vt, 'exact' => ! empty( $meta['rows_exact'] ) ) : null,
			'user'      => array(
				'id'    => $user ? (int) $user->ID : 0,
				'login' => $user ? $user->user_login : '',
			),
			'ip'        => DBS_Context::ip(),
		);
		file_put_contents( $dir . '/restore-' . $job . '.json', wp_json_encode( $state ), LOCK_EX );

		if ( 'restore' === $mode ) {
			DBS_Activity::record(
				array(
					'category'    => 'backup',
					'action'      => 'restore_started',
					'severity'    => 'danger',
					'summary'     => ( $tables ? 'بازگردانی ' . count( $tables ) . ' جدول' : 'بازگردانی کامل دیتابیس' ) . ' به بکاپ ' . wp_date( 'Y-m-d H:i', (int) $meta['created'] ) . ' شروع شد',
					'object_type' => 'backup',
					'object_id'   => $id,
				)
			);
			DBS_Activity::flush();
		}

		return array(
			'job'    => $job,
			'token'  => $token,
			'total'  => $size,
			'mode'   => $mode,
			'runner' => self::runner_url(),
		);
	}

	public static function abort( $job ) {
		$job = preg_replace( '/[^a-z0-9]/i', '', (string) $job );
		$dir = DBS_Storage::dir( false );
		if ( ! $job || ! $dir ) {
			return;
		}
		@unlink( $dir . '/restore-' . $job . '.json' );
		@unlink( $dir . '/restore-' . $job . '.sql' );
	}

	/** Run a prepared job to completion inside one process (WP-CLI / cron). */
	public static function run_sync( $job ) {
		require_once DBS_DIR . 'includes/restore-engine.php';
		$dir = DBS_Storage::dir( false );
		@set_time_limit( 0 );
		do {
			$r = dbs_engine_step( $dir, $job, null, 20.0 );
			if ( ! empty( $r['busy'] ) ) {
				sleep( 1 );
			}
		} while ( empty( $r['error'] ) && ! empty( $r['ok'] ) && 'done' !== ( isset( $r['status'] ) ? $r['status'] : '' ) );
		return $r;
	}

	/** Test-restore a backup into temporary tables (verified, then dropped). */
	public static function verify_sync( $id ) {
		$j = self::init_job( $id, array( 'mode' => 'verify' ) );
		if ( is_wp_error( $j ) ) {
			return $j;
		}
		$r = self::run_sync( $j['job'] );
		self::abort( $j['job'] );
		return $r;
	}
}
