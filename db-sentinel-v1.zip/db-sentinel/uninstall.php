<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

require_once __DIR__ . '/includes/paths.php';

$settings = get_option( 'dbs_settings', array() );
$dir      = dbs_backup_dir( false );

foreach ( array( 'dbs_settings', 'dbs_db_version', 'dbs_missed_at', 'dbs_weekly_at', 'dbs_verify_at', 'dbs_watch_at', 'dbs_anomaly_mass_delete', 'dbs_anomaly_mass_users' ) as $opt ) {
	delete_option( $opt );
}
wp_clear_scheduled_hook( 'dbs_run_backup' );
wp_clear_scheduled_hook( 'dbs_watchdog' );
$wpdb->query( 'DROP TABLE IF EXISTS `' . $wpdb->base_prefix . 'dbs_activity`' );

if ( $dir && is_dir( $dir ) ) {
	// The settings file holds secrets (S3 / FTP / Telegram / encryption passphrase): always remove it.
	@unlink( $dir . '/settings.json' );

	// Backups are kept by default (they may be your only copy). Enable
	// "delete_on_uninstall" in the plugin settings to remove them as well.
	if ( is_array( $settings ) && ! empty( $settings['delete_on_uninstall'] ) ) {
		foreach ( (array) scandir( $dir ) as $item ) {
			if ( '.' !== $item && '..' !== $item && is_file( $dir . '/' . $item ) ) {
				@unlink( $dir . '/' . $item );
			}
		}
		@rmdir( $dir );
	}
}
