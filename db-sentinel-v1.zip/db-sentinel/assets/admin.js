/* DB Sentinel admin UI – vanilla JS, no external dependencies. */
(function () {
  'use strict';
  var C = window.DBS || {};
  var root = document.getElementById('dbs-app');
  if (!root) return;

  /* ------------------------------------------------------------ helpers */
  var SVGNS = 'http://www.w3.org/2000/svg';
  function ls(k, v) {
    try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; }
  }
  function add(el, kids) {
    kids.forEach(function (c) {
      if (Array.isArray(c)) return add(el, c);
      if (c === null || c === undefined || c === false) return;
      el.append(c.nodeType ? c : document.createTextNode(String(c)));
    });
  }
  function mk(ns, tag, a, kids) {
    var e = ns ? document.createElementNS(SVGNS, tag) : document.createElement(tag);
    if (a) Object.keys(a).forEach(function (n) {
      var v = a[n];
      if (v === null || v === undefined || v === false) return;
      if (n === 'class') { ns ? e.setAttribute('class', v) : (e.className = v); }
      else if (n === 'html') e.innerHTML = v;
      else if (n.slice(0, 2) === 'on') e.addEventListener(n.slice(2).toLowerCase(), v);
      else if (n === 'style' && typeof v === 'object') Object.assign(e.style, v);
      else e.setAttribute(n, v === true ? '' : v);
    });
    add(e, kids);
    return e;
  }
  function h(tag, a) { return mk(false, tag, a, Array.prototype.slice.call(arguments, 2)); }
  function s(tag, a) { return mk(true, tag, a, Array.prototype.slice.call(arguments, 2)); }

  var ICONS = {
    shield: '<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z"/>',
    db: '<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>',
    download: '<path d="M12 4v11m0 0l-4-4m4 4l4-4M5 20h14"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3m-8 0l1 13h8l1-13"/>',
    restore: '<path d="M4 12a8 8 0 1 0 3-6.2M4 4v5h5M12 8v4l3 2"/>',
    alert: '<path d="M12 3l10 18H2L12 3zM12 10v5M12 18v.5"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
    plug: '<path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 0 1-12 0V8zM12 17v4"/>',
    brush: '<path d="M4 20c3 0 4-2 4-4l9-9-2-2-9 9c-2 0-4 1-4 4 0 1 1 2 2 2zM15 5l4 4"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    cog: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/>',
    moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
    chev: '<path d="M6 9l6 6 6-6"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-3-6.2M20 4v5h-5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5"/>',
    upload: '<path d="M12 16V4m0 0l-4 4m4-4l4 4M5 20h14"/>',
    cloud: '<path d="M7 18a4 4 0 0 1-.5-7.97A6 6 0 0 1 18 9a4.5 4.5 0 0 1 0 9H7z"/>',
    compare: '<path d="M8 3v18M16 3v18M4 7h8M12 17h8"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    unlock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7-2.6"/>',
    verify: '<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z"/><path d="M9 12l2 2 4-4"/>',
    undo: '<path d="M9 14L4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3"/>',
    scan: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5M8 11h6"/>',
    tool: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.7 2.7-2.6-.6-.6-2.6 2.9-2.5z"/>'
  };
  function ic(name, cls) {
    return h('span', { class: 'dbs-ic ' + (cls || ''), html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || '') + '</svg>' });
  }

  var nf = new Intl.NumberFormat('fa-IR');
  function num(n) { return nf.format(n); }
  function bytes(n) {
    if (!n) return '۰ بایت';
    var u = ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت'], i = 0;
    while (n >= 1024 && i < 3) { n /= 1024; i++; }
    return new Intl.NumberFormat('fa-IR', { maximumFractionDigits: i ? 1 : 0 }).format(n) + ' ' + u[i];
  }
  function dur(sec) {
    sec = Math.max(0, Math.round(sec));
    var d = Math.floor(sec / 86400), hh = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
    if (d) return num(d) + ' روز' + (hh ? ' و ' + num(hh) + ' ساعت' : '');
    if (hh) return num(hh) + ' ساعت' + (m && hh < 12 ? ' و ' + num(m) + ' دقیقه' : '');
    if (m) return num(m) + ' دقیقه';
    return 'چند ثانیه';
  }

  var S = {
    tab: (location.hash || '').replace('#', '') || 'dashboard',
    ov: null, selected: null, first: true, runnerOk: null,
    jalali: ls('dbs_cal') !== 'g', dark: ls('dbs_theme') === 'd',
    skew: (C.now || 0) - Math.floor(Date.now() / 1000),
    act: { f: { range: '48', q: '', kind: '', category: '', severity: '', user: '', actor: '', context: '', id: 0, since: 0 }, rows: [], total: 0, loading: false, open: {}, opts: null, req: 0 },
    ins: { range: 168, data: null },
    settings: null, busy: false
  };
  function nowTs() { return Math.floor(Date.now() / 1000) + S.skew; }
  function rel(ts) {
    var d = ts - nowTs();
    if (Math.abs(d) < 60) return 'همین الان';
    return d < 0 ? dur(-d) + ' پیش' : dur(d) + ' دیگر';
  }
  function tzfmt(ts, o) {
    var loc = S.jalali ? 'fa-IR-u-ca-persian' : 'fa-IR-u-ca-gregory';
    var opt = Object.assign({}, o), d;
    try {
      if (C.tzName) { opt.timeZone = C.tzName; d = new Date(ts * 1000); }
      else { opt.timeZone = 'UTC'; d = new Date((ts + (C.tzOffset || 0)) * 1000); }
      return new Intl.DateTimeFormat(loc, opt).format(d);
    } catch (e) {
      opt.timeZone = 'UTC'; d = new Date((ts + (C.tzOffset || 0)) * 1000);
      return new Intl.DateTimeFormat(loc, opt).format(d);
    }
  }
  function dateStr(ts) { return tzfmt(ts, { month: 'short', day: 'numeric' }); }
  function timeStr(ts) { return tzfmt(ts, { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }); }
  function dtStr(ts) { return tzfmt(ts, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }); }
  function fullStr(ts) { return tzfmt(ts, { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }); }

  var CAT = { option: 'تنظیمات', post: 'محتوا', user: 'کاربر', plugin: 'افزونه', theme: 'پوسته', widget: 'ابزارک', meta: 'فیلد سفارشی', menu: 'منو', backup: 'بکاپ', core: 'هسته', db: 'کوئری SQL', anomaly: 'ناهنجاری', undo: 'برگرداندن', tools: 'ابزار' };
  var CTX = { admin: 'پنل مدیریت', ajax: 'AJAX', rest: 'REST API', cron: 'کرون', cli: 'WP-CLI', frontend: 'بخش عمومی سایت', xmlrpc: 'XML-RPC', install: 'نصب' };
  var ATYPE = { plugin: 'افزونه', theme: 'پوسته', core: 'هسته وردپرس', 'mu-plugin': 'افزونه ضروری' };
  var ROLE = { administrator: 'مدیر کل', editor: 'ویرایشگر', author: 'نویسنده', contributor: 'مشارکت‌کننده', subscriber: 'مشترک', shop_manager: 'مدیر فروشگاه', customer: 'مشتری' };
  var SEV = { info: 'عادی', notice: 'توجه', warning: 'هشدار', danger: 'خطر' };
  var BTYPE = { auto: ['خودکار', 'teal'], manual: ['دستی', 'cobalt'], pre_restore: ['ایمنی قبل از بازگردانی', 'amber'], pre_update: ['ایمنی قبل از آپدیت', 'amber'], pre_tool: ['ایمنی قبل از ابزار', 'amber'], uploaded: ['آپلودشده', 'cobalt'], imported: ['واردشده', 'cobalt'] };
  var PALETTE = ['#3d5fd0', '#12907b', '#c2571a', '#8a4fd1', '#c23b78', '#2a7fa8', '#7a8a10'];
  function colorOf(str) { var x = 0; for (var i = 0; i < str.length; i++) x = (x * 31 + str.charCodeAt(i)) >>> 0; return PALETTE[x % PALETTE.length]; }

  /* ------------------------------------------------------------ api */
  function api(name, data) {
    var body = new URLSearchParams();
    body.set('action', 'dbs'); body.set('nonce', C.nonce); body.set('do', name);
    Object.keys(data || {}).forEach(function (k) {
      var v = data[k];
      body.set(k, (v !== null && typeof v === 'object') ? JSON.stringify(v) : v);
    });
    return fetch(C.ajax, { method: 'POST', body: body, credentials: 'same-origin' }).then(function (r) {
      return r.text();
    }, function () { throw new Error('اتصال به سرور برقرار نشد.'); }).then(function (t) {
      var j;
      try { j = JSON.parse(t); } catch (e) { throw new Error('پاسخ نامعتبر از سرور. اگر عملیات طولانی بود، ممکن است زمان درخواست تمام شده و کار در پس‌زمینه ادامه داشته باشد.'); }
      if (j === -1 || j === 0) throw new Error('نشست شما منقضی شده؛ صفحه را دوباره بارگذاری کنید.');
      if (!j.success) { var er = new Error((j.data && j.data.message) || 'خطای ناشناخته'); er.data = j.data || {}; er.reauth = !!(j.data && j.data.reauth); throw er; }
      return j.data;
    });
  }

  /* ------------------------------------------------------------ ui atoms */
  var toastWrap = h('div', { class: 'dbs-toast-wrap' });
  function toast(msg, err) {
    var t = h('div', { class: 'dbs-toast' + (err ? ' err' : '') }, msg);
    toastWrap.appendChild(t);
    setTimeout(function () { t.remove(); }, err ? 7000 : 3800);
  }
  var tipEl = h('div', { class: 'dbs-tip', style: { display: 'none' } });
  function showTip(ev, nodes) {
    tipEl.replaceChildren.apply(tipEl, nodes); tipEl.style.display = 'block';
    var x = ev.clientX, y = ev.clientY, w = tipEl.offsetWidth;
    tipEl.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, x - w / 2)) + 'px';
    tipEl.style.top = (y + 18) + 'px';
  }
  function hideTip() { tipEl.style.display = 'none'; }

  function modal(title, body, actions, wide, locked) {
    var ovl = h('div', { class: 'dbs-ovl' });
    var onKey = function (e) { if (e.key === 'Escape' && !locked) close(); };
    var close = function () { ovl.remove(); document.removeEventListener('keydown', onKey); };
    var box = h('div', { class: 'dbs-modal' + (wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true' },
      h('div', { class: 'dbs-modal-h' }, h('h3', null, title), locked ? null : h('button', { class: 'dbs-x', 'aria-label': 'بستن', onclick: close }, '×')),
      h('div', { class: 'dbs-modal-b' }, body),
      actions ? h('div', { class: 'dbs-modal-f' }, actions) : null);
    ovl.appendChild(box);
    if (!locked) {
      ovl.addEventListener('mousedown', function (e) { if (e.target === ovl) close(); });
      document.addEventListener('keydown', onKey);
    }
    root.appendChild(ovl);
    return { el: box, close: close, ovl: ovl };
  }
  function confirmBox(title, text, okLabel, danger) {
    return new Promise(function (res) {
      var m;
      m = modal(title, [h('p', null, text)], [
        h('button', { class: 'dbs-btn ' + (danger ? 'dbs-btn-danger' : 'dbs-btn-amber'), onclick: function () { m.close(); res(true); } }, okLabel),
        h('button', { class: 'dbs-btn', onclick: function () { m.close(); res(false); } }, 'انصراف')
      ]);
    });
  }

  function chip(text, cls) { return h('span', { class: 'dbs-chip ' + (cls || '') }, text); }
  function sevDot(sev) { return h('span', { class: 'dbs-dot sev-' + sev }); }
  function avatar(name) { return h('span', { class: 'dbs-avatar', style: { '--av': colorOf(name) } }, (name || '?').charAt(0).toUpperCase()); }
  function actorIcon(t) { return ic({ plugin: 'plug', 'mu-plugin': 'plug', theme: 'brush', core: 'globe' }[t] || 'cog'); }
  function empty(title, text, actionNode) { return h('div', { class: 'dbs-empty' }, h('h3', null, title), h('p', null, text), actionNode ? h('div', { style: { marginTop: '14px' } }, actionNode) : null); }

  function boardRows(items, color, onclick) {
    var max = Math.max.apply(null, items.map(function (i) { return i.c; }).concat([1]));
    return h('div', { class: 'dbs-board' }, items.map(function (it) {
      return h('div', { class: 'dbs-row' + (onclick ? ' click' : ''), onclick: onclick ? function () { onclick(it); } : null },
        h('div', { class: 'dbs-lbl' }, it.icon || null, h('span', { class: 't', title: it.label }, it.label)),
        h('div', { class: 'dbs-bar' }, h('i', { style: { width: Math.max(3, it.c / max * 100) + '%', '--c': color } })),
        h('div', { class: 'dbs-count' }, num(it.c)));
    }));
  }

  /* ------------------------------------------------------------ shell */
  var heroEl = h('header', { class: 'dbs-hero' });
  var tabsEl = h('nav', { class: 'dbs-tabs', role: 'tablist' });
  var mainEl = h('main', { class: 'dbs-main' });
  root.replaceChildren(heroEl, tabsEl, mainEl, toastWrap, tipEl);
  root.classList.toggle('dbs-dark', S.dark);

  var TABS = [['dashboard', 'نمای کلی'], ['backups', 'بکاپ‌ها'], ['activity', 'تغییرات دیتابیس'], ['insights', 'آمار و تحلیل'], ['security', 'امنیت'], ['tools', 'ابزارها'], ['settings', 'تنظیمات']];
  function renderTabs() {
    tabsEl.replaceChildren.apply(tabsEl, TABS.map(function (t) {
      var badge = (t[0] === 'activity' && S.ov && S.ov.counts.warn48) ? h('span', { class: 'dbs-badge', title: 'تغییرات مهم در ۴۸ ساعت اخیر' }, num(S.ov.counts.warn48)) : null;
      return h('button', { class: 'dbs-tab', role: 'tab', 'aria-selected': S.tab === t[0] ? 'true' : 'false', onclick: function () { go(t[0]); } }, t[1], badge);
    }));
  }
  function go(tab) {
    S.tab = tab; try { history.replaceState(null, '', '#' + tab); } catch (e) { /* ignore */ }
    renderTabs(); renderMain();
  }
  function renderMain() {
    var v = { dashboard: viewDashboard, backups: viewBackups, activity: viewActivity, insights: viewInsights, security: viewSecurity, tools: viewTools, settings: viewSettings }[S.tab] || viewDashboard;
    mainEl.replaceChildren(); v();
  }

  /* ------------------------------------------------------------ hero + timeline */
  function logo() {
    return h('span', { class: 'dbs-logo', html: '<svg viewBox="0 0 48 48" fill="none"><path d="M24 4l16 6v12c0 10-7 18-16 22C15 40 8 32 8 22V10l16-6z" fill="#15384a" stroke="#e8a13a" stroke-width="2.4" stroke-linejoin="round"/><ellipse cx="24" cy="18" rx="8" ry="3.2" stroke="#e9f2f5" stroke-width="2"/><path d="M16 18v7c0 1.8 3.6 3.2 8 3.2s8-1.4 8-3.2v-7" stroke="#e9f2f5" stroke-width="2"/><path d="M16 25v5c0 1.8 3.6 3.2 8 3.2s8-1.4 8-3.2v-5" stroke="#e9f2f5" stroke-width="2"/></svg>' });
  }
  function selectedBackup() { return S.selected && S.ov ? S.ov.backups.filter(function (b) { return b.id === S.selected; })[0] : null; }

  function timeline() {
    var ov = S.ov, now = nowTs();
    var R = ov.settings.retention_hours * 3600, I = ov.settings.interval_hours * 3600;
    var start = now - R - 3600, end = Math.max(now + I, ov.next_run || 0) + 3600;
    var W = 1000, H = 212, pl = 18, pr = 18, base = 92;
    function X(t) { return pl + (t - start) / (end - start) * (W - pl - pr); }
    var svg = s('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'dbs-tl', role: 'img', 'aria-label': 'خط زمانی بکاپ‌ها و تغییرات دیتابیس' });
    var sel = selectedBackup();
    if (sel) svg.append(s('rect', { x: X(sel.created), y: 8, width: Math.max(2, X(now) - X(sel.created)), height: H - 16, fill: 'rgba(232,161,58,.10)', rx: 6 }));

    svg.append(s('line', { x1: pl, x2: W - pr, y1: base, y2: base, stroke: '#3b6177', 'stroke-width': 1.5 }));
    var off = C.tzOffset || 0, t0 = Math.ceil((start + off) / 3600) * 3600 - off;
    for (var t = t0; t <= end; t += 3600) {
      var lh = ((((t + off) % 86400) + 86400) % 86400) / 3600, x = X(t), major = lh % 6 === 0, mid = lh === 0;
      svg.append(s('line', { x1: x, x2: x, y1: base, y2: base + (mid ? 18 : major ? 12 : 6), stroke: mid ? '#7fa3b6' : '#4d7387', 'stroke-width': mid ? 1.6 : 1 }));
      if (mid) svg.append(s('text', { x: x + 5, y: base + 32, fill: '#9fb8c4', 'font-size': 12 }, dateStr(t)));
      else if (major) svg.append(s('text', { x: x, y: base + 30, fill: '#6d8d9d', 'font-size': 11, 'text-anchor': 'middle' }, num(lh)));
    }

    var hgt = { info: 8, notice: 14, warning: 26, danger: 42 }, col = { info: 'rgba(159,184,196,.45)', notice: '#7f98ff', warning: '#e8a13a', danger: '#e5544f' }, rank = { info: 0, notice: 1, warning: 2, danger: 3 };
    var yb = H - 8;
    ov.ticks.slice().sort(function (a, b) { return rank[a[1]] - rank[b[1]]; }).forEach(function (tk) {
      if (tk[0] < start || tk[0] > end) return;
      svg.append(s('rect', { x: X(tk[0]) - 1, y: yb - hgt[tk[1]], width: 2, height: hgt[tk[1]], fill: col[tk[1]], rx: 1 }));
    });

    var bcol = { auto: '#2fc4a8', manual: '#7f98ff', pre_restore: '#e8a13a' };
    ov.backups.forEach(function (b, i) {
      if (b.created < start) return;
      var x = X(b.created), c = bcol[b.type] || '#2fc4a8', isSel = sel && sel.id === b.id;
      var g = s('g', { class: 'dbs-mk', style: '--i:' + i, tabindex: 0, role: 'button', 'aria-label': 'بکاپ ' + dtStr(b.created) });
      g.append(s('line', { x1: x, x2: x, y1: 34, y2: base, stroke: c, 'stroke-width': 2 }));
      if (isSel) g.append(s('circle', { cx: x, cy: 34, r: 15, fill: 'none', stroke: c, 'stroke-width': 1.5, opacity: .5 }));
      g.append(s('circle', { class: 'dbs-mk-dot', cx: x, cy: 34, r: isSel ? 10 : 8, fill: c, stroke: '#0d2431', 'stroke-width': 3 }));
      g.append(s('circle', { cx: x, cy: 34, r: 18, fill: 'transparent' }));
      var pick = function () { S.selected = (S.selected === b.id) ? null : b.id; renderHero(); };
      g.addEventListener('click', pick);
      g.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } });
      var tip = function (e) {
        showTip(e, [h('b', null, 'بکاپ ' + (BTYPE[b.type] || BTYPE.manual)[0]), h('br'), dtStr(b.created), h('br'), bytes(b.size) + ' · ' + num(b.tables) + ' جدول', h('br'), 'حذف خودکار: ' + rel(b.expires_at), h('br'), num(b.changes.total) + ' تغییر پس از آن']);
      };
      g.addEventListener('mouseenter', tip); g.addEventListener('mousemove', tip); g.addEventListener('mouseleave', hideTip);
      svg.append(g);
    });

    if (ov.next_run) {
      var nx = X(ov.next_run);
      svg.append(s('line', { x1: nx, x2: nx, y1: 34, y2: base, stroke: '#e8a13a', 'stroke-width': 2, 'stroke-dasharray': '4 4' }));
      svg.append(s('circle', { cx: nx, cy: 34, r: 8, fill: '#0d2431', stroke: '#e8a13a', 'stroke-width': 2.5 }));
      svg.append(s('text', { x: nx, y: 14, fill: '#f3c377', 'font-size': 12, 'text-anchor': 'middle' }, 'بعدی'));
    }
    var nowX = X(now);
    svg.append(s('line', { x1: nowX, x2: nowX, y1: 24, y2: H - 4, stroke: '#e9f2f5', 'stroke-width': 1.2, opacity: .7 }));
    svg.append(s('rect', { x: nowX - 22, y: 4, width: 44, height: 18, rx: 9, fill: '#e9f2f5' }));
    svg.append(s('text', { x: nowX, y: 17, fill: '#0d2431', 'font-size': 11, 'font-weight': 700, 'text-anchor': 'middle' }, 'اکنون'));
    return svg;
  }

  function selectionStrip() {
    var b = selectedBackup();
    if (!b) return h('div', { class: 'dbs-sel' }, h('span', null, 'روی یکی از نشانه‌های بکاپ کلیک کنید تا ببینید بعد از آن چه تغییراتی در دیتابیس ثبت شده است. خط‌های رنگی زیر خط‌کش، تغییرات ثبت‌شده هستند (هرچه بلندتر، مهم‌تر).'));
    var users = ''; // filled asynchronously in the modal; keep the strip light
    return h('div', { class: 'dbs-sel' },
      h('span', null, 'بکاپ ', h('b', null, (BTYPE[b.type] || BTYPE.manual)[0]), ' — ', dtStr(b.created), ' (', rel(b.created), '، ', bytes(b.size), '). ',
        h('b', null, num(b.changes.total)), ' تغییر پس از آن ثبت شده', b.changes.important ? [' که ', h('b', null, num(b.changes.important)), ' مورد مهم است'] : '', users, '.'),
      h('div', { class: 'dbs-sel-actions' },
        h('button', { class: 'dbs-btn dbs-btn-sm', onclick: function () { showChanges(b); } }, ic('eye'), 'جزئیات تغییرات'),
        h('button', { class: 'dbs-btn dbs-btn-sm dbs-btn-amber', onclick: function () { startRestore(b); } }, ic('restore'), 'بازگردانی به این بکاپ')));
  }

  function renderHero() {
    var ov = S.ov, now = nowTs(), last = ov.backups[0];
    var overdue = ov.next_run && ov.next_run < now - 900;
    var wrap = h('div', { class: 'dbs-tl-wrap' + (S.first ? ' dbs-first' : '') }, timeline());
    S.first = false;
    heroEl.replaceChildren(
      h('div', { class: 'dbs-hero-top' },
        h('div', { class: 'dbs-brand' }, logo(), h('div', null, h('h2', null, 'نگهبان دیتابیس'),
          h('div', { class: 'dbs-sub' },
            last ? h('span', null, 'آخرین بکاپ ', h('b', null, rel(last.created))) : h('span', null, 'هنوز بکاپی گرفته نشده است'),
            ov.next_run ? h('span', null, 'بکاپ بعدی ', h('b', null, rel(ov.next_run))) : null,
            overdue ? h('span', { class: 'dbs-pill' }, ic('alert'), 'زمان‌بند وردپرس عقب افتاده') : null))),
        h('div', { class: 'dbs-hero-actions' },
          h('button', { class: 'dbs-icon-btn', style: { width: 'auto', padding: '0 12px', fontSize: '12.5px', fontFamily: 'inherit' }, title: 'تغییر تقویم', onclick: function () { S.jalali = !S.jalali; ls('dbs_cal', S.jalali ? 'j' : 'g'); renderHero(); renderMain(); } }, S.jalali ? 'تقویم شمسی' : 'تقویم میلادی'),
          h('button', { class: 'dbs-icon-btn', title: 'حالت تیره / روشن', 'aria-label': 'حالت تیره / روشن', onclick: function () { S.dark = !S.dark; ls('dbs_theme', S.dark ? 'd' : 'l'); root.classList.toggle('dbs-dark', S.dark); renderHero(); } }, ic(S.dark ? 'sun' : 'moon')),
          h('button', { class: 'dbs-btn dbs-btn-amber', id: 'dbs-now', onclick: backupNow }, ic('db'), 'بکاپ فوری'))),
      wrap, selectionStrip());
  }

  /* ------------------------------------------------------------ data loading */
  function refresh(silent) {
    return api('overview').then(function (d) {
      S.ov = d; S.skew = d.now - Math.floor(Date.now() / 1000);
      renderHero(); renderTabs();
      if (!silent || S.tab === 'dashboard' || S.tab === 'backups') renderMain();
    }).catch(function (e) { if (!silent) toast(e.message, true); });
  }

  function backupNow() {
    var btn = document.getElementById('dbs-now');
    if (S.busy) return;
    S.busy = true;
    if (btn) { btn.disabled = true; btn.replaceChildren(ic('refresh', 'dbs-spin'), 'در حال بکاپ‌گیری…'); }
    api('backup_now', { type: 'manual' }).then(function (m) {
      toast('بکاپ ساخته شد (' + bytes(m.size) + ')');
    }).catch(function (e) { toast(e.message, true); }).then(function () {
      S.busy = false; return refresh();
    });
  }

  /* ------------------------------------------------------------ dashboard */
  function barChart() {
    var W = 600, H = 150, pb = 18, n = 48, ov = S.ov, off = C.tzOffset || 0;
    var endH = Math.floor(nowTs() / 3600), map = {};
    ov.chart.forEach(function (b) { map[Math.floor(b.t / 3600)] = b; });
    var slots = [], max = 1;
    for (var i = 0; i < n; i++) { var hr = endH - (n - 1) + i, b = map[hr] || { c: 0, w: 0 }; slots.push({ hr: hr, c: b.c, w: b.w }); if (b.c > max) max = b.c; }
    var svg = s('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'dbs-chart', role: 'img', 'aria-label': 'نمودار تغییرات ساعتی' });
    var bw = W / n;
    svg.append(s('line', { x1: 0, x2: W, y1: H - pb, y2: H - pb, stroke: 'var(--line)' }));
    slots.forEach(function (sl, i) {
      var x = i * bw, hh = sl.c ? Math.max(3, sl.c / max * (H - pb - 8)) : 0, wh = sl.c ? hh * (sl.w / sl.c) : 0;
      var g = s('g', null, s('title', null, dtStr(sl.hr * 3600) + ': ' + num(sl.c) + ' تغییر' + (sl.w ? ' (' + num(sl.w) + ' مهم)' : '')));
      g.append(s('rect', { x: x + 1.5, y: 0, width: bw - 3, height: H - pb, fill: 'transparent' }));
      if (hh) g.append(s('rect', { x: x + 1.5, y: H - pb - hh, width: bw - 3, height: hh, rx: 2, style: 'fill:var(--cobalt)', opacity: .85 }));
      if (wh) g.append(s('rect', { x: x + 1.5, y: H - pb - wh, width: bw - 3, height: wh, rx: 2, fill: '#e8a13a' }));
      svg.append(g);
      var lh = ((((sl.hr * 3600 + off) % 86400) + 86400) % 86400) / 3600;
      if (lh % 6 === 0) svg.append(s('text', { x: x + bw / 2, y: H - 4, 'text-anchor': 'middle' }, lh === 0 ? dateStr(sl.hr * 3600) : num(lh)));
    });
    return svg;
  }

  function eventMini(e) {
    return h('div', { class: 'dbs-feed-item', onclick: function () { openEvent(e.id); } },
      sevDot(e.severity),
      h('div', null, h('div', { class: 'dbs-fs' }, e.summary),
        h('div', { class: 'dbs-fm' }, h('span', null, e.user_login || (e.context === 'cron' ? 'سیستم' : 'ناشناس')), h('span', null, e.actor_name), h('span', null, rel(e.ts)))));
  }
  function openEvent(id) {
    S.act.f = { range: 'all', q: '', kind: '', category: '', severity: '', user: '', actor: '', context: '', id: id, since: 0 };
    S.act.open[id] = true; go('activity');
  }

  function healthItem(state, title, sub) {
    return h('div', { class: 'dbs-hi' }, h('span', { class: state }, ic(state === 'ok' ? 'check' : state === 'bad' ? 'x' : 'alert')), h('div', null, h('b', null, title), sub ? h('small', null, sub) : null));
  }
  function healthList() {
    var hl = S.ov.health, items = [];
    items.push(healthItem(hl.dir_ok && hl.writable ? 'ok' : 'bad', 'پوشه بکاپ', hl.dir_ok ? (hl.writable ? 'ساخته شده و قابل نوشتن است' : 'قابل نوشتن نیست') : 'ساخته نشد'));
    items.push(healthItem(hl.gzip ? 'ok' : 'wn', 'فشرده‌سازی gzip', hl.gzip ? 'فعال؛ بکاپ‌ها کم‌حجم می‌شوند' : 'zlib نصب نیست؛ بکاپ‌ها فشرده نمی‌شوند'));
    items.push(healthItem(hl.wp_cron_disabled ? 'wn' : 'ok', 'زمان‌بندی', hl.wp_cron_disabled ? 'WP-Cron غیرفعال است؛ مطمئن شوید کرون سرور تنظیم شده' : 'WP-Cron وردپرس (وابسته به بازدید سایت)'));
    items.push(healthItem(S.runnerOk === false ? 'bad' : (S.runnerOk ? 'ok' : 'wn'), 'موتور بازگردانی', S.runnerOk === false ? 'دسترسی مستقیم به restore-runner.php مسدود است' : (S.runnerOk ? 'در دسترس' : 'در حال بررسی…')));
    var rm = S.ov.remote || {};
    var lastB = S.ov.backups[0];
    items.push(healthItem(rm.configured ? (lastB && lastB.remote && lastB.remote.ok ? 'ok' : 'wn') : 'wn', 'ذخیره‌ساز بیرونی',
      rm.configured ? ((rm.driver === 's3' ? 'S3' : 'FTP') + (lastB && lastB.remote && lastB.remote.ok ? ' — آخرین بکاپ ارسال شده' : ' — آخرین بکاپ هنوز ارسال نشده')) : 'تنظیم نشده؛ بکاپ‌ها فقط روی همین سرور هستند'));
    items.push(healthItem('ok', 'سرور', 'PHP ' + hl.php + '، پایگاه‌داده ' + hl.mysql));
    if (hl.disk_free) items.push(healthItem(hl.disk_free < (S.ov.totals.size || 1) * 3 ? 'wn' : 'ok', 'فضای آزاد دیسک', bytes(hl.disk_free)));
    return h('div', { class: 'dbs-health' }, items);
  }

  function viewDashboard() {
    var ov = S.ov, now = nowTs();
    if (!ov) return mainEl.append(h('div', { class: 'dbs-boot' }, 'در حال بارگذاری…'));
    var nextTxt = ov.next_run ? dur(ov.next_run - now) : '—';
    var ledger = h('div', { class: 'dbs-ledger' },
      h('div', { class: 'dbs-cell' }, h('small', null, 'بکاپ‌های نگهداری‌شده'), h('strong', null, num(ov.totals.count)), h('span', null, 'مربوط به ' + num(ov.settings.retention_hours) + ' ساعت اخیر')),
      h('div', { class: 'dbs-cell' }, h('small', null, 'حجم کل بکاپ‌ها'), h('strong', null, bytes(ov.totals.size)), h('span', null, ov.health.db_size ? 'حجم دیتابیس: ' + bytes(ov.health.db_size) : ' ')),
      h('div', { class: 'dbs-cell' }, h('small', null, 'تغییرات ثبت‌شده (۴۸ ساعت)'), h('strong', null, num(ov.counts.events48)), h('span', null, num(ov.counts.warn48) + ' مورد مهم')),
      h('div', { class: 'dbs-cell' }, h('small', null, 'بکاپ بعدی'), h('strong', null, ov.next_run ? nextTxt : '—'), h('span', null, ov.next_run ? dtStr(ov.next_run) : 'زمان‌بندی نشده')));

    var feedPanel = h('section', { class: 'dbs-panel' }, h('h3', null, 'نیازمند توجه'), h('p', { class: 'dbs-hint' }, 'هشدارها و موارد خطرناک هفت روز اخیر'),
      ov.feed.length ? h('div', { class: 'dbs-feed' }, ov.feed.map(eventMini)) : empty('همه‌چیز آرام است', 'در هفت روز گذشته تغییر مشکوک یا مهمی ثبت نشده است.'));

    var users = ov.top_users.map(function (u) { return { label: u.login || 'سیستم / ناشناس', c: u.c, icon: avatar(u.login || '؟'), key: u.login }; });
    var actors = ov.top_actors.map(function (a) { return { label: a.name, c: a.c, icon: actorIcon(a.type), key: a.type + ':' + a.slug }; });

    mainEl.append(ledger,
      h('div', { class: 'dbs-grid2' },
        h('section', { class: 'dbs-panel' }, h('h3', null, 'فعالیت دیتابیس در ۴۸ ساعت اخیر'), h('p', { class: 'dbs-hint' }, 'تعداد تغییرات ثبت‌شده در هر ساعت؛ بخش نارنجی یعنی تغییر مهم'), barChart()),
        feedPanel),
      h('div', { class: 'dbs-grid2e' },
        h('section', { class: 'dbs-panel' }, h('h3', null, 'چه کسانی تغییر می‌دهند'), h('p', { class: 'dbs-hint' }, 'بر اساس کاربر واردشده'),
          users.length ? boardRows(users, 'var(--cobalt)', function (it) { filterActivity({ user: it.key || '__none__' }); }) : empty('هنوز داده‌ای نیست', 'به‌محض ثبت اولین تغییر، اینجا نمایش داده می‌شود.')),
        h('section', { class: 'dbs-panel' }, h('h3', null, 'کدام افزونه یا بخش'), h('p', { class: 'dbs-hint' }, 'مسئول نوشتن در دیتابیس (بر اساس ردیابی کد)'),
          actors.length ? boardRows(actors, 'var(--teal)', function (it) { filterActivity({ actor: it.key }); }) : empty('هنوز داده‌ای نیست', 'به‌محض ثبت اولین تغییر، اینجا نمایش داده می‌شود.'))),
      h('section', { class: 'dbs-panel' }, h('h3', null, 'وضعیت سلامت'), h('p', { class: 'dbs-hint' }, 'اگر مورد قرمز یا نارنجی دیدید، پیش از نیاز به بازگردانی آن را رفع کنید'), healthList()));
  }
  function filterActivity(patch) {
    S.act.f = Object.assign({ range: '168', q: '', kind: '', category: '', severity: '', user: '', actor: '', context: '', id: 0, since: 0 }, patch);
    go('activity');
  }

  /* ------------------------------------------------------------ backups */
  function iconAct(name, title, fn) {
    return h('button', { class: 'dbs-btn dbs-btn-sm', title: title, 'aria-label': title, onclick: fn }, ic(name));
  }

  function viewBackups() {
    var ov = S.ov, notes = [];
    if (S.runnerOk === false) notes.push(h('div', { class: 'dbs-alert bad' }, ic('alert'), h('div', null, h('b', null, 'بازگردانی روی این هاست کار نمی‌کند. '), 'دسترسی مستقیم به فایل includes/restore-runner.php مسدود شده است (افزونه امنیتی یا تنظیمات سرور). این فایل باید از بیرون قابل فراخوانی باشد چون هنگام بازگردانی وردپرس نمی‌تواند خودش را اجرا کند.')));
    var remoteOn = ov.remote && ov.remote.configured;
    var toolbar = h('div', { class: 'dbs-toolbar' },
      h('button', { class: 'dbs-btn dbs-btn-amber', onclick: backupNow }, ic('db'), 'بکاپ فوری'),
      h('button', { class: 'dbs-btn', onclick: openUpload }, ic('upload'), 'آپلود بکاپ'),
      h('button', { class: 'dbs-btn', onclick: openRemote }, ic('cloud'), 'ذخیره‌ساز بیرونی'),
      h('button', { class: 'dbs-btn', onclick: openCompare }, ic('compare'), 'مقایسه'));
    if (!ov.backups.length) {
      return mainEl.append.apply(mainEl, notes.concat([toolbar, h('section', { class: 'dbs-panel' }, empty('هنوز بکاپی وجود ندارد', 'اولین بکاپ خودکار به‌زودی گرفته می‌شود؛ یا همین حالا یکی بسازید یا یک فایل بکاپ آپلود کنید.'))]));
    }
    var rows = ov.backups.map(function (b) {
      var bt = BTYPE[b.type] || BTYPE.manual, flags = [chip(bt[0], bt[1])];
      if (b.locked) flags.push(h('span', { class: 'dbs-chip', title: 'از حذف خودکار مستثنی است' }, ic('lock'), 'قفل'));
      if (b.remote) flags.push(b.remote.ok
        ? h('span', { class: 'dbs-chip teal', title: 'روی ذخیره‌ساز بیرونی هم هست' }, ic('cloud'), 'بیرونی' + (b.remote.enc ? ' (رمزنگاری‌شده)' : ''))
        : h('span', { class: 'dbs-chip coral', title: b.remote.error || '' }, ic('cloud'), 'ارسال ناموفق'));
      if (b.verified) flags.push(b.verified.ok ? h('span', { class: 'dbs-chip teal', title: 'در ' + dtStr(b.verified.ts) + ' با موفقیت در جدول‌های موقت بازگردانی شد' }, ic('verify'), 'تست‌شده')
        : h('span', { class: 'dbs-chip coral', title: (b.verified.mismatch || []).join('\n') }, 'تست ناموفق'));
      return h('tr', null,
        h('td', null, h('b', null, dtStr(b.created)), h('div', { class: 'dbs-sub2' }, rel(b.created)), b.note ? h('div', { class: 'dbs-sub2 dbs-note', title: b.note }, b.note) : null),
        h('td', null, h('div', { class: 'dbs-flags' }, flags)),
        h('td', { class: 'num' }, bytes(b.size), h('div', { class: 'dbs-sub2' }, b.compressed ? 'gzip' : 'بدون فشرده‌سازی')),
        h('td', { class: 'num' }, num(b.tables) + ' جدول', h('div', { class: 'dbs-sub2' }, num(b.rows) + (b.rows_exact === false ? '+ ردیف (تقریبی)' : ' ردیف'))),
        h('td', null, b.locked ? 'قفل — حذف نمی‌شود' : rel(b.expires_at), ov.backups[0].id === b.id && !b.locked ? h('div', { class: 'dbs-sub2' }, 'آخرین بکاپ همیشه نگه‌داشته می‌شود') : null),
        h('td', null, b.changes.total ? h('button', { class: 'dbs-btn dbs-btn-sm', onclick: function () { showChanges(b); } }, num(b.changes.total) + ' تغییر', b.changes.important ? chip(num(b.changes.important) + ' مهم', 'coral') : null) : h('span', { class: 'dbs-sub2' }, 'بدون تغییر')),
        h('td', null, h('div', { class: 'acts' },
          h('button', { class: 'dbs-btn dbs-btn-sm dbs-btn-amber', onclick: function () { startRestore(b); } }, ic('restore'), 'بازگردانی'),
          iconAct('verify', 'تست بازگردانی (بدون دست‌زدن به سایت)', function () { verifyBackup(b); }),
          remoteOn ? iconAct('cloud', 'ارسال به ذخیره‌ساز بیرونی', function () { sendRemote(b); }) : null,
          iconAct(b.locked ? 'lock' : 'unlock', 'قفل و یادداشت', function () { lockModal(b); }),
          h('a', { class: 'dbs-btn dbs-btn-sm', href: C.dl + '&id=' + encodeURIComponent(b.id), title: 'دانلود فایل SQL', 'aria-label': 'دانلود' }, ic('download')),
          iconAct('trash', 'حذف', function () { deleteBackup(b); }))));
    });
    mainEl.append.apply(mainEl, notes.concat([toolbar, h('section', { class: 'dbs-panel' },
      h('h3', null, 'بکاپ‌های دیتابیس'),
      h('p', { class: 'dbs-hint' }, 'هر ' + num(ov.settings.interval_hours) + ' ساعت یک بکاپ گرفته می‌شود و بکاپ‌های قدیمی‌تر از ' + num(ov.settings.retention_hours) + ' ساعت خودکار حذف می‌شوند (مگر قفل باشند). فقط دیتابیس بکاپ می‌شود، نه فایل‌ها.'),
      h('div', { class: 'dbs-scroll' }, h('table', { class: 'dbs-table' },
        h('thead', null, h('tr', null, ['زمان', 'وضعیت', 'حجم', 'محتوا', 'حذف خودکار', 'تغییرات پس از آن', 'عملیات'].map(function (t) { return h('th', null, t); }))),
        h('tbody', null, rows))))]));
  }

  function deleteBackup(b) {
    confirmBox('حذف بکاپ', 'بکاپ ' + dtStr(b.created) + ' برای همیشه حذف شود؟', 'حذف', true).then(function (ok) {
      if (!ok) return;
      askPw('برای حذف بکاپ رمز عبور را وارد کنید.').then(function (pw) {
        if (pw === null) return;
        api('backup_delete', { id: b.id, pw: pw }).then(function () { toast('بکاپ حذف شد'); if (S.selected === b.id) S.selected = null; return refresh(); }).catch(function (e) { toast(e.message, true); });
      });
    });
  }

  function lockModal(b) {
    var note = h('input', { class: 'dbs-input', value: b.note || '', placeholder: 'مثلاً: قبل از تغییر قالب', style: { width: '100%' }, maxlength: 200 });
    var lk = h('input', { type: 'checkbox', checked: !!b.locked });
    var m = modal('قفل و یادداشت بکاپ', [
      h('p', { class: 'dbs-sub2' }, 'بکاپ قفل‌شده هیچ‌وقت خودکار حذف نمی‌شود.'),
      h('label', { class: 'dbs-switch' }, lk, h('span', { class: 'tr' }), h('span', null, 'قفل کن (حذف خودکار نشود)')),
      h('div', null, h('label', { style: { display: 'block', fontWeight: 700, marginBottom: '6px' } }, 'یادداشت'), note)
    ], [
      h('button', { class: 'dbs-btn dbs-btn-amber', onclick: function () {
        api('backup_lock', { id: b.id, locked: lk.checked ? 1 : 0, note: note.value }).then(function () { m.close(); toast('ذخیره شد'); return refresh(); }).catch(function (e) { toast(e.message, true); });
      } }, 'ذخیره'),
      h('button', { class: 'dbs-btn', onclick: function () { m.close(); } }, 'انصراف')]);
  }

  function sendRemote(b) {
    toast('در حال ارسال به ذخیره‌ساز بیرونی…');
    api('remote_upload', { id: b.id }).then(function () { toast('بکاپ روی ذخیره‌ساز بیرونی ذخیره شد'); return refresh(); }).catch(function (e) { toast(e.message, true); refresh(true); });
  }

  function changesBody(d, compact) {
    var parts = [];
    parts.push(h('p', null, h('b', null, num(d.total)), ' تغییر در دیتابیس بعد از این بکاپ ثبت شده است' + (d.important ? ' که ' + num(d.important) + ' مورد آن مهم است.' : '.')));
    if (d.users.length) parts.push(h('div', null, h('h4', { style: { margin: '0 0 6px', fontSize: '13px', color: 'var(--muted)' } }, 'کاربران'), h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap' } }, d.users.map(function (u) { return chip((u.login || 'سیستم / ناشناس') + ' ×' + num(u.c)); }))));
    if (d.actors.length) parts.push(h('div', null, h('h4', { style: { margin: '0 0 6px', fontSize: '13px', color: 'var(--muted)' } }, 'افزونه / بخش'), h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap' } }, d.actors.map(function (a) { return chip(a.name + ' ×' + num(a.c)); }))));
    if (d.top.length) parts.push(h('div', null, h('h4', { style: { margin: '0 0 2px', fontSize: '13px', color: 'var(--muted)' } }, 'مهم‌ترین تغییرات'), h('div', { class: 'dbs-feed' }, d.top.slice(0, compact ? 4 : 8).map(function (e) {
      return h('div', { class: 'dbs-feed-item', style: { cursor: 'default' } }, sevDot(e.severity), h('div', null, h('div', { class: 'dbs-fs', style: { WebkitLineClamp: 3 } }, e.summary), h('div', { class: 'dbs-fm' }, h('span', null, e.user_login || 'سیستم / ناشناس'), h('span', null, e.actor_name), h('span', null, dtStr(e.ts)))));
    }))));
    return parts;
  }

  function showChanges(b) {
    var body = h('div', { class: 'dbs-modal-b', style: { padding: 0 } }, h('p', { class: 'dbs-sub2' }, 'در حال بارگذاری…'));
    var m = modal('تغییرات پس از بکاپ ' + dtStr(b.created), [body], [
      h('button', { class: 'dbs-btn', onclick: function () { m.close(); S.act.f = { range: 'custom', q: '', kind: 'event', category: '', severity: '', user: '', actor: '', context: '', id: 0, since: b.created }; go('activity'); } }, 'مشاهده همه در تب تغییرات'),
      h('button', { class: 'dbs-btn dbs-btn-amber', onclick: function () { m.close(); startRestore(b); } }, ic('restore'), 'بازگردانی به این بکاپ')
    ], true);
    api('changes_since', { id: b.id }).then(function (d) { body.replaceChildren.apply(body, changesBody(d)); }).catch(function (e) { body.replaceChildren(h('p', null, e.message)); });
  }

  /* ------------------------------------------------------------ restore flow, verify, upload, remote, compare */
  var WORD = 'بازگردانی';
  function normFa(x) { return x.replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/\u200c/g, '').trim(); }
  function delay(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function askPw(msg) {
    return new Promise(function (res) {
      if (!(S.ov && S.ov.settings && S.ov.settings.reauth)) return res('');
      var input = h('input', { class: 'dbs-input', type: 'password', autocomplete: 'current-password', placeholder: 'رمز عبور حساب شما', style: { width: '100%' } });
      var m;
      var ok = function () { if (!input.value) return; m.close(); res(input.value); };
      input.addEventListener('keydown', function (e) { if (e.key === 'Enter') ok(); });
      m = modal('تأیید هویت', [h('p', null, msg || 'برای ادامه رمز عبور خود را وارد کنید.'), input], [
        h('button', { class: 'dbs-btn dbs-btn-amber', onclick: ok }, 'تأیید'),
        h('button', { class: 'dbs-btn', onclick: function () { m.close(); res(null); } }, 'انصراف')]);
      setTimeout(function () { input.focus(); }, 50);
    });
  }

  /** Drive a restore / verify job through the standalone runner until it is done. */
  function pollJob(job, onProgress) {
    return new Promise(function (resolve, reject) {
      var retries = 0;
      function tick() {
        var fd = new URLSearchParams(); fd.set('job', job.job); fd.set('token', job.token); fd.set('do', 'step');
        fetch(job.runner, { method: 'POST', body: fd, cache: 'no-store' }).then(function (r) { return r.text(); }).then(function (t) {
          var j; try { j = JSON.parse(t); } catch (e) { throw new Error('پاسخ نامعتبر از موتور بازگردانی'); }
          retries = 0;
          if (j.busy) { setTimeout(tick, 900); return; }
          if (onProgress) onProgress(j);
          if (j.ok === false) { var er = new Error(j.error || 'نامشخص'); er.resp = j; reject(er); return; }
          if (j.status === 'done') { resolve(j); return; }
          setTimeout(tick, 120);
        }).catch(function (e) {
          if (retries++ < 6) { setTimeout(tick, 1500); return; }
          reject(e);
        });
      }
      tick();
    });
  }

  var GROUPS = [['محتوا', /(posts|postmeta|terms|termmeta|term_taxonomy|term_relationships|comments|commentmeta)$/], ['تنظیمات', /options$/], ['کاربران', /(users|usermeta)$/]];

  function startRestore(b, rollback) {
    if (S.runnerOk === false) { toast('بازگردانی روی این هاست ممکن نیست (restore-runner.php مسدود است).', true); return; }
    var mode = 'full', picked = {}, loaded = false;
    var summary = h('div', { style: { display: 'grid', gap: '10px' } }, h('p', { class: 'dbs-sub2' }, 'در حال بررسی تغییرات پس از این بکاپ…'));
    var input = h('input', { class: 'dbs-input', placeholder: 'کلمه «' + WORD + '» را بنویسید', autocomplete: 'off', style: { width: '100%' } });
    var picker = h('div', { class: 'dbs-picker', style: { display: 'none' } });
    var go1 = h('button', { class: 'dbs-btn dbs-btn-danger', disabled: true }, ic('restore'), 'شروع بازگردانی');
    function refreshGo() { go1.disabled = !(normFa(input.value) === WORD && (mode === 'full' || Object.keys(picked).length > 0)); }
    input.addEventListener('input', refreshGo);

    var segFull = h('button', { class: 'dbs-seg-b on', type: 'button' }, 'کل دیتابیس');
    var segPart = h('button', { class: 'dbs-seg-b', type: 'button' }, 'فقط جدول‌های انتخابی');
    function setMode(mm) {
      mode = mm; segFull.classList.toggle('on', mm === 'full'); segPart.classList.toggle('on', mm === 'partial');
      picker.style.display = mm === 'partial' ? 'block' : 'none';
      if (mm === 'partial' && !loaded) loadTables();
      refreshGo();
    }
    segFull.addEventListener('click', function () { setMode('full'); });
    segPart.addEventListener('click', function () { setMode('partial'); });

    function loadTables() {
      loaded = true; picker.replaceChildren(h('p', { class: 'dbs-sub2' }, 'در حال خواندن فهرست جدول‌ها…'));
      api('tables_of', { id: b.id }).then(function (d) {
        var list = h('div', { class: 'dbs-picker-list' }), boxes = {};
        var q = h('input', { class: 'dbs-input', type: 'search', placeholder: 'جستجوی جدول…', style: { width: '100%' } });
        function setAll(fn) { d.tables.forEach(function (t) { var on = fn(t.name); boxes[t.name].checked = on; if (on) picked[t.name] = true; else delete picked[t.name]; }); refreshGo(); cnt.textContent = num(Object.keys(picked).length) + ' جدول انتخاب شده'; }
        var cnt = h('span', { class: 'dbs-sub2' }, '۰ جدول انتخاب شده');
        d.tables.forEach(function (t) {
          var cb = h('input', { type: 'checkbox' }); boxes[t.name] = cb;
          cb.addEventListener('change', function () { if (cb.checked) picked[t.name] = true; else delete picked[t.name]; cnt.textContent = num(Object.keys(picked).length) + ' جدول انتخاب شده'; refreshGo(); });
          list.append(h('label', { class: 'dbs-pick', 'data-n': t.name.toLowerCase() }, cb, h('span', { class: 'ltr' }, t.name), h('small', { class: 'dbs-sub2' }, num(t.rows) + ' ردیف')));
        });
        q.addEventListener('input', function () { var v = q.value.toLowerCase(); Array.prototype.forEach.call(list.children, function (el) { el.style.display = el.getAttribute('data-n').indexOf(v) > -1 ? '' : 'none'; }); });
        var quick = h('div', { class: 'dbs-quick' },
          h('button', { class: 'dbs-btn dbs-btn-sm', type: 'button', onclick: function () { setAll(function () { return true; }); } }, 'همه'),
          h('button', { class: 'dbs-btn dbs-btn-sm', type: 'button', onclick: function () { setAll(function () { return false; }); } }, 'هیچ'),
          GROUPS.map(function (g) { return h('button', { class: 'dbs-btn dbs-btn-sm', type: 'button', onclick: function () { setAll(function (n) { return g[1].test(n); }); } }, 'فقط ' + g[0]); }));
        picker.replaceChildren(quick, q, list, cnt);
      }).catch(function (e) { picker.replaceChildren(h('p', { class: 'dbs-alert bad' }, e.message)); });
    }

    go1.addEventListener('click', function () {
      m.close();
      askPw('برای شروع بازگردانی رمز عبور خود را وارد کنید.').then(function (pw) {
        if (pw === null) return;
        runRestore(b, { rollback: rollback, tables: mode === 'partial' ? Object.keys(picked) : [], pw: pw });
      });
    });
    var m = modal('بازگردانی دیتابیس به ' + dtStr(b.created), [
      h('div', { class: 'dbs-alert bad' }, ic('alert'), h('div', null, h('b', null, 'دیتابیس فعلی جایگزین می‌شود. '), 'همه‌ی تغییرات بعد از این بکاپ (نوشته‌ها، سفارش‌ها، کاربران جدید، تنظیمات…) از بین می‌روند. قبل از شروع، یک «بکاپ ایمنی» از وضعیت فعلی گرفته می‌شود تا بتوانید برگردید. ممکن است پس از پایان لازم باشد دوباره وارد شوید.')),
      summary,
      h('div', { class: 'dbs-seg' }, segFull, segPart), picker,
      h('div', null, h('label', { style: { display: 'block', fontWeight: 700, marginBottom: '6px' } }, 'برای تأیید تایپ کنید: ' + WORD), input)
    ], [go1, h('button', { class: 'dbs-btn', onclick: function () { m.close(); } }, 'انصراف')], true);
    if (rollback) summary.replaceChildren(h('p', { class: 'dbs-sub2' }, 'این بکاپ ایمنی است که قبل از بازگردانی ناموفق گرفته شده بود.'));
    else api('changes_since', { id: b.id }).then(function (d) { summary.replaceChildren.apply(summary, changesBody(d, true)); }).catch(function () { summary.replaceChildren(); });
  }

  function runRestore(b, o) {
    o = o || {};
    var partial = o.tables && o.tables.length;
    var steps = [['safety', 'ساخت بکاپ ایمنی از وضعیت فعلی'], ['prepare', 'آماده‌سازی و بررسی صحت فایل بکاپ'], ['restore', partial ? 'بازگردانی ' + num(o.tables.length) + ' جدول' : 'بازگردانی جدول‌ها']];
    var els = {}, bar = h('i'), info = h('div', { class: 'dbs-sub2' }), foot = h('div', { class: 'dbs-modal-f', style: { display: 'none', borderTop: 0, padding: 0 } });
    var list = h('div', { class: 'dbs-steps' }, steps.map(function (st) {
      var badge = h('span', { class: 'b' }), text = h('div', null, h('b', null, st[1]));
      els[st[0]] = { row: h('div', { class: 'dbs-step' }, badge, text), badge: badge, text: text };
      return els[st[0]].row;
    }));
    els.restore.text.append(h('div', { class: 'dbs-prog' }, bar), info);
    var m = modal('در حال بازگردانی…', [list, foot], null, false, true);

    function mark(k, state) {
      var e = els[k]; e.row.className = 'dbs-step ' + state;
      e.badge.replaceChildren(state === 'done' ? ic('check') : state === 'err' ? ic('x') : state === 'on' ? ic('refresh', 'dbs-spin') : '');
    }
    function fail(msg, safe) {
      m.el.querySelector('h3').textContent = 'بازگردانی ناموفق بود';
      info.textContent = msg + ' اگر پنل باز نشد: فایل بکاپ ایمنی داخل پوشه‌ی dbs-backups-… در wp-content است و با phpMyAdmin قابل ایمپورت است.'; info.style.color = 'var(--coral, #d8433e)';
      foot.style.display = 'flex'; foot.style.marginTop = '12px';
      foot.replaceChildren(h('button', { class: 'dbs-btn', onclick: function () { m.close(); refresh(); } }, 'بستن'));
      if (safe) foot.append(h('button', { class: 'dbs-btn dbs-btn-amber', onclick: function () { m.close(); startRestore(safe, true); } }, ic('restore'), 'برگرداندن به بکاپ ایمنی'));
    }
    function finish() {
      m.el.querySelector('h3').textContent = 'بازگردانی با موفقیت انجام شد';
      info.textContent = (partial ? 'جدول‌های انتخابی' : 'دیتابیس') + ' به وضعیت ' + dtStr(b.created) + ' برگشت.';
      foot.style.display = 'flex'; foot.style.marginTop = '12px';
      foot.replaceChildren(h('button', { class: 'dbs-btn dbs-btn-amber', onclick: function () { location.reload(); } }, ic('refresh'), 'بارگذاری مجدد صفحه'),
        h('span', { class: 'dbs-sub2', style: { alignSelf: 'center' } }, 'اگر از پنل خارج شدید، دوباره وارد شوید.'));
    }

    var first = o.rollback ? Promise.resolve({ id: b.id, created: b.created }) : (mark('safety', 'on'), api('backup_now', { type: 'pre_restore', 'for': b.id, pw: o.pw || '' }));
    var safeMeta = null;
    first.then(function (safe) {
      safeMeta = safe; mark('safety', 'done'); mark('prepare', 'on');
      return api('restore_init', { id: b.id, tables: o.tables || [], pw: o.pw || '' });
    }).then(function (job) {
      mark('prepare', 'done'); mark('restore', 'on');
      return pollJob(job, function (j) { if (j.percent !== undefined) { bar.style.width = j.percent + '%'; info.textContent = num(j.percent) + '٪ — ' + num(j.stmts || 0) + ' دستور اجرا شد'; } });
    }).then(function () { mark('restore', 'done'); bar.style.width = '100%'; finish(); }).catch(function (e) {
      var cur = ['safety', 'prepare', 'restore'].filter(function (k) { return els[k].row.classList.contains('on'); })[0];
      if (cur) mark(cur, 'err');
      var msg = e.message;
      if (cur === 'restore') msg = 'خطا: ' + msg + ' — دیتابیس ممکن است نیمه‌کاره بازگردانی شده باشد؛ پیشنهاد می‌شود به بکاپ ایمنی برگردید.';
      fail(msg, cur === 'restore' ? safeMeta : null);
    });
  }

  function verifyBackup(b) {
    var bar = h('i'), info = h('div', { class: 'dbs-sub2' }, 'در حال آماده‌سازی…'), foot = h('div', { class: 'dbs-modal-f', style: { display: 'none', padding: 0, borderTop: 0, marginTop: '10px' } });
    var m = modal('تست بازگردانی بکاپ', [
      h('p', { class: 'dbs-sub2' }, 'بکاپ در جدول‌های موقت (پیشوند dbsvt_) بازگردانی و شمارش می‌شود و سپس جدول‌های موقت پاک می‌شوند. به داده‌های سایت دست نمی‌زند.'),
      h('div', { class: 'dbs-prog' }, bar), info, foot], null, false, true);
    function showResult(v) {
      m.el.querySelector('h3').textContent = v && v.ok ? 'بکاپ سالم است' : 'مشکل در بکاپ';
      info.replaceChildren(v && v.ok ? h('span', null, ic('check'), ' همه‌ی ' + num(v.checked) + ' جدول با موفقیت بازگردانی و تأیید شد.')
        : h('div', { class: 'dbs-alert bad' }, ic('alert'), h('div', null, h('b', null, 'مشکل پیدا شد:'), h('div', null, (v && v.mismatch ? v.mismatch : ['نامشخص']).join(' | ')))));
      foot.style.display = 'flex';
      foot.replaceChildren(h('button', { class: 'dbs-btn', onclick: function () { m.close(); refresh(); } }, 'بستن'));
    }
    api('verify_init', { id: b.id }).then(function (job) {
      info.textContent = 'در حال اجرا…';
      return pollJob(job, function (j) { if (j.percent !== undefined) { bar.style.width = j.percent + '%'; info.textContent = num(j.percent) + '٪'; } });
    }).then(function (j) { bar.style.width = '100%'; showResult(j.verify); }).catch(function (e) {
      if (e.resp && e.resp.verify) showResult(e.resp.verify);
      else { m.el.querySelector('h3').textContent = 'تست ناموفق بود'; info.textContent = e.message; foot.style.display = 'flex'; foot.replaceChildren(h('button', { class: 'dbs-btn', onclick: function () { m.close(); refresh(); } }, 'بستن')); }
    });
  }

  /* ---- upload a backup file (chunked) */
  function openUpload() {
    var file = h('input', { type: 'file', accept: '.sql,.gz,.enc,.sql.gz', class: 'dbs-input', style: { width: '100%' } });
    var pass = h('input', { type: 'password', class: 'dbs-input', placeholder: 'رمز (فقط اگر فایل با DB Sentinel رمزنگاری شده)', style: { width: '100%' }, autocomplete: 'off' });
    var bar = h('i'), info = h('div', { class: 'dbs-sub2' }), prog = h('div', { class: 'dbs-prog', style: { display: 'none' } }, bar);
    var start = h('button', { class: 'dbs-btn dbs-btn-amber' }, ic('upload'), 'آپلود و ورود بکاپ');
    var m = modal('آپلود فایل بکاپ', [
      h('p', { class: 'dbs-sub2' }, 'فایل SQL دیتابیس وردپرس (خروجی DB Sentinel، phpMyAdmin، mysqldump یا افزونه‌های دیگر) را انتخاب کنید. فایل‌های فشرده‌ی gzip و فایل‌های رمزنگاری‌شده‌ی DB Sentinel هم پشتیبانی می‌شوند. اگر پیشوند جدول‌ها فرق داشته باشد خودکار به پیشوند این سایت تبدیل می‌شود. فایل به‌صورت تکه‌تکه بالا می‌رود و به محدودیت آپلود هاست وابسته نیست.'),
      file, pass, prog, info], [start, h('button', { class: 'dbs-btn', onclick: function () { m.close(); } }, 'بستن')], true);
    var uid = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
    var uploaded = false;

    function finishCall() {
      info.textContent = 'در حال پردازش و ورود فایل… (برای فایل‌های بزرگ ممکن است چند دقیقه طول بکشد)';
      api('upload_finish', { uid: uid, name: file.files[0].name, pass: pass.value }).then(function (meta) {
        bar.style.width = '100%'; info.replaceChildren(h('span', null, ic('check'), ' وارد شد: ' + num(meta.tables) + ' جدول، ' + bytes(meta.size) + '. بکاپ قفل شده و در لیست هست.'));
        start.disabled = false; start.replaceChildren('بستن'); start.onclick = function () { m.close(); refresh(); };
        refresh(true);
      }).catch(function (e) {
        info.textContent = e.message; info.style.color = 'var(--coral, #d8433e)'; start.disabled = false;
        if (e.data && e.data.need_pass) { uploaded = true; pass.focus(); }
      });
    }
    function chunkPost(i, total, chunk, tries) {
      var fd = new FormData();
      fd.append('action', 'dbs'); fd.append('nonce', C.nonce); fd.append('do', 'upload_chunk');
      fd.append('uid', uid); fd.append('index', i); fd.append('total', total);
      fd.append('chunk', file.files[0].slice(i * chunk, (i + 1) * chunk), 'chunk.bin');
      return fetch(C.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.text(); }).then(function (t) {
        var j; try { j = JSON.parse(t); } catch (e) { throw new Error('پاسخ نامعتبر از سرور'); }
        if (!j.success) { var er = new Error((j.data && j.data.message) || 'خطا'); er.data = j.data || {}; throw er; }
        bar.style.width = Math.round((i + 1) / total * 100) + '%'; info.textContent = 'در حال آپلود… ' + num(Math.round((i + 1) / total * 100)) + '٪';
        return i + 1 < total ? chunkPost(i + 1, total, chunk, 0) : true;
      }).catch(function (e) {
        if (e.data && typeof e.data.next === 'number' && e.data.next !== i) return chunkPost(e.data.next, total, chunk, 0);
        if (tries < 3) return delay(1500).then(function () { return chunkPost(i, total, chunk, tries + 1); });
        throw e;
      });
    }
    start.addEventListener('click', function () {
      if (uploaded) return finishCall();
      var f = file.files[0];
      if (!f) { toast('یک فایل انتخاب کنید', true); return; }
      start.disabled = true; prog.style.display = 'block'; info.style.color = ''; bar.style.width = '0';
      var chunk = Math.max(262144, Math.floor((C.chunk || 2097152) * 0.8)), total = Math.max(1, Math.ceil(f.size / chunk));
      chunkPost(0, total, chunk, 0).then(function () { uploaded = true; finishCall(); }).catch(function (e) { info.textContent = e.message; info.style.color = 'var(--coral, #d8433e)'; start.disabled = false; });
    });
  }

  /* ---- remote storage browser */
  function openRemote() {
    var body = h('div', null, h('p', { class: 'dbs-sub2' }, 'در حال خواندن فهرست فایل‌ها…'));
    var m = modal('ذخیره‌ساز بیرونی', [body], [h('button', { class: 'dbs-btn', onclick: function () { m.close(); } }, 'بستن'), h('button', { class: 'dbs-btn', onclick: function () { m.close(); go('settings'); } }, 'تنظیمات ذخیره‌ساز')], true);
    function load() {
      api('remote_list').then(function (d) {
        if (!d.items.length) { body.replaceChildren(empty('فایلی روی ذخیره‌ساز نیست', 'بعد از اولین ارسال، بکاپ‌ها اینجا دیده می‌شوند.')); return; }
        body.replaceChildren(h('div', { class: 'dbs-scroll' }, h('table', { class: 'dbs-table' },
          h('thead', null, h('tr', null, ['زمان', 'حجم', 'وضعیت', 'عملیات'].map(function (t) { return h('th', null, t); }))),
          h('tbody', null, d.items.map(function (it) {
            return h('tr', null, h('td', null, h('b', null, dtStr(it.created)), h('div', { class: 'dbs-sub2 ltr' }, it.name)), h('td', { class: 'num' }, bytes(it.size)),
              h('td', null, h('div', { class: 'dbs-flags' }, it.enc ? chip('رمزنگاری‌شده', 'cobalt') : null, it.local ? chip('روی این سرور هم هست', 'teal') : null)),
              h('td', null, h('div', { class: 'acts' },
                h('button', { class: 'dbs-btn dbs-btn-sm', onclick: function () { importRemote(it); } }, ic('download'), 'دریافت به لیست بکاپ‌ها'),
                iconAct('trash', 'حذف از ذخیره‌ساز', function () { delRemote(it); }))));
          })))));
      }).catch(function (e) { body.replaceChildren(h('div', { class: 'dbs-alert bad' }, ic('alert'), h('div', null, e.message))); });
    }
    function importRemote(it) {
      var run = function (pw) {
        toast('در حال دریافت و ورود بکاپ…');
        api('remote_import', { name: it.name, pass: pw || '' }).then(function () { toast('بکاپ دریافت شد و در لیست هست'); m.close(); return refresh(); }).catch(function (e) {
          if (e.data && e.data.need_pass) { var p = window.prompt('رمز رمزنگاری این فایل را وارد کنید:'); if (p) run(p); } else toast(e.message, true);
        });
      };
      run('');
    }
    function delRemote(it) {
      confirmBox('حذف از ذخیره‌ساز', 'فایل ' + it.name + ' از ذخیره‌ساز بیرونی حذف شود؟', 'حذف', true).then(function (ok) {
        if (!ok) return;
        askPw('برای حذف رمز عبور را وارد کنید.').then(function (pw) {
          if (pw === null) return;
          api('remote_delete', { name: it.name, pw: pw }).then(function () { toast('حذف شد'); load(); }).catch(function (e) { toast(e.message, true); });
        });
      });
    }
    load();
  }

  /* ---- compare two backups (or a backup with the live database) */
  var CMP = { changed: ['تغییر کرده', 'coral'], added: ['فقط در دومی', 'teal'], removed: ['فقط در اولی', 'amber'], same: ['یکسان', ''], maybe: ['ردیف‌ها یکسان (محتوا نامشخص)', 'cobalt'] };
  function openCompare() {
    var bs = S.ov.backups;
    if (!bs.length) { toast('بکاپی برای مقایسه وجود ندارد.', true); return; }
    var opt = function (b) { return h('option', { value: b.id }, dtStr(b.created) + ' — ' + (BTYPE[b.type] || BTYPE.manual)[0]); };
    var selA = h('select', { class: 'dbs-input' }, bs.map(opt));
    var selB = h('select', { class: 'dbs-input' }, [h('option', { value: 'live' }, 'وضعیت فعلی دیتابیس')].concat(bs.map(opt)));
    var out = h('div', { style: { marginTop: '14px' } });
    var run = h('button', { class: 'dbs-btn dbs-btn-amber' }, ic('compare'), 'مقایسه');
    var m = modal('مقایسه', [
      h('div', { class: 'dbs-filters' }, h('div', null, h('small', { class: 'dbs-sub2' }, 'اول'), h('div', null, selA)), h('div', null, h('small', { class: 'dbs-sub2' }, 'دوم'), h('div', null, selB)), run), out], [h('button', { class: 'dbs-btn', onclick: function () { m.close(); } }, 'بستن')], true);
    run.addEventListener('click', function () {
      out.replaceChildren(h('p', { class: 'dbs-sub2' }, 'در حال مقایسه…'));
      api('compare', { a: selA.value, b: selB.value }).then(function (d) { renderCmp(d.rows); }).catch(function (e) { out.replaceChildren(h('div', { class: 'dbs-alert bad' }, e.message)); });
    });
    function renderCmp(rows) {
      var cnt = {}; rows.forEach(function (r) { cnt[r.status] = (cnt[r.status] || 0) + 1; });
      var live = selB.value === 'live';
      var deepBtns = [];
      var trs = rows.map(function (r) {
        var st = CMP[r.status], cell = h('td', null, h('span', { class: 'dbs-chip ' + st[1] }, st[0]));
        var tr = h('tr', { style: { display: r.status === 'same' ? 'none' : '' }, 'data-same': r.status === 'same' ? '1' : '' }, h('td', { class: 'ltr' }, r.name), h('td', { class: 'num' }, r.a === null ? '—' : num(r.a)), h('td', { class: 'num' }, r.b === null ? '—' : num(r.b)), cell);
        if (live && r.status === 'maybe' && r.crc_a) {
          var b1 = h('button', { class: 'dbs-btn dbs-btn-sm' }, 'بررسی دقیق');
          var runDeep = function () {
            b1.disabled = true; b1.textContent = '…';
            return api('deep_check', { table: r.name }).then(function (x) {
              var same = x.crc === r.crc_a; cell.replaceChildren(h('span', { class: 'dbs-chip ' + (same ? '' : 'coral') }, same ? 'یکسان (تأییدشده)' : 'محتوا تغییر کرده'));
              if (same) { tr.style.display = 'none'; tr.setAttribute('data-same', '1'); }
            }).catch(function () { b1.textContent = 'خطا'; });
          };
          b1.addEventListener('click', runDeep); deepBtns.push(runDeep);
          cell.append(' ', b1);
        }
        return tr;
      });
      var showSame = h('label', { class: 'dbs-switch', style: { marginInlineStart: 'auto' } }, h('input', { type: 'checkbox', onchange: function (e) { trs.forEach(function (tr) { if (tr.getAttribute('data-same') === '1') tr.style.display = e.target.checked ? '' : 'none'; }); } }), h('span', { class: 'tr' }), h('span', null, 'نمایش جدول‌های یکسان'));
      out.replaceChildren(
        h('div', { class: 'dbs-filters', style: { marginBottom: '10px' } },
          Object.keys(CMP).map(function (k) { return cnt[k] ? h('span', { class: 'dbs-chip ' + CMP[k][1] }, CMP[k][0] + ': ' + num(cnt[k])) : null; }),
          deepBtns.length ? h('button', { class: 'dbs-btn dbs-btn-sm', onclick: function () { deepBtns.reduce(function (p, f) { return p.then(f); }, Promise.resolve()); } }, 'بررسی دقیق همه (' + num(deepBtns.length) + ')') : null, showSame),
        h('div', { class: 'dbs-scroll', style: { maxHeight: '46vh', overflow: 'auto' } }, h('table', { class: 'dbs-table' },
          h('thead', null, h('tr', null, ['جدول', 'ردیف (اول)', 'ردیف (دوم)', 'وضعیت'].map(function (t) { return h('th', null, t); }))), h('tbody', null, trs))));
    }
  }

  /* ------------------------------------------------------------ activity */
  function payload() {
    var f = S.act.f, o = {};
    ['q', 'kind', 'category', 'severity', 'user', 'actor', 'context'].forEach(function (k) { if (f[k]) o[k] = f[k]; });
    if (f.id) o.id = f.id;
    if (f.since) o.since = f.since;
    else if (f.range && f.range !== 'all' && f.range !== 'custom') o.since = nowTs() - parseInt(f.range, 10) * 3600;
    return o;
  }
  var searchTimer = null;
  function viewActivity() {
    var A = S.act, f = A.f;
    function sel(key, options, ph) {
      return h('select', { class: 'dbs-input', 'aria-label': ph, onchange: function (e) { f[key] = e.target.value; if (key === 'range') f.since = 0; f.id = 0; loadActivity(true); } },
        options.map(function (o) { return h('option', { value: o[0], selected: String(f[key] || '') === String(o[0]) }, o[1]); }));
    }
    var opts = A.opts || { users: [], actors: [], categories: [] };
    var listEl = h('div', { id: 'dbs-list' });
    var q = h('input', { class: 'dbs-input grow', type: 'search', placeholder: 'جستجو در تغییرات، کاربر، افزونه، جدول…', value: f.q, oninput: function (e) { clearTimeout(searchTimer); searchTimer = setTimeout(function () { f.q = e.target.value; f.id = 0; loadActivity(true); }, 350); } });
    var chipsRow = [];
    if (f.since && f.range === 'custom') chipsRow.push(h('span', { class: 'dbs-chip amber' }, 'از زمان بکاپ ' + dtStr(f.since), h('button', { class: 'dbs-x', style: { fontSize: '14px', padding: 0 }, 'aria-label': 'حذف فیلتر', onclick: function () { f.since = 0; f.range = '48'; renderMain(); loadActivity(true); } }, '×')));
    if (f.id) chipsRow.push(h('span', { class: 'dbs-chip amber' }, 'نمایش یک رویداد', h('button', { class: 'dbs-x', style: { fontSize: '14px', padding: 0 }, 'aria-label': 'حذف فیلتر', onclick: function () { f.id = 0; f.range = '48'; renderMain(); loadActivity(true); } }, '×')));
    mainEl.append(h('section', { class: 'dbs-panel' },
      h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: '10px', flexWrap: 'wrap' } },
        h('div', null, h('h3', null, 'تغییرات دیتابیس'), h('p', { class: 'dbs-hint' }, 'ببینید چه کسی، از کجا و با کدام افزونه چه چیزی را تغییر داده است. روی هر ردیف بزنید تا جزئیات و مقدار قبل/بعد را ببینید.')),
        h('a', { class: 'dbs-btn dbs-btn-sm', href: C.csv + '&f=' + encodeURIComponent(JSON.stringify(payload())) }, ic('download'), 'خروجی CSV')),
      h('div', { class: 'dbs-filters' }, q,
        sel('range', [['1', 'یک ساعت اخیر'], ['24', '۲۴ ساعت اخیر'], ['48', '۴۸ ساعت اخیر'], ['168', '۷ روز اخیر'], ['720', '۳۰ روز اخیر'], ['all', 'همه زمان‌ها']].concat(f.since ? [['custom', 'از زمان بکاپ انتخاب‌شده']] : []), 'بازه'),
        sel('severity', [['', 'همه سطح‌ها'], ['important', 'فقط مهم‌ها'], ['danger', 'خطر'], ['warning', 'هشدار'], ['notice', 'توجه'], ['info', 'عادی']], 'سطح'),
        sel('kind', [['', 'همه نوع‌ها'], ['event', 'رویدادهای معنایی'], ['sql', 'کوئری‌های SQL']], 'نوع'),
        sel('user', [['', 'همه کاربران'], ['__none__', 'سیستم / ناشناس']].concat(opts.users.map(function (u) { return [u, u]; })), 'کاربر'),
        sel('actor', [['', 'همه افزونه‌ها / بخش‌ها']].concat(opts.actors.map(function (a) { return [a.key, (ATYPE[a.type] || a.type) + ': ' + a.name]; })), 'مسئول'),
        sel('category', [['', 'همه دسته‌ها']].concat(opts.categories.map(function (c) { return [c, CAT[c] || c]; })), 'دسته'),
        sel('context', [['', 'همه منشأها']].concat(Object.keys(CTX).map(function (c) { return [c, CTX[c]]; })), 'منشأ')),
      chipsRow.length ? h('div', { style: { marginTop: '10px', display: 'flex', gap: '8px' } }, chipsRow) : null,
      h('div', { style: { marginTop: '14px' } }, listEl)));
    if (!A.opts) api('filters').then(function (o) { A.opts = o; if (S.tab === 'activity') { mainEl.replaceChildren(); viewActivity(); } });
    if (f.range === 'custom' && !f.since) f.range = '48';
    loadActivity(true);
  }

  function loadActivity(reset) {
    var A = S.act, listEl = document.getElementById('dbs-list');
    if (!listEl) return;
    var mine = ++A.req;
    if (reset) { A.rows = []; listEl.replaceChildren(h('p', { class: 'dbs-sub2', style: { padding: '20px', textAlign: 'center' } }, 'در حال بارگذاری…')); }
    api('activity', { f: payload(), offset: reset ? 0 : A.rows.length, limit: 40 }).then(function (d) {
      if (mine !== A.req) return;
      A.rows = A.rows.concat(d.rows); A.total = d.total; renderList();
    }).catch(function (e) { if (mine === A.req) listEl.replaceChildren(h('p', { class: 'dbs-alert bad' }, e.message)); });
  }

  function userNode(e) {
    var name = e.user_login;
    if (!name) {
      var label = ({ cron: 'سیستم (کرون)', cli: 'خط فرمان', frontend: 'بازدیدکننده / ناشناس', rest: 'بدون ورود', ajax: 'بدون ورود' })[e.context] || 'سیستم / ناشناس';
      return h('div', { class: 'dbs-who' }, h('span', { class: 'dbs-avatar', style: { '--av': '#7a8b94' } }, '؟'), h('div', null, h('span', { class: 'n' }, label)));
    }
    return h('div', { class: 'dbs-who' }, avatar(name), h('div', { style: { minWidth: 0 } }, h('span', { class: 'n' }, name), h('span', { class: 'r' }, ROLE[e.user_role] || e.user_role || '')));
  }
  function diffNodes(d) {
    var out = [];
    function it(cls, lbl, x) {
      return h('div', { class: 'it ' + cls }, h('b', null, lbl), h('span', { class: 'ltr' }, x.label), x.ad ? chip('تبلیغاتی', 'amber') : null, x.obf ? chip('مشکوک / مبهم‌سازی‌شده', 'coral') : null);
    }
    if (d.removed && d.removed.length) out.push(d.removed.map(function (x) { return it('rm', 'حذف شد', x); }));
    if (d.added && d.added.length) out.push(d.added.map(function (x) { return it('ad', 'اضافه شد', x); }));
    return h('div', { class: 'dbs-diff' }, out);
  }
  function eventDetails(e) {
    var d = e.details || {}, parts = [];
    parts.push(h('div', { class: 'dbs-kv' },
      h('div', null, h('small', null, 'زمان دقیق'), h('span', null, fullStr(e.ts))),
      h('div', null, h('small', null, 'مسئول (بر اساس ردیابی کد)'), h('span', null, (ATYPE[e.actor_type] || e.actor_type) + ' — ' + e.actor_name)),
      h('div', null, h('small', null, 'منشأ درخواست'), h('span', null, CTX[e.context] || e.context)),
      h('div', null, h('small', null, 'درخواست'), h('span', { class: 'ltr' }, e.request || '—')),
      h('div', null, h('small', null, 'آی‌پی'), h('span', { class: 'ltr' }, e.ip || '—')),
      e.object_id ? h('div', null, h('small', null, 'شیء'), h('span', { class: 'ltr' }, e.object_type + ' / ' + e.object_id)) : null));
    if (d.diff) parts.push(diffNodes(d.diff));
    if (d.changes) parts.push(h('div', { class: 'dbs-diff' }, d.changes.map(function (c) { return h('div', { class: 'it' }, h('b', null, c.field + ':'), h('span', { class: 'ltr' }, (c.before || '∅') + '  ←  ' + (c.after || '∅'))); })));
    if (d.before !== undefined || d.after !== undefined) {
      parts.push(h('div', { class: 'dbs-ba' }, h('div', null, h('h4', null, 'قبل'), h('pre', { class: 'dbs-code' }, d.before || '∅')), h('div', null, h('h4', null, 'بعد'), h('pre', { class: 'dbs-code' }, d.after || '∅'))));
    }
    if (d.keys && d.keys.length) parts.push(h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap' } }, h('small', { class: 'dbs-sub2' }, 'کلیدهای تغییر‌یافته:'), d.keys.slice(0, 20).map(function (k) { return chip(k); })));
    if (e.undone) parts.push(h('div', null, chip('این تغییر برگردانده شده است', 'teal')));
    else if (e.undoable) parts.push(h('div', null, h('button', { class: 'dbs-btn dbs-btn-sm dbs-btn-amber', onclick: function (ev) { ev.stopPropagation(); undoEvent(e); } }, ic('undo'), 'برگرداندن این تغییر'), h('span', { class: 'dbs-sub2', style: { marginInlineStart: '10px' } }, 'فقط همین یک مورد به وضعیت قبل برمی‌گردد، نه کل دیتابیس.')));
    if (d.sample) parts.push(h('div', null, h('h4', { style: { margin: '0 0 4px', fontSize: '12.5px', color: 'var(--muted)' } }, 'نمونه کوئری (مقادیر بلند کوتاه شده‌اند)'), h('pre', { class: 'dbs-code' }, d.sample)));
    return parts;
  }

  function undoEvent(e) {
    function run(force) {
      askPw('برای برگرداندن این تغییر رمز عبور را وارد کنید.').then(function (pw) {
        if (pw === null) return;
        api('undo', { id: e.id, force: force ? 1 : 0, pw: pw }).then(function () {
          e.undone = true; e.undoable = false; toast('تغییر برگردانده شد'); renderList(); refresh(true);
        }).catch(function (er) {
          if (er.data && er.data.code === 'dbs_changed') {
            confirmBox('مقدار فعلی عوض شده', er.message, 'با این حال برگردان', true).then(function (ok) { if (ok) run(true); });
          } else toast(er.message, true);
        });
      });
    }
    confirmBox('برگرداندن تغییر', 'این تغییر به وضعیت قبل از آن برگردانده شود؟\n' + e.summary, 'برگردان', false).then(function (ok) { if (ok) run(false); });
  }

  function renderList() {
    var A = S.act, listEl = document.getElementById('dbs-list');
    if (!listEl) return;
    if (!A.rows.length) { listEl.replaceChildren(empty('موردی پیدا نشد', 'با این فیلترها تغییری ثبت نشده است. بازه یا فیلترها را عوض کنید.')); return; }
    var nodes = A.rows.map(function (e) {
      var open = !!A.open[e.id];
      var body = h('div', { class: 'dbs-ev-body', style: { display: open ? 'grid' : 'none' } });
      if (open) body.append.apply(body, eventDetails(e));
      var head = h('div', { class: 'dbs-ev-head sev-' + e.severity, tabindex: 0, role: 'button', 'aria-expanded': open ? 'true' : 'false' },
        h('span', { class: 'dbs-ev-bar' }),
        h('div', { class: 'dbs-ev-time' }, dtStr(e.ts), h('span', null, rel(e.ts))),
        userNode(e),
        h('div', { class: 'dbs-via' }, h('span', { class: 'a' }, actorIcon(e.actor_type), h('span', { title: e.actor_name }, e.actor_name)), h('span', { class: 'c' }, (ATYPE[e.actor_type] || '') + (CTX[e.context] ? ' · ' + CTX[e.context] : ''))),
        h('div', { class: 'dbs-what' }, h('div', { class: 's' }, e.summary), h('div', { class: 'm' }, chip(CAT[e.category] || e.category), e.severity !== 'info' ? chip(SEV[e.severity], e.severity === 'danger' ? 'coral' : e.severity === 'warning' ? 'amber' : 'cobalt') : null, e.kind === 'sql' ? chip('SQL') : null)),
        h('span', { class: 'dbs-chev' }, ic('chev')));
      var wrap = h('div', { class: 'dbs-ev' + (open ? ' open' : '') }, head, body);
      var toggle = function () {
        A.open[e.id] = !A.open[e.id]; var o = A.open[e.id];
        wrap.classList.toggle('open', o); body.style.display = o ? 'grid' : 'none'; head.setAttribute('aria-expanded', o ? 'true' : 'false');
        if (o && !body.childNodes.length) body.append.apply(body, eventDetails(e));
      };
      head.addEventListener('click', toggle);
      head.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); toggle(); } });
      return wrap;
    });
    if (A.rows.length < A.total) nodes.push(h('div', { style: { textAlign: 'center', paddingTop: '14px' } }, h('button', { class: 'dbs-btn', onclick: function () { loadActivity(false); } }, 'نمایش بیشتر (' + num(A.total - A.rows.length) + ' مورد دیگر)')));
    nodes.push(h('p', { class: 'dbs-sub2', style: { textAlign: 'center', marginTop: '10px' } }, num(A.total) + ' مورد پیدا شد'));
    listEl.replaceChildren.apply(listEl, nodes);
  }

  /* ------------------------------------------------------------ insights */
  function viewInsights() {
    var I = S.ins;
    var body = h('div', { style: { display: 'grid', gap: '18px' } }, h('p', { class: 'dbs-sub2' }, 'در حال بارگذاری…'));
    var sel = h('select', { class: 'dbs-input', onchange: function (e) { I.range = parseInt(e.target.value, 10); viewInsights2(body); } },
      [[24, '۲۴ ساعت اخیر'], [48, '۴۸ ساعت اخیر'], [168, '۷ روز اخیر'], [720, '۳۰ روز اخیر']].map(function (o) { return h('option', { value: o[0], selected: I.range === o[0] }, o[1]); }));
    mainEl.append(h('section', { class: 'dbs-panel', style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '10px', flexWrap: 'wrap' } },
      h('div', null, h('h3', null, 'آمار و تحلیل'), h('p', { class: 'dbs-hint', style: { margin: 0 } }, 'روی هر ردیف بزنید تا همان تغییرات در تب «تغییرات دیتابیس» فیلتر شوند.')), sel), body);
    viewInsights2(body);
  }
  function viewInsights2(body) {
    api('insights', { range: S.ins.range }).then(function (d) {
      var users = d.users.map(function (u) { return { label: u.login || 'سیستم / ناشناس', c: u.c, icon: avatar(u.login || '؟'), key: u.login }; });
      var actors = d.actors.map(function (a) { return { label: a.name, c: a.c, icon: actorIcon(a.type), key: a.type + ':' + a.slug }; });
      var tables = d.tables.map(function (t) { return { label: t.name, c: t.c, icon: ic('db'), key: t.name }; });
      var cats = d.categories.map(function (c) { return { label: CAT[c.name] || c.name, c: c.c, key: c.name }; });
      var sv = d.severity, total = sv.info + sv.notice + sv.warning + sv.danger;
      var bs = d.bucket === 'day' ? 86400 : 3600, map = {}, max = 1;
      d.buckets.forEach(function (b) { map[Math.floor(b.t / bs)] = b; if (b.c > max) max = b.c; });
      var n = d.bucket === 'day' ? Math.round(d.range / 24) : d.range, endB = Math.floor(nowTs() / bs), W = 900, H = 170, pb = 18, bw = W / n;
      var svg = s('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'dbs-chart' });
      svg.append(s('line', { x1: 0, x2: W, y1: H - pb, y2: H - pb, stroke: 'var(--line)' }));
      for (var i = 0; i < n; i++) {
        var key = endB - (n - 1) + i, b = map[key] || { c: 0, w: 0 }, hh = b.c ? Math.max(3, b.c / max * (H - pb - 8)) : 0, wh = b.c ? hh * (b.w / b.c) : 0;
        var g = s('g', null, s('title', null, (d.bucket === 'day' ? dateStr(key * bs) : dtStr(key * bs)) + ': ' + num(b.c) + ' تغییر'));
        g.append(s('rect', { x: i * bw + 1, y: 0, width: bw - 2, height: H - pb, fill: 'transparent' }));
        if (hh) g.append(s('rect', { x: i * bw + 1, y: H - pb - hh, width: bw - 2, height: hh, rx: 2, style: 'fill:var(--cobalt)', opacity: .85 }));
        if (wh) g.append(s('rect', { x: i * bw + 1, y: H - pb - wh, width: bw - 2, height: wh, rx: 2, fill: '#e8a13a' }));
        svg.append(g);
        if (n <= 48 ? i % 6 === 0 : i % Math.ceil(n / 10) === 0) svg.append(s('text', { x: i * bw + bw / 2, y: H - 4, 'text-anchor': 'middle' }, d.bucket === 'day' ? dateStr(key * bs) : timeStr(key * bs)));
      }
      var sevBar = h('div', { style: { display: 'flex', height: '12px', borderRadius: '999px', overflow: 'hidden', background: 'var(--panel2)', border: '1px solid var(--line)' } },
        ['info', 'notice', 'warning', 'danger'].map(function (k) { return h('i', { title: SEV[k] + ': ' + num(sv[k]), style: { width: (total ? sv[k] / total * 100 : 0) + '%', background: 'var(--s-' + k + ')' } }); }));
      body.replaceChildren(
        h('section', { class: 'dbs-panel' }, h('h3', null, 'روند تغییرات'), h('p', { class: 'dbs-hint' }, num(total) + ' تغییر ثبت شده؛ بخش نارنجی یعنی مهم'), svg,
          h('div', { style: { display: 'flex', gap: '14px', flexWrap: 'wrap', marginTop: '12px' } }, ['info', 'notice', 'warning', 'danger'].map(function (k) { return h('span', { class: 'dbs-sub2', style: { display: 'inline-flex', gap: '6px', alignItems: 'center' } }, h('span', { class: 'dbs-dot sev-' + k }), SEV[k] + ' ' + num(sv[k])); })), h('div', { style: { marginTop: '10px' } }, sevBar)),
        h('div', { class: 'dbs-grid3' },
          h('section', { class: 'dbs-panel' }, h('h3', null, 'کاربران'), h('p', { class: 'dbs-hint' }, 'بیشترین تغییرات'), users.length ? boardRows(users, 'var(--cobalt)', function (it) { filterActivity({ user: it.key || '__none__', kind: 'event' }); }) : empty('—', 'داده‌ای نیست')),
          h('section', { class: 'dbs-panel' }, h('h3', null, 'افزونه‌ها و بخش‌ها'), h('p', { class: 'dbs-hint' }, 'بیشترین نوشتن در دیتابیس'), actors.length ? boardRows(actors, 'var(--teal)', function (it) { filterActivity({ actor: it.key }); }) : empty('—', 'داده‌ای نیست')),
          h('section', { class: 'dbs-panel' }, h('h3', null, 'جدول‌ها'), h('p', { class: 'dbs-hint' }, 'بیشترین دستورهای نوشتن (SQL)'), tables.length ? boardRows(tables, '#c2571a', function (it) { filterActivity({ q: it.key, kind: 'sql' }); }) : empty('—', 'ثبت SQL خاموش است یا داده‌ای نیست'))),
        h('section', { class: 'dbs-panel' }, h('h3', null, 'دسته تغییرات'), h('p', { class: 'dbs-hint' }, 'چه نوع چیزهایی بیشتر تغییر کرده‌اند'), cats.length ? boardRows(cats, 'var(--cobalt)', function (it) { filterActivity({ category: it.key, kind: 'event' }); }) : empty('—', 'داده‌ای نیست')));
    }).catch(function (e) { body.replaceChildren(h('div', { class: 'dbs-alert bad' }, e.message)); });
  }

  /* ------------------------------------------------------------ security scanner */
  var SEVLBL = { danger: ['خطر', 'coral'], warning: ['هشدار', 'amber'], notice: ['توجه', 'cobalt'], info: ['اطلاع', ''] };
  function viewSecurity() {
    var bar = h('i'), prog = h('div', { class: 'dbs-prog', style: { display: 'none', marginTop: '12px' } }, bar), info = h('div', { class: 'dbs-sub2', style: { marginTop: '8px' } });
    var results = h('div', { style: { marginTop: '16px' } });
    var btn = h('button', { class: 'dbs-btn dbs-btn-amber' }, ic('scan'), 'شروع اسکن دیتابیس');
    btn.addEventListener('click', function () {
      btn.disabled = true; prog.style.display = 'block'; bar.style.width = '0'; results.replaceChildren(); info.textContent = 'در حال اسکن…';
      var all = [], st = { phase: 'posts', last: 0, scanned: 0 };
      (function step() {
        api('scan_step', { state: st }).then(function (d) {
          all = all.concat(d.findings); st = d.state; bar.style.width = d.percent + '%';
          info.textContent = num(d.percent) + '٪ — ' + num(all.length) + ' مورد پیدا شد';
          if (!d.done) return step();
          btn.disabled = false; info.textContent = 'اسکن کامل شد.'; showFindings(all);
        }).catch(function (e) { btn.disabled = false; info.textContent = e.message; info.style.color = 'var(--coral)'; });
      })();
    });
    function showFindings(all) {
      var rank = { danger: 0, warning: 1, notice: 2, info: 3 };
      all.sort(function (a, b) { return rank[a.sev] - rank[b.sev]; });
      var bad = all.filter(function (f) { return f.sev !== 'info'; });
      if (!all.length) { results.replaceChildren(empty('چیز مشکوکی پیدا نشد', 'در نوشته‌ها، تنظیمات و فیلدهای سفارشی کد مخفی یا مبهم‌سازی‌شده‌ای دیده نشد.')); return; }
      results.replaceChildren(
        h('p', { class: 'dbs-hint' }, num(bad.length) + ' مورد نیازمند بررسی و ' + num(all.length - bad.length) + ' مورد اطلاعاتی. اسکنر فقط گزارش می‌دهد و چیزی را تغییر نمی‌دهد. اگر کد مشکوکی بعد از یک بکاپ سالم اضافه شده، از تب «تغییرات دیتابیس» ببینید چه کسی آن را اضافه کرده و در صورت نیاز آن تغییر را برگردانید یا به بکاپ سالم برگردید.'),
        h('div', { class: 'dbs-scroll' }, h('table', { class: 'dbs-table' },
          h('thead', null, h('tr', null, ['سطح', 'نوع مورد', 'محل', 'نمونه'].map(function (t) { return h('th', null, t); }))),
          h('tbody', null, all.slice(0, 300).map(function (f) {
            var sv = SEVLBL[f.sev] || SEVLBL.info;
            return h('tr', null, h('td', null, chip(sv[0], sv[1])), h('td', null, f.rule),
              h('td', null, f.where.url ? h('a', { href: f.where.url, target: '_blank', rel: 'noopener' }, f.where.label) : f.where.label, h('div', { class: 'dbs-sub2' }, { post: 'نوشته/برگه', option: 'گزینه', meta: 'فیلد سفارشی', user: 'کاربر' }[f.where.type] || '')),
              h('td', null, h('code', { class: 'dbs-code ltr', style: { display: 'block', maxHeight: '90px' } }, f.snippet)));
          })))));
    }
    mainEl.append(
      h('section', { class: 'dbs-panel' }, h('h3', null, 'اسکنر امنیتی دیتابیس'),
        h('p', { class: 'dbs-hint' }, 'نوشته‌ها، تنظیمات و فیلدهای سفارشی را برای اسکریپت مبهم‌سازی‌شده، iframe مخفی، کد رمزشده (eval/base64)، لینک‌های مخفی اسپم، کدهای تبلیغاتی و مدیران تازه‌ساخته بررسی می‌کند.'), btn, prog, info, results),
      h('section', { class: 'dbs-panel' }, h('h3', null, 'ناهنجاری‌ها'),
        h('p', { class: 'dbs-hint' }, 'قانون‌های خودکار: حذف گروهی نوشته‌ها (۱۰ مورد در ۱۰ دقیقه) و ساخت چند کاربر پشت‌سرهم (۳ کاربر در ۱۰ دقیقه) به‌عنوان رویداد «خطر» ثبت و اعلان می‌شوند.'),
        h('button', { class: 'dbs-btn', onclick: function () { filterActivity({ category: 'anomaly' }); } }, 'مشاهده ناهنجاری‌های ثبت‌شده')));
  }

  /* ------------------------------------------------------------ tools */
  function viewTools() {
    var search = h('input', { class: 'dbs-input ltr', placeholder: 'https://old-domain.com', style: { width: '100%' } });
    var repl = h('input', { class: 'dbs-input ltr', placeholder: 'https://new-domain.com', style: { width: '100%' } });
    var bar = h('i'), prog = h('div', { class: 'dbs-prog', style: { display: 'none', marginTop: '12px' } }, bar), info = h('div', { class: 'dbs-sub2', style: { marginTop: '8px' } });
    var dry = h('button', { class: 'dbs-btn' }, 'اجرای آزمایشی (بدون تغییر)');
    var real = h('button', { class: 'dbs-btn dbs-btn-danger' }, ic('tool'), 'اجرای جایگزینی');
    function runSR(isDry) {
      var s = search.value, r = repl.value;
      if (!s) { toast('عبارت جستجو را وارد کنید.', true); return; }
      var lockUi = function (on) { dry.disabled = on; real.disabled = on; };
      lockUi(true); prog.style.display = 'block'; bar.style.width = '0'; info.style.color = ''; info.textContent = 'در حال آماده‌سازی…';
      var pre = isDry ? Promise.resolve() : api('backup_now', { type: 'pre_tool', pw: '' }).then(function () { info.textContent = 'بکاپ ایمنی ساخته شد…'; });
      pre.then(function () { return api('sr_tables'); }).then(function (d) {
        var st = { tables: d.tables, i: 0, last: null, cells: 0, rows: 0, scanned: 0, skipped: [] };
        return (function step() {
          return api('sr_step', { search: s, replace: r, dry: isDry ? 1 : 0, state: st }).then(function (x) {
            st = x.state; bar.style.width = x.percent + '%';
            info.textContent = num(x.percent) + '٪' + (x.table ? ' — ' + x.table : '') + ' — ' + num(st.cells) + ' سلول در ' + num(st.rows) + ' ردیف';
            return x.done ? st : step();
          });
        })();
      }).then(function (st) {
        info.replaceChildren(h('b', null, (isDry ? 'نتیجه‌ی آزمایشی: ' : 'انجام شد: ') + num(st.cells) + ' سلول در ' + num(st.rows) + ' ردیف ' + (isDry ? 'تغییر می‌کند.' : 'تغییر کرد.')),
          st.skipped.length ? h('div', { class: 'dbs-sub2' }, 'جدول‌های بدون کلید اصلی نادیده گرفته شدند: ' + st.skipped.join('، ')) : null);
        lockUi(false); if (!isDry) refresh(true);
      }).catch(function (e) { lockUi(false); info.textContent = e.message; info.style.color = 'var(--coral)'; });
    }
    dry.addEventListener('click', function () { runSR(true); });
    real.addEventListener('click', function () {
      confirmBox('اجرای جایگزینی', 'ابتدا یک بکاپ ایمنی گرفته می‌شود و سپس «' + search.value + '» در همه‌ی جدول‌ها با «' + repl.value + '» عوض می‌شود. پیشنهاد می‌شود اول اجرای آزمایشی را ببینید.', 'اجرا کن', true).then(function (ok) { if (ok) runSR(false); });
    });

    var cronUrl = (S.cronUrl || '');
    var cronBox = h('div', null, h('p', { class: 'dbs-sub2' }, 'در حال بارگذاری…'));
    api('settings').then(function (d) {
      S.cronUrl = d.cron_url;
      cronBox.replaceChildren(
        h('pre', { class: 'dbs-code' }, d.cron_url),
        h('p', { class: 'dbs-hint', style: { marginTop: '10px' } }, 'این آدرس مخفی است و فقط در صورت رسیدن زمان بکاپ، آن را اجرا می‌کند. در کرون‌جاب سرور (مثلاً هر ۱۵ دقیقه) بگذارید و برای دقت کامل در wp-config.php بنویسید define(\'DISABLE_WP_CRON\', true);'),
        h('pre', { class: 'dbs-code' }, '*/15 * * * * curl -s "' + d.cron_url + '" > /dev/null'),
        h('button', { class: 'dbs-btn dbs-btn-sm', onclick: function () { try { navigator.clipboard.writeText(d.cron_url); toast('کپی شد'); } catch (e) { toast('کپی نشد', true); } } }, 'کپی آدرس'));
    }).catch(function (e) { cronBox.replaceChildren(h('div', { class: 'dbs-alert bad' }, e.message)); });
    void cronUrl;

    mainEl.append(
      h('section', { class: 'dbs-panel' }, h('h3', null, 'جستجو و جایگزینی امن (مهاجرت / تغییر دامنه)'),
        h('p', { class: 'dbs-hint' }, 'بعد از انتقال سایت یا تغییر دامنه، آدرس قدیمی را در کل دیتابیس عوض می‌کند. داده‌های سریالایز وردپرس (تنظیمات پوسته، ابزارک‌ها، صفحه‌سازها) بدون خراب‌شدن اصلاح می‌شوند و ستون guid دست‌نخورده می‌ماند.'),
        h('div', { class: 'dbs-form' },
          h('div', { class: 'dbs-field' }, h('div', { class: 'l' }, 'جستجو'), h('div', null, search)),
          h('div', { class: 'dbs-field' }, h('div', { class: 'l' }, 'جایگزین'), h('div', null, repl))),
        h('div', { style: { display: 'flex', gap: '10px', marginTop: '14px', flexWrap: 'wrap' } }, dry, real), prog, info),
      h('section', { class: 'dbs-panel' }, h('h3', null, 'آدرس کرون امن'), h('p', { class: 'dbs-hint' }, 'بکاپ دقیق و مستقل از بازدید سایت'), cronBox),
      h('section', { class: 'dbs-panel' }, h('h3', null, 'دستورهای WP-CLI'), h('p', { class: 'dbs-hint' }, 'برای سرورها و اسکریپت‌ها'),
        h('pre', { class: 'dbs-code' }, ['wp sentinel backup', 'wp sentinel list', 'wp sentinel restore <id> --yes', 'wp sentinel restore <id> --tables=wp_options,wp_posts --yes', 'wp sentinel verify [<id>]', 'wp sentinel remote-upload [<id>]', 'wp sentinel scan', 'wp sentinel prune'].join('\n'))));
  }

  /* ------------------------------------------------------------ settings */
  function viewSettings() {
    var body = h('div', { style: { display: 'grid', gap: '18px' } }, h('p', { class: 'dbs-sub2' }, 'در حال بارگذاری…'));
    mainEl.append(body);
    api('settings').then(function (d) { S.settings = d.settings; S.cronUrl = d.cron_url; S.env = d.env; renderSettings(body); }).catch(function (e) { body.replaceChildren(h('div', { class: 'dbs-alert bad' }, e.message)); });
  }

  function renderSettings(body) {
    var st = S.settings, env = S.env || {}, F = {};
    function field(label, ctl, hint) { return h('div', { class: 'dbs-field' }, h('div', { class: 'l' }, label), h('div', null, ctl, hint ? h('small', null, hint) : null)); }
    function numIn(k, min, max, unit) { var i = h('input', { class: 'dbs-input', type: 'number', min: min, max: max, value: st[k], style: { width: '120px' } }); F[k] = function () { return parseInt(i.value, 10) || 0; }; return h('span', null, i, ' ', unit); }
    function sw(k, label) { var i = h('input', { type: 'checkbox', checked: !!parseInt(st[k], 10) }); F[k] = function () { return i.checked ? 1 : 0; }; return h('label', { class: 'dbs-switch' }, i, h('span', { class: 'tr' }), h('span', null, label)); }
    function txt(k, ph, ltr) { var i = h('input', { class: 'dbs-input' + (ltr ? ' ltr' : ''), value: st[k] || '', placeholder: ph || '', style: { width: '100%', maxWidth: '420px' } }); F[k] = function () { return i.value; }; return i; }
    function area(k, ph) { var i = h('textarea', { class: 'dbs-input ltr', rows: 4, style: { width: '100%' }, placeholder: ph || '' }, st[k] || ''); F[k] = function () { return i.value; }; return i; }
    function sec(k, ph) {
      var i = h('input', { class: 'dbs-input ltr', type: 'password', autocomplete: 'new-password', placeholder: st[k + '_set'] ? '•••••••• (ذخیره شده — خالی بگذارید تا حفظ شود)' : (ph || ''), style: { width: '100%', maxWidth: '420px' } });
      var clr = h('input', { type: 'checkbox' });
      F[k] = function () { return clr.checked ? '' : (i.value !== '' ? i.value : '__keep__'); };
      return h('div', null, i, st[k + '_set'] ? h('label', { class: 'dbs-sub2', style: { display: 'inline-flex', gap: '6px', marginTop: '6px', alignItems: 'center' } }, clr, 'حذف مقدار ذخیره‌شده') : null);
    }
    function sel(k, opts, onchange) {
      var i = h('select', { class: 'dbs-input' }, opts.map(function (o) { return h('option', { value: o[0], selected: String(st[k]) === String(o[0]) }, o[1]); }));
      F[k] = function () { return i.value; }; if (onchange) i.addEventListener('change', function () { onchange(i.value); }); return i;
    }

    var driverBoxes = {
      s3: h('div', { class: 'dbs-form' },
        field('Endpoint', txt('s3_endpoint', 'https://s3.amazonaws.com  یا  https://<id>.r2.cloudflarestorage.com', true), 'آدرس سرویس S3-سازگار (AWS، Cloudflare R2، Wasabi، MinIO، DigitalOcean Spaces، Backblaze B2 و…)'),
        field('Region', txt('s3_region', 'us-east-1  (برای R2: auto)', true)),
        field('Bucket', txt('s3_bucket', '', true)),
        field('Access Key', txt('s3_key', '', true)),
        field('Secret Key', sec('s3_secret')),
        field('پوشه (Prefix)', txt('s3_prefix', 'db-sentinel', true)),
        field('حالت آدرس', sw('s3_pathstyle', 'Path-style (پیشنهاد می‌شود؛ برای MinIO/R2 لازم است)'))),
      ftp: h('div', { class: 'dbs-form' },
        field('هاست', txt('ftp_host', 'ftp.example.com', true)),
        field('پورت', numIn('ftp_port', 1, 65535, '')),
        field('نام کاربری', txt('ftp_user', '', true)),
        field('رمز', sec('ftp_pass')),
        field('پوشه', txt('ftp_dir', '/db-sentinel', true)),
        field('اتصال امن', sw('ftp_ssl', 'FTPS (رمزنگاری TLS)')),
        field('حالت Passive', sw('ftp_passive', 'Passive (پیشنهاد می‌شود)')))
    };
    function showDriver(v) { driverBoxes.s3.style.display = v === 's3' ? 'grid' : 'none'; driverBoxes.ftp.style.display = v === 'ftp' ? 'grid' : 'none'; remoteCommon.style.display = v ? 'grid' : 'none'; }
    var driverSel = sel('remote_driver', [['', 'غیرفعال'], ['s3', 'S3-سازگار (AWS / R2 / Wasabi / …)'], ['ftp', 'FTP / FTPS']], showDriver);
    var remoteCommon = h('div', { class: 'dbs-form' },
      field('ارسال خودکار', sw('remote_auto', 'بعد از هر بکاپ، نسخه‌ای هم به ذخیره‌ساز بیرونی بفرست')),
      field('رمزنگاری', sw('remote_encrypt', 'قبل از ارسال با AES-256 رمزنگاری کن'), env.openssl === false ? 'افزونه OpenSSL در PHP این سرور فعال نیست؛ رمزنگاری کار نمی‌کند.' : 'برای بازگردانی از فایل رمزنگاری‌شده همین رمز لازم است. رمز را جایی امن هم نگه دارید.'),
      field('رمز رمزنگاری', sec('remote_pass', 'یک رمز قوی')),
      field('نگهداری روزانه', numIn('remote_daily', 0, 365, 'روز'), 'از هر روز، جدیدترین بکاپ نگه داشته می‌شود.'),
      field('نگهداری هفتگی', numIn('remote_weekly', 0, 104, 'هفته'), 'از هر هفته، جدیدترین بکاپ نگه داشته می‌شود. بکاپ‌های داخل بازه‌ی نگهداری محلی هم می‌مانند.'));
    var warns = [];
    if (env.curl === false) warns.push('cURL روی این سرور فعال نیست؛ ارسال به S3 کار نمی‌کند.');
    if (env.ftp === false) warns.push('افزونه FTP در PHP فعال نیست؛ ارسال با FTP کار نمی‌کند.');

    var resultBox = h('div', { class: 'dbs-sub2', style: { marginTop: '8px' } });
    function collect() { var d = {}; Object.keys(F).forEach(function (k) { d[k] = F[k](); }); return d; }
    function saveNow() { return api('settings_save', { data: collect() }).then(function (r) { S.settings = r.settings; st = r.settings; return refresh(true); }); }

    var save = h('button', { class: 'dbs-btn dbs-btn-amber' }, 'ذخیره تنظیمات');
    save.addEventListener('click', function () { save.disabled = true; saveNow().then(function () { toast('تنظیمات ذخیره شد. تغییر ثبت رویدادها از درخواست بعدی اعمال می‌شود.'); }).catch(function (e) { toast(e.message, true); }).then(function () { save.disabled = false; }); });
    var testRemote = h('button', { class: 'dbs-btn' }, ic('cloud'), 'ذخیره و آزمایش اتصال');
    testRemote.addEventListener('click', function () {
      testRemote.disabled = true; resultBox.textContent = 'در حال آزمایش…'; resultBox.style.color = '';
      saveNow().then(function () { return api('remote_test'); }).then(function () { resultBox.textContent = '✓ اتصال موفق بود.'; resultBox.style.color = 'var(--teal)'; })
        .catch(function (e) { resultBox.textContent = e.message; resultBox.style.color = 'var(--coral)'; }).then(function () { testRemote.disabled = false; });
    });
    var sendLatest = h('button', { class: 'dbs-btn' }, ic('upload'), 'ارسال آخرین بکاپ');
    sendLatest.addEventListener('click', function () {
      var b = S.ov && S.ov.backups[0]; if (!b) { toast('هنوز بکاپی وجود ندارد.', true); return; }
      sendLatest.disabled = true; resultBox.textContent = 'در حال ارسال…'; resultBox.style.color = '';
      saveNow().then(function () { return api('remote_upload', { id: b.id }); }).then(function () { resultBox.textContent = '✓ ارسال شد.'; resultBox.style.color = 'var(--teal)'; return refresh(true); })
        .catch(function (e) { resultBox.textContent = e.message; resultBox.style.color = 'var(--coral)'; }).then(function () { sendLatest.disabled = false; });
    });
    var testNotify = h('button', { class: 'dbs-btn' }, 'ذخیره و ارسال پیام آزمایشی');
    var notifyBox = h('div', { class: 'dbs-sub2', style: { marginTop: '8px' } });
    testNotify.addEventListener('click', function () {
      testNotify.disabled = true; notifyBox.textContent = 'در حال ارسال…'; notifyBox.style.color = '';
      saveNow().then(function () { return api('notify_test'); }).then(function (d) {
        var names = { email: 'ایمیل', telegram: 'تلگرام', webhook: 'وب‌هوک' }, keys = Object.keys(d.results);
        notifyBox.replaceChildren.apply(notifyBox, keys.length ? keys.map(function (k) { return h('div', { style: { color: d.results[k] === true ? 'var(--teal)' : 'var(--coral)' } }, (d.results[k] === true ? '✓ ' : '✗ ') + names[k] + (d.results[k] === true ? ' ارسال شد' : ': ' + d.results[k])); }) : ['هیچ کانالی فعال نیست.']);
      }).catch(function (e) { notifyBox.textContent = e.message; notifyBox.style.color = 'var(--coral)'; }).then(function () { testNotify.disabled = false; });
    });

    body.replaceChildren(
      h('section', { class: 'dbs-panel' }, h('h3', null, 'بکاپ'), h('p', { class: 'dbs-hint' }, 'پیش‌فرض: هر ۱۲ ساعت یک بکاپ و حذف بکاپ‌های قدیمی‌تر از ۴۸ ساعت'),
        h('div', { class: 'dbs-form' },
          field('فاصله بکاپ‌گیری', numIn('interval_hours', 1, 168, 'ساعت')),
          field('مدت نگهداری بکاپ', numIn('retention_hours', 1, 720, 'ساعت'), 'بکاپ‌های قدیمی‌تر حذف می‌شوند؛ آخرین بکاپ و بکاپ‌های قفل‌شده همیشه می‌مانند.'),
          field('فشرده‌سازی', sw('compress', 'فشرده‌سازی gzip'), 'حجم فایل‌ها را معمولاً به یک‌پنجم می‌رساند.'),
          field('جدول‌های مستثنی', area('exclude_tables', 'مثلاً:\nwc_sessions\n*_logs'), 'هر خط یک نام یا الگو (با *). نام را با یا بدون پیشوند بنویسید. این جدول‌ها بکاپ گرفته نمی‌شوند.'),
          field('محافظ دیسک', sw('disk_guard', 'اگر فضای آزاد کم بود بکاپ نگیر'), 'جلوگیری از پر شدن سرور و از کار افتادن سایت.'),
          field('قبل از آپدیت', sw('pre_update_snapshot', 'قبل از به‌روزرسانی افزونه/پوسته/هسته خودکار بکاپ بگیر')),
          field('تست خودکار', sw('auto_verify', 'روزی یک‌بار جدیدترین بکاپ را در جدول‌های موقت تست کن'), 'ثابت می‌کند بکاپ واقعاً قابل بازگردانی است. کمی فشار روی دیتابیس می‌آورد.'),
          field('تأیید هویت', sw('reauth', 'برای بازگردانی، حذف بکاپ و برگرداندن تغییرات رمز عبور بخواه')),
          field('حذف با افزونه', sw('delete_on_uninstall', 'با حذف افزونه، بکاپ‌ها هم پاک شوند'), 'پیش‌فرض خاموش است تا با حذف افزونه، تنها نسخه‌های پشتیبان از بین نروند.'))),

      h('section', { class: 'dbs-panel' }, h('h3', null, 'ذخیره‌ساز بیرونی'), h('p', { class: 'dbs-hint' }, 'بکاپ فقط روی همان سرور، اگر سرور از بین برود، از بین می‌رود. یک نسخه‌ی بیرونی (ترجیحاً رمزنگاری‌شده) بگذارید. کلیدها و رمزها فقط در پوشه‌ی خصوصی بکاپ ذخیره می‌شوند، نه در دیتابیس و نه داخل بکاپ‌ها.'),
        warns.length ? h('div', { class: 'dbs-alert' }, ic('alert'), h('div', null, warns.join(' '))) : null,
        h('div', { class: 'dbs-form' }, field('نوع', driverSel), driverBoxes.s3, driverBoxes.ftp, remoteCommon),
        h('div', { style: { display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '14px' } }, testRemote, sendLatest), resultBox),

      h('section', { class: 'dbs-panel' }, h('h3', null, 'اعلان‌ها'), h('p', { class: 'dbs-hint' }, 'اگر روی سرور ایران هستید و دسترسی به تلگرام بسته است، در «آدرس API تلگرام» آدرس یک پروکسی/رله‌ی خودتان را بگذارید.'),
        h('div', { class: 'dbs-form' },
          field('ایمیل', sw('notify_email_on', 'اعلان با ایمیل')), field('ایمیل گیرنده', txt('notify_email_to', 'خالی = ایمیل مدیر سایت', true)),
          field('تلگرام', sw('notify_telegram_on', 'اعلان با ربات تلگرام')), field('توکن ربات', sec('tg_token', '123456:ABC…')), field('Chat ID', txt('tg_chat', '', true)), field('آدرس API تلگرام', txt('tg_api', 'https://api.telegram.org', true)),
          field('وب‌هوک', sw('notify_webhook_on', 'ارسال JSON به یک آدرس (Slack، n8n، …)')), field('آدرس وب‌هوک', txt('webhook_url', 'https://…', true)),
          field('رویدادها', h('div', { style: { display: 'grid', gap: '8px' } }, sw('notify_danger', 'تغییرات با سطح «خطر» و ناهنجاری‌ها'), sw('notify_fail', 'شکست بکاپ / ارسال بیرونی'), sw('notify_missed', 'جاماندن بکاپ (زمان‌بند کار نمی‌کند)'), sw('notify_weekly', 'گزارش هفتگی')))),
        h('div', { style: { marginTop: '14px' } }, testNotify), notifyBox),

      h('section', { class: 'dbs-panel' }, h('h3', null, 'ردیابی تغییرات'), h('p', { class: 'dbs-hint' }, 'مشخص می‌کند چه کاربر یا افزونه‌ای چه چیزی را در دیتابیس عوض کرده است'),
        h('div', { class: 'dbs-form' },
          field('رویدادهای معنایی', sw('log_events', 'ثبت تغییر تنظیمات، نوشته‌ها، کاربران، افزونه‌ها، ابزارک‌ها…'), 'با مقدار قبل و بعد، امکان برگرداندن و تشخیص اضافه/حذف شدن اسکریپت و iframe.'),
          field('کوئری‌های SQL', sw('log_sql', 'ثبت دستورهای نوشتن در دیتابیس (تجمیع‌شده در هر درخواست)')),
          field('SQL بخش عمومی سایت', sw('log_sql_frontend', 'نوشتن‌های بازدیدکنندگان را هم ثبت کن'), 'روی سایت‌های پربازدید حجم لاگ را زیاد می‌کند؛ پیشنهاد: خاموش.'),
          field('نگهداری لاگ', numIn('log_retention_days', 1, 365, 'روز')),
          field('حداکثر تعداد رکورد', numIn('log_max_rows', 1000, 2000000, 'رکورد')),
          field('نادیده‌گرفتن نام‌ها', area('ignore_patterns', 'my_plugin_counter\n_my_cache'), 'هر خط یک عبارت. گزینه‌ها/فیلدهایی که نامشان شامل این عبارت باشد ثبت نمی‌شوند.'))),

      h('div', { style: { display: 'flex', gap: '10px', flexWrap: 'wrap' } }, save,
        h('button', { class: 'dbs-btn', onclick: function () {
          confirmBox('پاک‌کردن لاگ', 'کل سابقه‌ی تغییرات ثبت‌شده پاک شود؟ این کار بازگشت‌پذیر نیست.', 'پاک کن', true).then(function (ok) {
            if (!ok) return;
            askPw('برای پاک‌کردن لاگ رمز عبور را وارد کنید.').then(function (pw) { if (pw === null) return; api('activity_clear', { pw: pw }).then(function () { toast('لاگ پاک شد'); S.act.opts = null; return refresh(true); }).catch(function (e) { toast(e.message, true); }); });
          });
        } }, ic('trash'), 'پاک‌کردن لاگ تغییرات')),
      h('section', { class: 'dbs-panel' }, h('h3', null, 'سلامت'), S.ov ? healthList() : null));
    showDriver(st.remote_driver || '');
  }

  /* ------------------------------------------------------------ boot */
  function ping() {
    fetch(C.runner + '?ping=1', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (j) { S.runnerOk = !!(j && j.pong); }).catch(function () { S.runnerOk = false; }).then(function () { if (S.ov && (S.tab === 'backups' || S.tab === 'dashboard')) renderMain(); });
  }
  renderTabs();
  refresh().then(function () { ping(); });
  setInterval(function () { refresh(true); }, 60000);
  setInterval(function () { if (S.ov) renderHero(); }, 30000);
})();
